=== Publion ===
Contributors: jaymian-lee
Donate link: https://jaymian-lee.nl
Tags: ai content, chatgpt, blog automatisering, post generatie, blogpost ai
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.9.49
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Genereer en verfijn blogposts met AI. Kies een categorie, krijg onderwerp-ideeen, zet SEO-geoptimaliseerde posts met afbeeldingen in de wachtrij en plan het aanmaken in WordPress.

== Description ==

Publion is je persoonlijke content-assistent voor WordPress. Deze plugin is bedoeld voor bloggers, marketeers en ondernemers en laat je:

* Slimme onderwerpvoorstellen genereren voor een geselecteerde categorie, inclusief dynamische SEO-brief met focus-keyword, zoekintentie, invalshoek en FAQ-vragen.
* Handmatig een SEO- en GEO-geschikte hiërarchie van hoofd- en subcategorieën onderzoeken op basis van bestaande berichten, pagina’s en categorieën, met een gekozen doel, volledig ingevulde WordPress-velden, duidelijke reviewstatus en expliciete aanmaak per categorie of in veilige hiërarchische volgorde.
* Voor iedere AI-run een actuele contentkaart van bestaande berichten gebruiken en nieuwe, te vergelijkbare concepten blokkeren.
* Een content-wachtrij opbouwen en beheren.
* Automatisch volledige blogposts (concepten) maken met ChatGPT.
* 6 contextbewuste AI-afbeeldingen genereren (5 in de content en 1 uitgelichte afbeelding).
* Postcreatie plannen: dagelijks één of meerdere concepten, gespreid over een zelfgekozen tijdvenster, of één concept elke X dagen.
* "Nu maken" starten voor elk onderwerp in de wachtrij.
* Optioneel een CTA-blok aan het einde van elke post toevoegen.
* Schrijven voor mensen, Google en AI-zoekmachines: directe antwoorden, semantische kopstructuur, feitelijke bronverwijzingen, interne links en relevante alt-tekst.
* Een toegankelijke SEO/SEA/GEO-checklist in het dashboard voor review vóór publicatie of campagnegebruik.
* Optionele dynamische BlogPosting- en FAQ-structured data voor nieuwe Publion-artikelen, zonder dubbele articleschema's naast bekende SEO-plugins.
* De afbeeldingsafronding van alle Publion-afbeeldingen instellen; standaard 8px.
* Thema-vriendelijke artikelweergave: volg de bestaande themastijl of kies een verfijnde leesstijl met instelbare accentkleur, leesbreedte en eigen gescopede CSS.
* Actuele OpenAI-modelkeuze: GPT-5.6 Sol, Terra en Luna, GPT-5.4, Mini en Nano, met een gevalideerd veld voor een eigen model-ID.
* Afzonderlijke keuze voor GPT Image 2, eerdere afbeeldingsmodellen of een eigen afbeeldingsmodel-ID.
* API-sleutels worden na opslag niet meer in het instellingenformulier weergegeven; model- en API-fouten zijn duidelijker uitgelegd.
* Optionele Rank Math-integratie met dynamisch focus-keyword, metadata en een automatische heranalyse in de editor voor ieder Publion-artikel.
* Optioneel e-mailmeldingen ontvangen wanneer een nieuwe conceptpost is aangemaakt.

**Bespaar tijd. Blijf consistent. Laat je site groeien.**

== Installation ==

1. Upload de pluginmap naar de map '/wp-content/plugins/'.
2. Activeer de plugin via het menu "Plugins" in WordPress.
3. Ga naar **Publion** in je dashboard om te starten.
4. Vul je OpenAI API-sleutel in om AI-content te genereren.

== Frequently Asked Questions ==

= Heb ik een OpenAI-account nodig? =
Ja. Je hebt een OpenAI API-sleutel nodig om content te genereren.

= Publiceert deze plugin automatisch? =
Standaard maakt de plugin concepten (op schema of op aanvraag) zodat je ze handmatig kunt reviewen. Kies bij “Poststatus bij aanmaken” voor “Gepubliceerd” om geldige artikelen direct te publiceren.

= Kan ik direct een post maken zonder te wachten op het schema? =
Ja. Gebruik de knop **Nu maken** in de wachtrij.

= Waar komen de afbeeldingen vandaan? =
Publion genereert afbeeldingen met het gekozen OpenAI-afbeeldingsmodel. GPT Image 2 (`gpt-image-2`) is de standaard voor nieuwe installaties. Als genereren faalt, wordt een placeholder gebruikt zodat je die later kunt vervangen.

= Kan ik zelf een afbeeldingsmodel invullen? =
Ja. Kies **Eigen afbeeldingsmodel-ID…** onder OpenAI/ChatGPT instellingen en vul de exacte OpenAI API-model-ID in. Het model moet de Images API ondersteunen en beschikbaar zijn voor jouw API-project.

= Kan ik de afgeronde hoeken van afbeeldingen aanpassen? =
Ja. Ga naar **Instellingen voor postcreatie** en kies een waarde tussen 0 en 48px. Nieuwe en bestaande Publion-artikelen gebruiken standaard 8px.

= Kan ik zelf een OpenAI-model invullen? =
Ja. Kies **Eigen OpenAI model-ID…** onder OpenAI/ChatGPT instellingen en vul de exacte API-model-ID in. Publion controleert het formaat vooraf; OpenAI controleert vervolgens of dat model voor jouw API-project beschikbaar is.

= Garandeert Publion een positie in Google of AI-antwoorden? =
Nee. Publion maakt de inhoud technisch en redactioneel beter voorbereid, maar ranking hangt ook af van kwaliteit, autoriteit, concurrentie en technische SEO van de website.

= Ondersteunt dit custom post types? =
Deze versie maakt standaard blogposts aan.

== Screenshots ==

1. Genereer onderwerp-ideeen met AI.
2. Voeg geselecteerde onderwerpen toe aan de content-wachtrij.
3. Stel planning en CTA-instellingen in.
4. Maak automatisch volledige conceptposts met AI-afbeeldingen.

== Changelog ==

= 1.9.49 =
* Herstelt mislukte generaties met GPT-5-modellen: het uitvoerbudget houdt nu rekening met reasoning-tokens (minimaal 12.000, maximaal 32.000), zodat artikelen niet meer met finish_reason "length" worden afgebroken en geweigerd.
* Bij een bereikte tokenlimiet toont Publion nu een duidelijke melding en bewaart de laatste finish_reason en het tokengebruik (optie publion_last_openai_response_meta) voor diagnose.

= 1.9.48 =
* Registreert dashboard en diagnose na hetzelfde parentmenu en herstelt correcte admin.php?page= routes.


= 1.9.47 =
* Beveiligde publicatiegates, duurzame retries en locks, herbruikbare afbeeldingen en transparante bronbeoordeling. Zie RELEASE-1.9.47.md in de repository voor tests en rollout.


= 1.9.46 =
* Herstelt automatische publicatie: handmatige en geplande creatie normaliseren de gekozen poststatus, verifiëren de status die WordPress werkelijk opslaat en proberen “Gepubliceerd” één keer opnieuw via de reguliere WordPress-API toe te passen.
* De wachtrij kan een concept niet langer ten onrechte als gepubliceerd markeren. Als een externe plugin of hook publicatie blijft blokkeren, blijft de post correct als aangemaakt geregistreerd en staat er een gerichte fout in de WordPress error log.

= 1.9.45 =
* Afbeeldingen worden uitsluitend nog tussen de echte artikelonderdelen geplaatst. Toegevoegde secties voor externe bronnen en live brononderzoek zijn uitgesloten, zodat afbeeldingen daar niet meer kunnen clusteren.

= 1.9.44 =
* De keuze “Gepubliceerd” is nu leidend voor handmatige én geplande postcreatie. De optionele Rank Math-conceptblokkade kan deze keuze niet langer stil naar een concept terugzetten.

= 1.9.43 =
* Voegt een veilige knop “Verbinding testen” toe aan de OpenAI-instellingen. Deze controleert de API-sleutel en de beschikbaarheid van de gekozen tekst- en afbeeldingsmodellen, zonder content of afbeeldingen te genereren.

= 1.9.42 =
* Herstelt de algemene admin-initialisatie. De exacte model-ID blijft bij een keuze uit de lijst zichtbaar en wisselt mee met de dropdown, zonder de overige navigatie of knoppen te beïnvloeden.

= 1.9.41 =
* De zichtbare exacte tekst- en afbeeldingsmodel-ID volgt nu direct de modelkeuze in het instellingenformulier. Een lijstmodel is alleen-lezen; een eigen model-ID blijft bewerkbaar.
* Live brononderzoek gebruikt altijd de opgeslagen tekstmodelkeuze. De afbeeldingskeuze bevat nu ook GPT Image 2.5 Sunburst en Flare.

= 1.9.40 =
* De automatische postplanning kan de wachtrij nu ook automatisch aanvullen met unieke AI-onderwerpen. De onderwerpaanvulling volgt dezelfde frequentie als de postplanning en maakt bij meerdere dagelijkse posts evenveel onderwerpen aan.

= 1.9.39 =
* Publion voegt alleen nog gevalideerde media-afbeeldingen in de artikelinhoud in. Mislukte generatie of een fallback geeft geen kapot afbeeldingsicoon meer; bestaande kapotte Publion-afbeeldingen worden op de pagina veilig verborgen.

= 1.9.38 =
* Publion plaatst geen reacties. Reacties en pingbacks staan nu bovendien hard uit voor alle artikelen die vanuit de Publion-wachtrij zijn gemaakt, ook bij oudere artikelen.

= 1.9.37 =
* De zichtbare kwaliteitsworkflow heet voortaan SEO/GEO-kwaliteit; de technische SEO-plugincompatibiliteit blijft op de achtergrond werken.

= 1.9.36 =
* Rank Math-contentcontrole is nu per onderdeel instelbaar: woorddoel, keyworddichtheid, maximale alinealengte, herstelronde, veilige conceptblokkade, inhoudsopgave, alt-tekst en linkreview.

= 1.9.35 =
* De volledige Basis SEO- en Extra-checklist van Rank Math is nu in beide aanmaakroutes verwerkt: SEO-titel en -omschrijving, URL, eerste alinea, inhoud, tussenkop, dichtheid, lengte, korte alinea’s, afbeeldingen/alt-tekst, inhoudsopgave en links.
* Ook “Nu maken” volgt voortaan dezelfde definitieve kwaliteitsgrens als de planning: onvolledige harde checks kunnen nooit per ongeluk als gepubliceerd bericht worden opgeslagen.
* De focus-keyword staat expliciet in de eerste alinea; de SEO-titel start met het keyword en bevat een passend power word. Een getal blijft zichtbaar als optionele, uitsluitend feitelijke titelkeuze.
* De Rank Math-meta description wordt ook als WordPress-samenvatting opgeslagen, zodat de gecontroleerde keywordomschrijving beschikbaar blijft als een site-template daarop terugvalt.

= 1.9.34 =
* Rank Math-integratie heeft nu een daadwerkelijke kwaliteitscontrole vóór het opslaan: focus-keyword, titel/meta/URL, intro, tussenkop, dichtheid, lengte en alinea’s worden gecontroleerd.
* Bij een harde inhoudsafwijking voert Publion één feitelijke herstelronde uit. Blijft een harde check openstaan, dan wordt een gekozen publicatie veilig teruggezet naar Concept.
* Elk Publion-artikel toont in de WordPress-editor een Rank Math-controlepaneel met woordenaantal, keyworddichtheid, geslaagde checks en redactionele aandachtspunten voor links, media en titel.

= 1.9.33 =
* De instellingen voor postcreatie zijn opnieuw ingedeeld in duidelijke workflowblokken: planning, onderwerpen en categorieën, bronnen, SEO en opvolging.
* Kies dagelijks één of meerdere posts (maximaal acht) en laat Publion ze vanaf de eerste aanmaaktijd over een aantal uren spreiden. De wachtrij blijft veilig één artikel tegelijk verwerken.
* De instellingen bevatten nu een directe verwijzing naar de aparte Categorie-strategie voor het handmatig genereren en controleren van SEO- en GEO-geschikte hoofd- en subcategorieën.

= 1.9.32 =
* Categorie-strategie heeft nu een eigen tab in Publion. Content plannen is daardoor uitsluitend gericht op artikelonderwerpen en SEO-briefs.
* Categorie-acties en herstelknoppen sturen direct terug naar de aparte Categorie-strategie-tab.

= 1.9.31 =
* De Categorie-strategie is uitgewerkt als toegankelijke driestaps-review: onderzoek, beoordeling en veilige aanmaak. Elke kaart toont een status en subcategorieën wachten zichtbaar op de benodigde hoofdcategorie.
* Voeg een volledig beoordeelde hiërarchie desgewenst in één bevestigde actie toe. Publion werkt dan altijd eerst de hoofdcategorieën af en daarna de subcategorieën; bij een fout blijft duidelijk wat wel en niet is aangemaakt.
* Nieuwe categorieën krijgen directe links naar Bewerken in WordPress en naar het categoriearchief. Slugconflicten, een subcategorie als ouder en WordPress-fouten worden expliciet geblokkeerd of gemeld.
* De focus-keywordcontrole is aangescherpt: het focus-keyword moet natuurlijk terugkomen in de categorieomschrijving, SEO-titel en meta description.

= 1.9.30 =
* Categorie-strategie maakt nu een echte hiërarchie van hoofd- en subcategorieën. Maak eerst een hoofdcategorie en daarna de gekoppelde subcategorie; Publion bewaakt deze relatie.
* Elk voorstel vult de WordPress-velden naam, SEO-slug, hoofdcategorie en unieke categorieomschrijving, plus focus-keyword, SEO-titel, meta description en GEO-samenvatting.
* Als Rank Math actief is, bewaart Publion de SEO-titel, meta description en focus-keyword ook als categorie-meta voor de categoriearchiefpagina.

= 1.9.29 =
* Nieuwe handmatige Categorie-strategie in Content plannen: Publion analyseert de bestaande contentkaart en taxonomie om vijf passende hoofdcategorieën voor te stellen.
* Kies een informatief, commercieel, transactioneel of gemengd doel, controleer per voorstel de onderbouwing en drie toekomstige artikelkansen, en maak alleen de afzonderlijk goedgekeurde categorie in WordPress aan.
* Nieuwe categorieën worden nooit automatisch ingepland, worden als top-level categorie gemaakt en staan direct klaar voor de bestaande onderwerpworkflow.

= 1.9.28 =
* De melding over een afgewezen of mislukte afbeeldingsgeneratie heeft nu een toegankelijke sluitknop met kruisje.

= 1.9.27 =
* De centrale schrijfinstructie heet overal Publion-prompt, met heldere uitleg over doelgroep, expertise, gewenste bronnen en redactionele grenzen.
* Opslaan, herstellen, foutmeldingen, de ingebouwde handleiding en de GitHub-README gebruiken dezelfde herkenbare Publion-benaming.

= 1.9.26 =
* Afbeeldingsprompts die door de OpenAI-veiligheidscontrole worden geblokkeerd, krijgen één aangepaste neutrale herpoging zonder geweld, dreiging, personen of merknamen.
* Na een tweede blokkade gebruikt Publion veilig een placeholder en toont het een begrijpelijke melding zonder technische API-tekst of sleutelinformatie.

= 1.9.25 =
* Publion staat nu als zelfstandig hoofdmenu-item in het WordPress-beheermenu, in plaats van onder Berichten.

= 1.9.24 =
* De uitgebreide Rank Math-workflow bereidt nieuwe artikelen voor op de officiële contenttests: unieke focus-keyword, keyword-led metadata, korte URL, intro, koppen, relevante links, inhoudsopgave, vier of meer afbeeldingen en korte alinea's.
* Bij ingeschakelde Rank Math-integratie vraagt Publion circa 2.500 tot 2.800 woorden voor de volledige lengtescore; dit kan meer generatietijd en API-tegoed vragen.
* Geen gegarandeerde score of ranking: Publion verwerkt controleerbare voorwaarden, terwijl Rank Math de daadwerkelijke score en de redacteur de inhoudelijke kwaliteit bepaalt.

= 1.9.23 =
* Wanneer je een Publion-artikel in de WordPress-editor opent, vraagt Publion Rank Math automatisch om de eigen titel- en contentanalyse opnieuw uit te voeren.
* De zichtbare score blijft uitsluitend de echte Rank Math-score; Publion berekent, bewaart of simuleert geen score op de achtergrond.

= 1.9.22 =
* Nieuwe artikelen gebruiken de inhoudelijke Rank Math-feedback: focus-keyword in de introductie en koppen, een korte keyword-URL en complete metadata.
* Een uitgaande dofollow-bronlink wordt alleen gebruikt wanneer een gecontroleerde vaste bron of Live brononderzoek beschikbaar is; Publion verzint geen bronlink om een score te manipuleren.
* Titelnummers en â€˜power wordsâ€™ blijven redactionele keuzes en worden niet blind geforceerd.

= 1.9.21 =
* Nieuwe optionele Live brononderzoek-instelling zoekt met de OpenAI Responses API actuele externe bronnen vÃ³Ã³r de artikelgeneratie.
* Beheerders kunnen model, aantal bronnen, onderzoeksdiepte, live toegang, domeinfilters, zichtbare bronnenlijst en foutgedrag instellen.
* Alleen werkelijk door de webzoekactie teruggegeven HTTPS-bronnen worden aan het artikel gekoppeld; bij verplichte research zonder bruikbare bronnen wordt de generatie veilig gestopt.

= 1.9.20 =
* De bulkstatus toont nu tijdens het genereren het actuele batchnummer, bijvoorbeeld: â€œItem 2 van 4 wordt verwerkt.â€

= 1.9.19 =
* Betrouwbare externe links blijven behouden wanneer een bron een HEAD-controle blokkeert; Publion probeert dan veilig een kleine GET-controle voordat een link als kapot wordt aangemerkt.
* Geverifieerde bron-URL's uit de instellingen worden nu hard en veilig toegepast: zodra er geen dergelijke bron in de AI-tekst staat, voegt Publion precies Ã©Ã©n ingestelde HTTPS-bron toe.
* De instellingen maken expliciet dat Publion nooit een bron-URL verzint. Voeg minstens Ã©Ã©n relevante bron-URL toe om een externe link per artikel te garanderen.

= 1.9.18 =
* Herstelt een race condition waardoor één wachtrij-item soms meerdere posts kon aanmaken.
* Elke generatie claimt nu atomair het wachtrij-item en gebruikt daarnaast een gedeelde titel-lock voor handmatige generatie en WP-Cron.
* Extra duplicaatcontrole direct vóór het opslaan blokkeert een tweede, vergelijkbare post als een andere workflow intussen al iets heeft aangemaakt.

= 1.9.17 =
* Live voortgang is monotone: een vertraagde oudere serverreactie kan het percentage niet meer terugzetten.
* Tijdens een generatie toont Publion een realistische bandbreedte voor de totale duur. Na minimaal drie geslaagde runs gebruikt die schatting de eigen, gemeten doorlooptijden van de site.

= 1.9.16 =
* Nieuwe actie Geschiedenis wissen bij Aangemaakte posts, met een expliciete bevestiging.
* Wist uitsluitend Publion-wachtrijgeschiedenis; WordPress-posts, concepten en media blijven behouden.

= 1.9.15 =
* De rode annuleerknop is nu strikt verborgen zolang er geen actieve artikelgeneratie loopt.

= 1.9.14 =
* Herstelt een fout waarbij een zichtbaar geselecteerd onderwerp zonder titel of categorie naar de server kon worden verstuurd.
* De wachtrij leest onderwerp, categorie en SEO-brief nu rechtstreeks uit de betrouwbare rijdata en valideert incomplete rijen al vóór het opslaan.

= 1.9.13 =
* Alle globale meldingen en foutpanelen hebben nu een toegankelijke sluitknop met kruisje.
* Sluiten verbergt alleen de melding; wachtrijgegevens, foutreferenties in de logs en de lopende actie blijven intact.

= 1.9.12 =
* Herstelt onnodige cURL 28-time-outs bij lange artikelgeneratie: tekst-, beeld- en keywordaanvragen krijgen passende time-outs.
* Tijdelijke transportfouten en serverfouten krijgen één begrensde retry met korte back-off; sleutel-, model- en tegoedfouten worden niet opnieuw verstuurd.
* Grote contentkaarten behouden alle titels en koppen, maar gebruiken compactere inhoudsextracten voor een betrouwbaardere API-aanvraag.
* Time-outmeldingen zijn nu menselijk leesbaar en tonen geen ruwe cURL-details of gevoelige gegevens.

= 1.9.11 =
* De live voortgang staat nu compact in de knop zelf; de losse voortgangskaart onder de knop is verwijderd.
* Tijdens artikelgeneratie verschijnt een toegankelijke annuleerknop met kruisje naast de voortgangsknop.
* Annuleren stopt de workflow bij een veilig servermoment, zonder het wachtrij-item te verwijderen of een half artikel als afgerond op te slaan.

= 1.9.10 =
* Herstelt een opslagfout waarbij geldige geselecteerde onderwerpkaarten op sommige PHP/FastCGI-servers als een lege wachtrij konden aankomen.
* Wachtrijgegevens gebruiken nu een expliciet JSON-contract met veilige fallback voor bestaande browsersessies.
* Bij een echte validatiefout toont Publion per afgekeurd onderwerp de concrete titel- of categoriereden.

= 1.9.9 =
* Uitgebreide foutafhandeling voor onderwerpvoorstellen, wachtrij, planning, instellingen, modellen, prompt en postcreatie.
* Elke actuele fout bevat een veilige oorzaak, concrete vervolgstap, relevante knop en foutreferentie voor ondersteuning; API-sleutels worden uit foutteksten verwijderd.
* Bulkacties tonen een volledig eindoverzicht per mislukt onderwerp in plaats van alleen een nummer van het mislukte item.

= 1.9.8 =
* Publion volgt nu automatisch de WordPress-site- en gebruikerstalen: de beheerinterface heeft een Engelse basiscatalogus en kan worden uitgebreid met standaard WordPress-taalpakketten.
* Nieuwe onderwerpvoorstellen en artikelen volgen de WordPress-sitetaal, terwijl de persoonlijke beheertaal veilig alleen de interface beïnvloedt.
* Browsermeldingen, live voortgang en bevestigingsvensters gebruiken dezelfde vertaallaag als de PHP-interface.

= 1.9.7 =
* De dashboardhandleiding staat nu als volledige, gestructureerde tekst in de tab Handleiding & diagnose. De losse Markdown-handleiding is verwijderd.

= 1.9.6 =
* De gebundelde PDF-handleiding is volledig herschreven: installatie, modellen, onderwerpvalidatie, postcreatie, SEO/SEA/GEO, styling, analytics, diagnose, privacy en review.

= 1.9.5 =
* Onderwerpvoorstellen accepteren alleen vijf complete, gevalideerde SEO-briefs; JSON-fragmenten, losse velden en onvolledige antwoorden worden niet getoond of opgeslagen.
* De OpenAI-fallback houdt JSON-modus actief wanneer Structured Outputs niet beschikbaar is.
* De browser valideert ontvangen voorstellen opnieuw als extra bescherming tegen oude caches en gemanipuleerde responses.

= 1.9.4 =
* New articles use semantic image blocks in an intentional 16:9 and 1:1 rhythm; old float styles are no longer written into content.
* The configurable image radius is enforced against theme image selectors.
* Article generation uses one complete, strictly structured HTML response to prevent incomplete lists and repeated continuation text.
* Meta descriptions finish at a readable word or sentence boundary.
* Publion skips its own BlogPosting schema when Rank Math, Yoast, or All in One SEO is active, preventing duplicate article schema.

= 1.9.3 =
* “Nu maken” toont live, servergestuurde voortgang per artikel: onderzoek, tekst, afbeeldingen, SEO, opslaan en afronden.
* De voortgang is een feitelijke workflowstatus met percentage per voltooid checkpoint, inclusief een duidelijke foutstatus.

= 1.9.2 =
* Onderwerpvoorstellen gebruiken strikt gestructureerde JSON-uitvoer. Onvolledige AI-antwoorden kunnen niet langer als losse, foutieve onderwerpkaarten verschijnen.
* Het uitvoerbudget voor onderwerpvoorstellen is verhoogd en een duidelijke herstelmelding verschijnt bij een afgebroken respons.

= 1.9.1 =
* Verpakking gecorrigeerd voor WordPress: het importpakket bevat nu exact één `publion` pluginmap.
* Bootstrap en alle PHP-bestanden opnieuw gecontroleerd op syntax en veilig laden.

= 1.9.0 =
* Nieuwe afzonderlijke afbeeldingsmodelkiezer met GPT Image 2 als standaard, GPT Image 1.5, GPT Image 1 en een eigen model-ID.
* Afbeeldingsfouten tonen nu ook het modelgerelateerde OpenAI-antwoord veilig in het dashboard.

= 1.8.0 =
* Onderwerp- en artikelgeneratie lezen nu eerst een actuele contentkaart van bestaande WordPress-berichten.
* Dubbele of sterk vergelijkbare titels en inhoud worden lokaal geblokkeerd vóór er een WordPress-concept wordt aangemaakt.
* De handleiding legt de contentkaart, foutmelding en noodzakelijke redactionele controle uit.

= 1.7.0 =
* De modelkiezer bevat GPT-5.6 Sol, Terra en Luna, GPT-5.4, GPT-5.4 Mini en GPT-5.4 Nano naast eerdere modellen.
* Beheerders kunnen een eigen, gevalideerde OpenAI model-ID opslaan.
* De API-sleutel wordt na opslag niet opnieuw in het dashboard getoond en AI-fouten melden nu concreet wat er gecontroleerd moet worden.

= 1.6.0 =
* Verbeterde alt-teksten voor content- en media-afbeeldingen, zonder keyword stuffing.
* Nieuwe toetsenbordtoegankelijke SEO/SEA/GEO-checkmodal met concrete publicatie- en landingspagina-controles.
* Schrijfinstructies aangescherpt voor directe antwoorden, controleerbare feiten en eerlijke commerciële content.

= 1.5.0 =
* Nieuwe thema-vriendelijke artikelstijl: thema volgen of een verfijnde Publion-leesstijl.
* Instelbare accentkleur, maximale leesbreedte en veilig verwerkt Custom CSS voor Publion-artikelen.
* Gebruikers- en GitHub-documentatie uitgebreid met vormgeving, reviewflow en diagnose-informatie.

= 1.4.0 =
* Nieuw operationeel dashboard met wachtrij-, concept-, plannings- en 30-dagenstatus.
* Duidelijke volgende acties, contextuele foutmeldingen en een praktische diagnosehandleiding in de plugin.
* Directe, optionele snelkoppelingen naar de eigen Google Search Console- en Google Analytics-rapporten.
* Instellingen voor structured data en afbeeldingsafronding worden nu volledig opgeslagen vanuit de interface.

= 1.3.0 =
* Vernieuwde, rustigere admininterface met duidelijke SEO-briefs per onderwerp.
* Onderwerpgeneratie levert nu focus-keyword, zoekintentie, invalshoek en FAQ-vragen als dynamische data.
* Artikelen worden aangestuurd op behulpzame, feitelijke en AI-citeerbare content in plaats van keyword stuffing.
* Optionele BlogPosting- en FAQ-structured data op basis van de uiteindelijke post.
* 8px afbeeldingsafronding als standaard, instelbaar van 0 tot 48px.

= 1.0.0 =
* Eerste release met AI-onderwerpvoorstellen, wachtrijbeheer, geplande postcreatie (concepten), AI-afbeeldingen met placeholders, actie "Nu maken", optionele CTA en e-mailmeldingen.

== Upgrade Notice ==

= 1.0.0 =
Eerste release - genereer AI-gedreven conceptposts volgens planning en keur ze goed in je workflow.

== Credits ==

Afbeeldingen in posts worden gegenereerd met het gekozen OpenAI-afbeeldingsmodel (standaard: GPT Image 2).
AI-content wordt gegenereerd met OpenAI (ChatGPT).
Plugin ontwikkeld door Jaymian-Lee.
