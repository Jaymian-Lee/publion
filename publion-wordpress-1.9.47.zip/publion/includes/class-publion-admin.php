<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Publion_Admin {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_rank_math_content_refresh' ], 100 );
        add_action( 'admin_init', [ $this, 'handle_form_submissions' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_styles' ] );
        add_filter( 'post_class', [ $this, 'add_generated_post_class' ], 10, 3 );
        add_filter( 'post_thumbnail_html', [ $this, 'add_generated_thumbnail_class' ], 10, 5 );
        add_action( 'wp_head', [ $this, 'output_structured_data' ], 20 );
        add_action( 'add_meta_boxes_post', [ $this, 'add_rank_math_quality_meta_box' ], 10, 1 );
    }

    public function add_admin_menu() {
        add_menu_page(
            __( 'Publion', 'publion' ),
            __( 'Publion', 'publion' ),
            'manage_options',
            'publion',
            [ $this, 'render_admin_page' ],
            'dashicons-welcome-write-blog',
            26
        );
    }

    public function add_rank_math_quality_meta_box( $post ) {
        if ( ! $post instanceof WP_Post || ! get_post_meta( $post->ID, '_publion_rank_math_quality_report', true ) ) {
            return;
        }
        add_meta_box(
            'publion-rank-math-quality',
            __( 'Publion SEO/GEO-controle', 'publion' ),
            [ $this, 'render_rank_math_quality_meta_box' ],
            'post',
            'side',
            'high'
        );
    }

    public function render_rank_math_quality_meta_box( $post ) {
        if ( ! $post instanceof WP_Post || ! current_user_can( 'edit_post', $post->ID ) ) {
            return;
        }

        $raw_report = get_post_meta( $post->ID, '_publion_rank_math_quality_report', true );
        $report     = is_string( $raw_report ) ? json_decode( $raw_report, true ) : $raw_report;
        if ( ! is_array( $report ) || empty( $report['checks'] ) ) {
            echo '<p>' . esc_html__( 'Dit bericht is niet door Publion met de uitgebreide SEO/GEO-controle aangemaakt.', 'publion' ) . '</p>';
            return;
        }

        $status          = sanitize_key( $report['status'] ?? 'review_required' );
        $status_label    = 'ready' === $status ? __( 'Klaar voor redactionele controle', 'publion' ) : __( 'Extra controle nodig', 'publion' );
        $status_class    = 'ready' === $status ? 'publion-quality-ready' : 'publion-quality-review';
        $checks          = (array) $report['checks'];
        $failed_required = (array) ( $report['failed_required'] ?? array() );
        $advisories      = (array) ( $report['needs_editor_review'] ?? array() );
        $labels = array(
            'focus_keyword_in_seo_title' => __( 'Focus-keyword vroeg in SEO-titel', 'publion' ),
            'focus_keyword_in_meta_description' => __( 'Focus-keyword in SEO-meta description', 'publion' ),
            'focus_keyword_in_url'       => __( 'Focus-keyword in URL', 'publion' ),
            'focus_keyword_in_intro'     => __( 'Focus-keyword in intro', 'publion' ),
            'focus_keyword_in_content'   => __( 'Focus-keyword in inhoud', 'publion' ),
            'focus_keyword_in_heading'   => __( 'Focus-keyword in tussenkop', 'publion' ),
            'focus_keyword_density'      => __( 'Keyworddichtheid 1–1,5%', 'publion' ),
            'content_length'             => __( 'Minimaal 2.500 woorden', 'publion' ),
            'short_paragraphs'           => __( 'Alinea’s korter dan 120 woorden', 'publion' ),
            'table_of_contents'          => __( 'Inhoudsopgave', 'publion' ),
            'media_count'                => __( 'Minimaal vier afbeeldingen of video’s', 'publion' ),
            'focus_keyword_in_image_alt' => __( 'Focus-keyword in afbeeldings-alttekst', 'publion' ),
            'external_link'              => __( 'Externe gegevensbron', 'publion' ),
            'followed_external_link'     => __( 'Gevolgde externe bronlink', 'publion' ),
            'internal_link'              => __( 'Relevante interne link', 'publion' ),
            'short_url'                  => __( 'Korte URL (max. 75 tekens)', 'publion' ),
            'number_in_seo_title'        => __( 'Feitelijk getal in SEO-titel', 'publion' ),
            'power_word_in_seo_title'    => __( 'Passend power word in SEO-titel', 'publion' ),
            'sentiment_in_seo_title'     => __( 'Passend sentiment in SEO-titel', 'publion' ),
        );

        echo '<p><strong class="' . esc_attr( $status_class ) . '">' . esc_html( $status_label ) . '</strong></p>';
        echo '<p>' . esc_html( sprintf( __( '%1$d woorden · %2$s%% keyworddichtheid', 'publion' ), (int) ( $report['word_count'] ?? 0 ), number_format_i18n( (float) ( $report['keyword_density'] ?? 0 ), 2 ) ) ) . '</p>';
        echo '<ul class="publion-quality-checks">';
        foreach ( $labels as $check => $label ) {
            $is_optional = ( 'number_in_seo_title' === $check );
            $passed      = ! empty( $checks[ $check ] );
            $class       = $passed ? 'is-passed' : ( $is_optional ? 'is-optional' : 'is-pending' );
            $icon        = $passed ? '&#10003;' : ( $is_optional ? '&ndash;' : '&#10007;' );
            echo '<li class="' . esc_attr( $class ) . '"><span aria-hidden="true">' . $icon . '</span> ' . esc_html( $label ) . ( $is_optional ? ' <em>' . esc_html__( '(alleen als feitelijk)', 'publion' ) . '</em>' : '' ) . '</li>';
        }
        echo '</ul>';
        if ( ! empty( $failed_required ) ) {
            echo '<p><strong>' . esc_html__( 'Voor publicatie herstellen:', 'publion' ) . '</strong></p><ul>';
            foreach ( $failed_required as $check ) {
                echo '<li>' . esc_html( $labels[ $check ] ?? $check ) . '</li>';
            }
            echo '</ul>';
        }
        if ( ! empty( $advisories ) ) {
            echo '<p><strong>' . esc_html__( 'Controleer redactioneel:', 'publion' ) . '</strong></p><ul>';
            foreach ( $advisories as $check ) {
                echo '<li>' . esc_html( $labels[ $check ] ?? $check ) . '</li>';
            }
            echo '</ul>';
        }
        echo '<p class="description">' . esc_html__( 'Publion vervangt geen feitelijke controle. Ontbrekende relevante interne/externe links of een misleidende titel worden bewust niet gefabriceerd voor een score.', 'publion' ) . '</p>';
    }

    public function enqueue_assets( $hook ) {
        $is_publion_page = ( $hook === 'toplevel_page_publion' );
        if ( ! $is_publion_page ) {
            $page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
            $is_publion_page = ( $page === 'publion' );
        }
        $is_post_editor = in_array( $hook, array( 'post.php', 'post-new.php' ), true );
        if ( ! $is_publion_page && ! $is_post_editor ) {
            return;
        }

        $css_version = file_exists( PUBLION_PATH . 'assets/admin.css' ) ? filemtime( PUBLION_PATH . 'assets/admin.css' ) : PUBLION_VERSION;
        wp_enqueue_style( 'publion-style', PUBLION_URL . 'assets/admin.css', [], $css_version );

        if ( ! $is_publion_page ) {
            return;
        }

        $js_version  = file_exists( PUBLION_PATH . 'assets/admin.js' ) ? filemtime( PUBLION_PATH . 'assets/admin.js' ) : PUBLION_VERSION;
        wp_enqueue_script( 'publion-script', PUBLION_URL . 'assets/admin.js', [ 'jquery' ], $js_version, true );

        // Localize a reusable nonce for all AJAX requests that call check_ajax_referer( 'publion_nonce', 'nonce' ).
        wp_localize_script(
            'publion-script',
            'Publion',
            [
                'ajax_url'    => admin_url( 'admin-ajax.php' ),
                'nonce'       => wp_create_nonce( 'publion_nonce' ),
                'has_api_key' => ! empty( get_option( 'publion_api_key' ) ),
                'locale'      => determine_locale(),
                // JavaScript messages must be passed through WordPress here;
                // PHP gettext calls do not automatically translate browser code.
                'i18n'        => [
                    'action_required'             => __( 'Actie nodig', 'publion' ),
                    'attention'                   => __( 'Let op', 'publion' ),
                    'success'                     => __( 'Gelukt', 'publion' ),
                    'no_valid_suggestions'        => __( 'Geen volledig gevalideerde onderwerpvoorstellen ontvangen. Er is niets opgeslagen. Vernieuw de voorstellen; blijft dit gebeuren, kies een ondersteund model of controleer de Publion-prompt.', 'publion' ),
                    'add'                         => __( 'Toevoegen', 'publion' ),
                    'remove'                      => __( 'Verwijderen', 'publion' ),
                    'removing'                    => __( 'Verwijderen…', 'publion' ),
                    'focus'                       => __( 'Focus', 'publion' ),
                    'intent'                      => __( 'Intentie', 'publion' ),
                    'faq'                         => __( 'FAQ', 'publion' ),
                    'informational'               => __( 'informatief', 'publion' ),
                    'no_valid_category_suggestions' => __( 'Geen volledig gevalideerde categorievoorstellen ontvangen. Er is niets aangemaakt; probeer het opnieuw.', 'publion' ),
                    'category_suggestions_failed' => __( 'Categorievoorstellen konden niet worden gemaakt. Controleer je API-sleutel en probeer opnieuw.', 'publion' ),
                    'create_category'             => __( 'Categorie aanmaken', 'publion' ),
                    'creating_category'           => __( 'Categorie wordt aangemaakt…', 'publion' ),
                    'category_created'            => __( 'Categorie aangemaakt', 'publion' ),
                    'category_created_message'    => __( 'Categorie aangemaakt. Je kunt er nu onderwerpen voor plannen.', 'publion' ),
                    'create_category_failed'      => __( 'De categorie kon niet worden aangemaakt. Vernieuw de pagina en probeer opnieuw.', 'publion' ),
                    'example_articles'            => __( 'Mogelijke artikelen', 'publion' ),
                    'main_category'               => __( 'Hoofdcategorie', 'publion' ),
                    'sub_category'                => __( 'Subcategorie', 'publion' ),
                    'parent_category'             => __( 'Hoofdcategorie', 'publion' ),
                    'slug'                        => __( 'Slug', 'publion' ),
                    'seo_title'                   => __( 'SEO-titel', 'publion' ),
                    'meta_description'            => __( 'Meta description', 'publion' ),
                    'geo_summary'                 => __( 'GEO-samenvatting', 'publion' ),
                    'category_ready'              => __( 'Klaar om aan te maken', 'publion' ),
                    'category_waiting_for_parent' => __( 'Wacht op hoofdcategorie: %s', 'publion' ),
                    'category_created_status'     => __( 'Aangemaakt', 'publion' ),
                    'category_results_status'     => __( '%d van %d categorieën aangemaakt.', 'publion' ),
                    'create_hierarchy'            => __( 'Volledige hiërarchie aanmaken', 'publion' ),
                    'creating_hierarchy'          => __( 'Hiërarchie wordt aangemaakt…', 'publion' ),
                    'create_hierarchy_confirm'    => __( 'Wil je alle getoonde categorieën aanmaken? Publion maakt eerst hoofdcategorieën en daarna subcategorieën. Bestaande categorieën worden niet gewijzigd.', 'publion' ),
                    'hierarchy_created'           => __( 'Categoriehiërarchie aangemaakt. Controleer daarna de categoriepagina’s en voeg interne links toe.', 'publion' ),
                    'hierarchy_stopped'           => __( 'De hiërarchie is gestopt bij een categorie die aandacht nodig heeft. Eerder aangemaakte categorieën blijven bestaan.', 'publion' ),
                    'clear_category_suggestions'  => __( 'Voorstellen wissen', 'publion' ),
                    'edit_category'               => __( 'Bewerk in WordPress', 'publion' ),
                    'view_category'               => __( 'Bekijk categorie', 'publion' ),
                    'wordpress_fields'            => __( 'WordPress-velden', 'publion' ),
                    'strategy_reason'             => __( 'Waarom deze categorie', 'publion' ),
                    'select_category_first'       => __( 'Selecteer eerst een categorie om relevante onderwerpvoorstellen te maken.', 'publion' ),
                    'refresh_failed'              => __( 'Vernieuwen van voorstellen mislukt. Controleer je API-sleutel en probeer opnieuw.', 'publion' ),
                    'connection_interrupted'       => __( 'De verbinding met WordPress of OpenAI is onderbroken. Controleer je internetverbinding en probeer opnieuw.', 'publion' ),
                    'suggestions_failed'          => __( 'Kon geen onderwerpvoorstellen ophalen. Controleer je API-sleutel en model in AI-instellingen.', 'publion' ),
                    'request_failed'              => __( 'De aanvraag kon niet worden verstuurd. Controleer de verbinding en probeer opnieuw.', 'publion' ),
                    'select_topic_first'          => __( 'Kies eerst minstens één onderwerp voordat je de wachtrij opslaat.', 'publion' ),
                    'unknown_topic'               => __( 'Een geselecteerd onderwerp', 'publion' ),
                    'queue_item_incomplete'       => __( 'Een geselecteerd onderwerp mist verplichte gegevens. Verwijder het onderwerp en voeg de voorstelkaart opnieuw toe.', 'publion' ),
                    'added_to_queue'              => __( 'Toegevoegd aan de wachtrij voor postcreatie!', 'publion' ),
                    'selected_added_to_queue'     => __( 'De geselecteerde onderwerpen staan nu in de wachtrij.', 'publion' ),
                    'save_failed'                 => __( 'Opslaan mislukt.', 'publion' ),
                    'ajax_error'                  => __( 'AJAX-fout.', 'publion' ),
                    'api_key_needed'              => __( 'Voeg een OpenAI API-sleutel toe om met onderwerpen, artikelen en afbeeldingen te werken.', 'publion' ),
                    'saved'                       => __( 'Opgeslagen!', 'publion' ),
                    'not_scheduled'               => __( 'Niet gepland', 'publion' ),
                    'keep_current_key'            => __( 'Laat dit veld leeg om de huidige sleutel te behouden.', 'publion' ),
                    'model_saved'                 => __( 'Model opgeslagen.', 'publion' ),
                    'image_model_saved'           => __( 'Afbeeldingsmodel opgeslagen.', 'publion' ),
                    'network_save_failed'         => __( 'Opslaan mislukt door een netwerkfout.', 'publion' ),
                    'items_load_failed'           => __( 'Items laden mislukt.', 'publion' ),
                    'working'                     => __( 'Bezig', 'publion' ),
                    'server_processing'           => __( 'De server verwerkt deze stap.', 'publion' ),
                    'percent'                     => __( 'procent', 'publion' ),
                    'create_now_confirm'          => __( 'Wil je nu een blogpost maken voor dit onderwerp? De knop toont de echte stappen op de server.', 'publion' ),
                    'request_sent'                => __( 'Aanvraag verstuurd', 'publion' ),
                    'request_started'             => __( 'Aanvraag gestart', 'publion' ),
                    'waiting_server'              => __( 'Publion wacht op de eerste serverbevestiging.', 'publion' ),
                    'complete'                    => __( 'Klaar', 'publion' ),
                    'draft_ready'                 => __( 'Het artikelconcept is aangemaakt en staat klaar voor controle.', 'publion' ),
                    'post_created'                => __( 'Post succesvol aangemaakt. De wachtrij wordt bijgewerkt.', 'publion' ),
                    'clear_history_confirm'       => __( 'Wil je de volledige Publion-geschiedenis van aangemaakte posts wissen? De originele WordPress-posts blijven behouden.', 'publion' ),
                    'clear_history_success'       => __( 'De Publion-geschiedenis is gewist. Je WordPress-posts zijn niet verwijderd.', 'publion' ),
                    'clear_history_failed'        => __( 'De Publion-geschiedenis kon niet worden gewist. Er is niets verwijderd.', 'publion' ),
                    'clear_history'               => __( 'Geschiedenis wissen', 'publion' ),
                    'clearing_history'            => __( 'Geschiedenis wissen…', 'publion' ),
                    'history_cleared'             => __( 'Geschiedenis gewist', 'publion' ),
                    'estimated_generation_time'   => __( 'Verwachte generatietijd', 'publion' ),
                    'minutes_short'               => __( 'min.', 'publion' ),
                    'estimate_learning'           => __( 'wordt nauwkeuriger na voltooide generaties', 'publion' ),
                    'estimate_based_on'           => __( 'op basis van eerdere generaties', 'publion' ),
                    'create_failed'               => __( 'Post aanmaken mislukt. Controleer de getoonde voortgang en probeer opnieuw.', 'publion' ),
                    'creation_failed'             => __( 'Maken mislukt', 'publion' ),
                    'create_now'                  => __( 'Nu maken', 'publion' ),
                    'connection_lost'             => __( 'De verbinding met WordPress viel weg. Controleer de actuele status na het verversen voordat je opnieuw start.', 'publion' ),
                    'connection_lost_stage'       => __( 'Verbinding onderbroken', 'publion' ),
                    'cancel_creation_confirm'     => __( 'Wil je de artikelgeneratie annuleren? Publion stopt bij het eerstvolgende veilige servermoment.', 'publion' ),
                    'cancel_requested'            => __( 'Annulering aangevraagd', 'publion' ),
                    'cancel_pending'              => __( 'De server stopt bij het eerstvolgende veilige moment.', 'publion' ),
                    'cancel_failed'               => __( 'Annuleren is niet gelukt. De artikelgeneratie kan nog actief zijn.', 'publion' ),
                    'cancel_connection_lost'      => __( 'Annuleren kon niet worden bevestigd. Ververs de wachtrij om de actuele status te controleren.', 'publion' ),
                    'delete_topic_confirm'        => __( 'Weet je zeker dat je dit onderwerp uit de wachtrij wilt verwijderen?', 'publion' ),
                    'no_items_selected'           => __( 'Geen items geselecteerd.', 'publion' ),
                    'reloading'                   => __( 'Klaar! Herladen…', 'publion' ),
                    'failed_at_item'              => __( 'Mislukt bij item %d.', 'publion' ),
                    'ajax_error_at_item'          => __( 'AJAX-fout bij item %d.', 'publion' ),
                    'failed_count'                => __( '%d mislukt.', 'publion' ),
                    'deleted'                     => __( 'Verwijderd.', 'publion' ),
                    'choose_bulk_action'          => __( 'Kies een bulkactie.', 'publion' ),
                    'bulk_generate_confirm'       => __( 'Weet je zeker dat je alle geselecteerde posts wilt genereren?', 'publion' ),
                    'bulk_delete_confirm'         => __( 'Weet je zeker dat je alle geselecteerde items wilt verwijderen?', 'publion' ),
                    'invalid_date_time'           => __( 'Ongeldige datum/tijd.', 'publion' ),
                    'saved_short'                 => __( 'Opgeslagen', 'publion' ),
                    'remove_from_publion_confirm' => __( 'Onderwerp verwijderen uit Publion?', 'publion' ),
                    'remove_topic_failed'         => __( 'Onderwerp verwijderen mislukt.', 'publion' ),
                    'delete_ajax_error'           => __( 'AJAX-fout bij verwijderen van onderwerp.', 'publion' ),
                    'post_status_uncertain'       => __( 'Er ging iets mis. De post is mogelijk toch aangemaakt. Vernieuw de pagina om de actuele status te controleren.', 'publion' ),
                    'generic_next_step'           => __( 'Controleer de getoonde informatie en probeer daarna opnieuw.', 'publion' ),
                    'reference'                   => __( 'Referentie', 'publion' ),
                    'dismiss_message'             => __( 'Melding sluiten', 'publion' ),
                    'open_queue'                  => __( 'Open wachtrij', 'publion' ),
                    'connection_lost_next_step'   => __( 'Ververs eerst de wachtrij. Start alleen opnieuw als er nog geen concept is aangemaakt.', 'publion' ),
                    'queue_item'                  => __( 'Wachtrij-item', 'publion' ),
                    'bulk_completed_with_errors'  => __( 'Bulkactie afgerond: %d item(s) hebben aandacht nodig.', 'publion' ),
                    'bulk_completed'              => __( 'Bulkactie succesvol afgerond.', 'publion' ),
                    'bulk_progress_summary'       => __( '%d van %d verwerkt.', 'publion' ),
                    'bulk_success_summary'        => __( '%d geslaagd.', 'publion' ),
                    'refresh_queue'               => __( 'Ververs wachtrij', 'publion' ),
                    'bulk_processing'             => __( 'Item %d van %d wordt verwerkt.', 'publion' ),
                    'bulk_delete_processing'      => __( 'Geselecteerde items worden verwijderd.', 'publion' ),
                    'bulk_failed'                 => __( 'Een of meer items konden niet worden verwerkt.', 'publion' ),
                    'session_expired_title'       => __( 'Je WordPress-sessie is verlopen.', 'publion' ),
                    'session_expired_message'     => __( 'De actie is niet uitgevoerd omdat de beveiligingssessie niet meer geldig is.', 'publion' ),
                    'session_expired_next_step'   => __( 'Ververs de pagina, meld je zo nodig opnieuw aan en probeer daarna opnieuw.', 'publion' ),
                ],
            ]
        );
    }

    public function enqueue_frontend_styles() {
        $settings = get_option( 'publion_post_settings', [] );

        $image_radius = isset( $settings['image_border_radius'] ) ? absint( $settings['image_border_radius'] ) : 8;
        $image_radius = min( 48, $image_radius );
        $style_mode   = ( $settings['article_style_mode'] ?? 'inherit' ) === 'refined' ? 'refined' : 'inherit';
        $accent_color = sanitize_hex_color( $settings['content_accent_color'] ?? '' );
        $accent_color = $accent_color ? $accent_color : '#4f46e5';
        $content_width = isset( $settings['content_max_width'] ) ? absint( $settings['content_max_width'] ) : 760;
        $content_width = max( 560, min( 1200, $content_width ) );
        $custom_css = isset( $settings['custom_article_css'] ) ? (string) $settings['custom_article_css'] : '';
        wp_register_style( 'publion-content', false );
        wp_enqueue_style( 'publion-content' );
        // Theme styles regularly target article images with very specific selectors.
        // Keep the setting authoritative for old and new Publion images alike.
        $frontend_css  = '.publion-generated-post img, .publion-generated-image { border-radius: ' . $image_radius . 'px !important; }';
        $frontend_css .= '.publion-generated-post .publion-article-media { clear: both; display: block; width: 100%; margin: 2rem 0; overflow: hidden; border-radius: ' . $image_radius . 'px !important; background: #f4f5f7; }';
        $frontend_css .= '.publion-generated-post .publion-article-media--landscape { aspect-ratio: 16 / 9; }';
        $frontend_css .= '.publion-generated-post .publion-article-media--square { aspect-ratio: 1 / 1; max-width: min(30rem, 100%); margin-left: auto; margin-right: auto; }';
        $frontend_css .= '.publion-generated-post .publion-article-media .publion-generated-image { display: block; width: 100% !important; height: 100% !important; max-width: none !important; object-fit: cover; border-radius: inherit !important; }';
        $frontend_css .= '.publion-generated-post .publion-research-sources { clear: both; margin: 2.5rem 0; padding: 1.25rem 1.5rem; border: 1px solid #d9e2f0; border-radius: 8px; background: #f8fafc; }';
        $frontend_css .= '.publion-generated-post .publion-research-sources h2 { margin-top: 0; }';
        $frontend_css .= '.publion-generated-post .publion-research-sources p { margin: 0 0 .75rem; }';
        $frontend_css .= '.publion-generated-post .publion-research-sources ul { margin: 0; padding-left: 1.25rem; }';
        if ( 'refined' === $style_mode ) {
            $frontend_css .= '.publion-generated-post { --publion-accent: ' . $accent_color . '; --publion-content-width: ' . $content_width . 'px; }';
            $frontend_css .= '.publion-generated-post .entry-content, .publion-generated-post .wp-block-post-content { max-width: var(--publion-content-width); }';
            $frontend_css .= '.publion-generated-post .entry-content :is(h2, h3, h4), .publion-generated-post .wp-block-post-content :is(h2, h3, h4) { scroll-margin-top: 2rem; }';
            $frontend_css .= '.publion-generated-post .entry-content a, .publion-generated-post .wp-block-post-content a { color: var(--publion-accent); text-decoration-thickness: .08em; text-underline-offset: .14em; }';
            $frontend_css .= '.publion-generated-post .entry-content img, .publion-generated-post .wp-block-post-content img { max-width: 100%; height: auto; }';
        }
        if ( $custom_css ) {
            $frontend_css .= "\n" . $custom_css;
        }
        wp_add_inline_style( 'publion-content', $frontend_css );

        if ( ! empty( $settings['hide_title'] ) && $settings['hide_title'] === 'yes' ) {
            wp_register_style( 'publion-hide-title', false ); // No file, just inline
            wp_enqueue_style( 'publion-hide-title' );
            wp_add_inline_style( 'publion-hide-title', '.publion-title { display: none !important; }' );
        }
    }

    /**
     * Ask Rank Math to run its own, browser-based content tests when a
     * Publion-generated post is opened in the WordPress editor.
     *
     * Rank Math deliberately calculates its score in the editor, so no score
     * is guessed or stored by Publion during a background generation request.
     * This integration only invokes Rank Math's public editor refresh method.
     *
     * @param string $hook Current admin page hook.
     * @return void
     */
    public function enqueue_rank_math_content_refresh( $hook ) {
        if ( 'post.php' !== $hook || ! defined( 'RANK_MATH_VERSION' ) ) {
            return;
        }

        $settings = get_option( 'publion_post_settings', [] );
        if ( ( $settings['rank_math_integration'] ?? 'no' ) !== 'yes' ) {
            return;
        }

        $post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
        if ( ! $post_id || ! get_post_meta( $post_id, '_publion_queue_id', true ) ) {
            return;
        }

        // Do not assume Rank Math's private script handles exist. The refresh
        // script waits for the documented rankMathEditor global instead.
        wp_enqueue_script(
            'publion-rank-math-refresh',
            PUBLION_URL . 'assets/rank-math-refresh.js',
            [],
            file_exists( PUBLION_PATH . 'assets/rank-math-refresh.js' ) ? filemtime( PUBLION_PATH . 'assets/rank-math-refresh.js' ) : PUBLION_VERSION,
            true
        );
    }

    public static function sanitize_custom_article_css( $css ) {
        $css = wp_strip_all_tags( (string) $css );
        $css = preg_replace( '/@(import|charset)[^;]*;/i', '', $css );
        $css = str_ireplace( array( '</style>', '<style>' ), '', $css );
        return substr( trim( $css ), 0, 6000 );
    }

    public function add_generated_post_class( $classes, $class, $post_id ) {
        if ( get_post_meta( $post_id, '_publion_queue_id', true ) ) {
            $classes[] = 'publion-generated-post';
        }
        return $classes;
    }

    public function add_generated_thumbnail_class( $html, $post_id, $thumbnail_id, $size, $attr ) {
        if ( $html && get_post_meta( $post_id, '_publion_queue_id', true ) ) {
            if ( preg_match( '/<img[^>]*\bclass=["\'][^"\']*["\']/i', $html ) ) {
                $html = preg_replace( '/(<img[^>]*\bclass=["\'][^"\']*)/i', '$1 publion-generated-image publion-generated-featured', $html, 1 );
            } else {
                $html = preg_replace( '/<img\s/i', '<img class="publion-generated-image publion-generated-featured" ', $html, 1 );
            }
        }
        return $html;
    }

    public function output_structured_data() {
        if ( ! is_singular( 'post' ) ) {
            return;
        }
        $settings = get_option( 'publion_post_settings', [] );
        if ( ( $settings['structured_data'] ?? 'yes' ) !== 'yes' ) {
            return;
        }
        // Let the active SEO suite own article schema. Emitting a second BlogPosting
        // graph can make Google's rich-result interpretation ambiguous.
        if ( defined( 'RANK_MATH_VERSION' ) || defined( 'WPSEO_VERSION' ) || defined( 'AIOSEO_VERSION' ) ) {
            return;
        }
        $post_id = get_queried_object_id();
        if ( ! $post_id || ! get_post_meta( $post_id, '_publion_queue_id', true ) ) {
            return;
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            return;
        }
        $schema = [
            '@context'         => 'https://schema.org',
            '@type'            => 'BlogPosting',
            'headline'         => get_the_title( $post_id ),
            'description'      => publion_build_meta_description( $post->post_content ),
            'datePublished'    => get_the_date( DATE_W3C, $post_id ),
            'dateModified'     => get_the_modified_date( DATE_W3C, $post_id ),
            'mainEntityOfPage' => get_permalink( $post_id ),
            'author'           => [ '@type' => 'Person', 'name' => get_the_author_meta( 'display_name', $post->post_author ) ],
            'publisher'        => [ '@type' => 'Organization', 'name' => get_bloginfo( 'name' ) ],
        ];
        if ( has_post_thumbnail( $post_id ) ) {
            $schema['image'] = get_the_post_thumbnail_url( $post_id, 'full' );
        }
        $faq_pairs = get_post_meta( $post_id, '_publion_faq_pairs', true );
        if ( is_array( $faq_pairs ) && $faq_pairs ) {
            $faq_schema = [
                '@type'       => 'FAQPage',
                'mainEntity'  => array_map(
                static function ( $faq ) {
                    return [
                        '@type'          => 'Question',
                        'name'           => $faq['question'],
                        'acceptedAnswer' => [ '@type' => 'Answer', 'text' => $faq['answer'] ],
                    ];
                },
                $faq_pairs
                ),
            ];
            $schema = [ '@context' => 'https://schema.org', '@graph' => [ $schema, $faq_schema ] ];
        }
        echo "\n<script type=\"application/ld+json\">" . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
    }

    public function handle_form_submissions() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( isset( $_POST['publion_save_openai_key'] ) && check_admin_referer( 'publion_save_openai_key' ) ) {
            $key = sanitize_text_field( wp_unslash( $_POST['publion_api_key'] ?? '' ) );
            update_option( 'publion_api_key', $key );
            add_settings_error( 'publion_messages', 'key_saved', __( 'API-sleutel opgeslagen.', 'publion' ), 'updated' );
        }

        if ( isset( $_POST['publion_save_prompt'] ) && check_admin_referer( 'publion_save_prompt' ) ) {
            $prompt = wp_kses_post( wp_unslash( $_POST['publion_prompt'] ?? '' ) );
            update_option( 'publion_prompt', $prompt );
            add_settings_error( 'publion_messages', 'prompt_saved', __( 'Publion-prompt opgeslagen.', 'publion' ), 'updated' );
        }

        if ( isset( $_POST['publion_reset_prompt'] ) && check_admin_referer( 'publion_reset_prompt' ) ) {
            delete_option( 'publion_prompt' );
            add_settings_error( 'publion_messages', 'prompt_reset', __( 'Publion-prompt teruggezet naar standaard.', 'publion' ), 'updated' );
        }
    }

    public function render_admin_page() {
        if ( ! get_option( 'publion_last_post_created_at' ) ) {
            update_option( 'publion_last_post_created_at', current_time( 'mysql' ) );
        }

        $openai_api_key   = get_option( 'publion_api_key', '' );
        $openai_model     = publion_get_openai_model();
        $model_options    = publion_get_allowed_openai_models();
        $custom_model     = array_key_exists( $openai_model, $model_options ) ? '' : $openai_model;
        $image_model      = publion_get_openai_image_model();
        $image_model_options = publion_get_allowed_openai_image_models();
        $custom_image_model = array_key_exists( $image_model, $image_model_options ) ? '' : $image_model;
        $warning_display  = empty( $openai_api_key ) ? 'display:inline-block;' : 'display:none;';
        $default_prompt   = "Je bent Publion, een expert in het schrijven van blogs. Je maakt hoogwaardige, SEO-geoptimaliseerde content voor [JOUW BEDRIJFSNAAM (INDIEN VAN TOEPASSING) EN WEBSITE-URL], [WAT JOUW BEDRIJF/WEBSITE BIEDT]. Het doel is [JOUW BEDRIJFS/WEBSITE-DOELEN]. Stem de toon af op het merk: [DE TOON DIE JE WILT UITSTRALEN - voorbeeld: professioneel maar benaderbaar, deskundig maar eenvoudig uit te leggen]. Elk onderwerp moet de missie van [JOUW BEDRIJFS/WEBSITE-NAAM] weerspiegelen om [BEDRIJVEN of MENSEN] te helpen met [HOE JE BEDRIJVEN of MENSEN HELPT].\n\n(Vervang deze Publion-prompt door je eigen tekst om je doelen beter te weerspiegelen.)";
        $openai_prompt    = get_option( 'publion_prompt', $default_prompt );
        $dashboard_settings = get_option( 'publion_post_settings', array() );
        $last_image_error   = get_option( 'publion_last_image_error', '' );
        $last_openai_error  = get_option( 'publion_last_openai_error', '' );
        global $wpdb;
        publion_register_table_on_wpdb();
        $queue_table = $wpdb->publion_queue;
        $pending_count = (int) $wpdb->get_var( "SELECT COUNT(1) FROM {$queue_table} WHERE status = 'pending'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $created_this_month = (int) $wpdb->get_var( "SELECT COUNT(1) FROM {$queue_table} WHERE post_created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $scheduled_count = (int) $wpdb->get_var( "SELECT COUNT(1) FROM {$queue_table} WHERE status = 'pending' AND scheduled_at IS NOT NULL" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $post_counts = wp_count_posts( 'post' );
        $draft_count = isset( $post_counts->draft ) ? (int) $post_counts->draft : 0;

        // --- Handle manual topic form submission (with nonce verification) ---
        if (
            isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'] &&
            isset( $_POST['publion_manual_add_topic'] ) &&
            check_admin_referer( 'publion_manual_add_topic' )
        ) {
            $manual_topic    = sanitize_text_field( wp_unslash( $_POST['manual_topic'] ?? '' ) );
            $manual_category = isset( $_POST['manual_category'] ) ? absint( wp_unslash( $_POST['manual_category'] ) ) : 0;

            if ( ! empty( $manual_topic ) && $manual_category ) {
                $category_obj = get_category( $manual_category );

                if ( $category_obj && ! is_wp_error( $category_obj ) ) {
                    global $wpdb;
                    $table = $wpdb->prefix . 'publion_queue';

                    $wpdb->insert( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                        $table,
                        [
                            'topic'          => $manual_topic,
                            'category_id'    => $manual_category,
                            'category_label' => $category_obj->name,
                            'status'         => 'pending',
                            'created_at'     => current_time( 'mysql' ),
                        ]
                    );
					publion_schedule_pending_entries( false );

                    // Redirect to preserve tab and show success.
                    wp_redirect( admin_url( 'admin.php?page=publion&publion_active_tab=publion-queue&topic_added=1' ) );
                    exit;
                } else {
                    wp_redirect( admin_url( 'admin.php?page=publion&publion_active_tab=publion-queue&topic_error=invalid_category' ) );
                    exit;
                }
            } else {
                wp_redirect( admin_url( 'admin.php?page=publion&publion_active_tab=publion-queue&topic_error=missing_fields' ) );
                exit;
            }
        }
        ?>

        <div class="wrap publion-app-shell">
            <header class="publion-app-header">
                <div>
                    <p class="publion-eyebrow"><?php esc_html_e( 'CONTENT ENGINE', 'publion' ); ?></p>
                    <h1><?php esc_html_e( 'Publion', 'publion' ); ?></h1>
                    <p><?php esc_html_e( 'Van zoekintentie naar heldere, vindbare artikelen.', 'publion' ); ?></p>
                </div>
                <div class="publion-header-status">
                    <span class="publion-status-dot"></span>
                    <?php echo esc_html( $openai_api_key ? __( 'AI verbonden', 'publion' ) : __( 'API-sleutel nodig', 'publion' ) ); ?>
                </div>
            </header>

            <?php settings_errors( 'publion_messages' ); ?>

            <h2 class="nav-tab-wrapper">
                <a href="javascript:void(0)" class="nav-tab nav-tab-active" data-tab="publion-dashboard"><?php esc_html_e( 'Overzicht', 'publion' ); ?></a>
                <a href="javascript:void(0)" class="nav-tab" data-tab="publion-category-strategy-tab"><?php esc_html_e( 'Categorie-strategie', 'publion' ); ?></a>
                <a href="javascript:void(0)" class="nav-tab" data-tab="publion-generate"><?php esc_html_e( 'Content plannen', 'publion' ); ?></a>
                <a href="javascript:void(0)" class="nav-tab" data-tab="publion-queue"><?php esc_html_e( 'Postcreatie', 'publion' ); ?></a>
                <a href="javascript:void(0)" class="nav-tab" data-tab="publion-post-settings"><?php esc_html_e( 'Instellingen voor postcreatie', 'publion' ); ?></a>
                <a href="javascript:void(0)" class="nav-tab" data-tab="publion-settings"><?php esc_html_e( 'OpenAI/ChatGPT instellingen', 'publion' ); ?></a>
                <a href="javascript:void(0)" class="nav-tab" data-tab="publion-help"><?php esc_html_e( 'Handleiding & diagnose', 'publion' ); ?></a>
            </h2>

            <div id="publion-global-notice" class="publion-global-notice" aria-live="polite" aria-atomic="true"></div>

            <!-- Dashboard -->
            <div id="publion-dashboard" class="publion-tab-content" style="display:block;">
                <section class="publion-dashboard-top">
                    <div>
                        <p class="publion-eyebrow"><?php esc_html_e( 'CONTENT OPERATIONS', 'publion' ); ?></p>
                        <h2><?php esc_html_e( 'Je contentwerk, helder geordend.', 'publion' ); ?></h2>
                        <p><?php esc_html_e( 'Begin bij de volgende actie, maak inhoudelijke concepten en meet het effect in je eigen analyticsomgeving.', 'publion' ); ?></p>
                    </div>
                    <div class="publion-dashboard-actions">
                        <button type="button" class="button button-primary" data-publion-tab="publion-generate"><?php esc_html_e( 'Plan artikelen', 'publion' ); ?></button>
                        <button type="button" class="button" data-publion-tab="publion-queue"><?php esc_html_e( 'Open wachtrij', 'publion' ); ?></button>
                        <button type="button" class="button" id="publion-open-quality-modal" aria-haspopup="dialog"><?php esc_html_e( 'SEO / SEA / GEO-check', 'publion' ); ?></button>
                    </div>
                </section>

                <?php if ( empty( $openai_api_key ) ) : ?>
                    <div class="publion-callout publion-callout-warning">
                        <div><strong><?php esc_html_e( 'AI is nog niet verbonden.', 'publion' ); ?></strong><span><?php esc_html_e( 'Voeg eerst een OpenAI API-sleutel toe; zonder sleutel kan Publion geen onderwerpen, artikelen of afbeeldingen maken.', 'publion' ); ?></span></div>
                        <button type="button" class="button button-primary" data-publion-tab="publion-settings"><?php esc_html_e( 'API-sleutel instellen', 'publion' ); ?></button>
                    </div>
                <?php elseif ( ! empty( $last_openai_error ) || ! empty( $last_image_error ) ) : ?>
                    <div class="publion-callout publion-callout-error">
                        <div><strong><?php esc_html_e( 'De laatste AI-opdracht had een probleem.', 'publion' ); ?></strong><span><?php echo esc_html( $last_openai_error ?: $last_image_error ); ?></span></div>
                        <button type="button" class="button" data-publion-tab="publion-settings"><?php esc_html_e( 'Controleer AI-instellingen', 'publion' ); ?></button>
                    </div>
                <?php else : ?>
                    <div class="publion-callout publion-callout-success"><div><strong><?php esc_html_e( 'Alles is klaar voor de volgende contentcyclus.', 'publion' ); ?></strong><span><?php esc_html_e( 'Genereer een plan of review je concepten voordat je publiceert.', 'publion' ); ?></span></div></div>
                <?php endif; ?>

                <div class="publion-metric-grid">
                    <section><span><?php esc_html_e( 'In wachtrij', 'publion' ); ?></span><strong><?php echo esc_html( $pending_count ); ?></strong><small><?php echo esc_html( sprintf( _n( '%s ingepland', '%s ingepland', $scheduled_count, 'publion' ), $scheduled_count ) ); ?></small></section>
                    <section><span><?php esc_html_e( 'Concepten te reviewen', 'publion' ); ?></span><strong><?php echo esc_html( $draft_count ); ?></strong><small><?php esc_html_e( 'Alle WordPress-concepten', 'publion' ); ?></small></section>
                    <section><span><?php esc_html_e( 'Aangemaakt (30 dagen)', 'publion' ); ?></span><strong><?php echo esc_html( $created_this_month ); ?></strong><small><?php esc_html_e( 'Via Publion', 'publion' ); ?></small></section>
                    <section><span><?php esc_html_e( 'SEO-structuur', 'publion' ); ?></span><strong><?php echo esc_html( ( $dashboard_settings['structured_data'] ?? 'yes' ) === 'yes' ? __( 'Aan', 'publion' ) : __( 'Uit', 'publion' ) ); ?></strong><small><?php esc_html_e( 'BlogPosting en FAQ-data', 'publion' ); ?></small></section>
                </div>

                <div class="publion-dashboard-layout">
                    <section class="publion-dashboard-panel">
                        <div class="publion-panel-heading"><div><p class="publion-eyebrow"><?php esc_html_e( 'VOLGENDE STAPPEN', 'publion' ); ?></p><h3><?php esc_html_e( 'Werk in deze volgorde', 'publion' ); ?></h3></div></div>
                        <ol class="publion-workflow-list">
                            <li><span>1</span><div><strong><?php esc_html_e( 'Plan onderwerpen met zoekintentie', 'publion' ); ?></strong><p><?php esc_html_e( 'Kies een categorie en controleer de SEO-brief voordat je onderwerpen bewaart.', 'publion' ); ?></p></div><button type="button" class="button-link" data-publion-tab="publion-generate"><?php esc_html_e( 'Plannen', 'publion' ); ?></button></li>
                            <li><span>2</span><div><strong><?php esc_html_e( 'Maak en review concepten', 'publion' ); ?></strong><p><?php esc_html_e( 'Controleer feiten, bronnen, merktoon, afbeeldingen en interne links voor publicatie.', 'publion' ); ?></p></div><button type="button" class="button-link" data-publion-tab="publion-queue"><?php esc_html_e( 'Reviewen', 'publion' ); ?></button></li>
                            <li><span>3</span><div><strong><?php esc_html_e( 'Meet wat echt werkt', 'publion' ); ?></strong><p><?php esc_html_e( 'Gebruik Search Console voor vertoningen, klikken, CTR en gemiddelde positie; verbeter eerst pagina’s met veel vertoningen en lage CTR.', 'publion' ); ?></p></div><button type="button" class="button-link" data-publion-tab="publion-help"><?php esc_html_e( 'Lees uitleg', 'publion' ); ?></button></li>
                        </ol>
                    </section>
                    <aside class="publion-dashboard-panel publion-performance-panel">
                        <p class="publion-eyebrow"><?php esc_html_e( 'PRESTATIES', 'publion' ); ?></p>
                        <h3><?php esc_html_e( 'Analytics blijft de bron van waarheid', 'publion' ); ?></h3>
                        <p><?php esc_html_e( 'Publion genereert geen verzonnen verkeerscijfers. Koppel hieronder je eigen dashboards om resultaten per artikel te beoordelen.', 'publion' ); ?></p>
                        <div class="publion-performance-links">
                            <a class="button" href="<?php echo esc_url( $dashboard_settings['search_console_url'] ?? 'https://search.google.com/search-console' ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open Search Console', 'publion' ); ?></a>
                            <a class="button" href="<?php echo esc_url( $dashboard_settings['ga4_url'] ?? 'https://analytics.google.com/' ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open Google Analytics', 'publion' ); ?></a>
                        </div>
                        <p class="publion-panel-note"><?php esc_html_e( 'Sla eigen rapportlinks op bij Instellingen voor postcreatie om direct naar de juiste property te gaan.', 'publion' ); ?></p>
                    </aside>
                </div>
            </div>

            <div id="publion-quality-modal" class="publion-modal" hidden>
                <div class="publion-modal-backdrop" data-publion-modal-close="true"></div>
                <section class="publion-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="publion-quality-modal-title" aria-describedby="publion-quality-modal-description" tabindex="-1">
                    <header class="publion-modal-header">
                        <div><p class="publion-eyebrow"><?php esc_html_e( 'PUBLICATIECHECK', 'publion' ); ?></p><h2 id="publion-quality-modal-title"><?php esc_html_e( 'SEO, SEA en GEO in één review', 'publion' ); ?></h2></div>
                        <button type="button" class="button-link publion-modal-close" data-publion-modal-close="true" aria-label="<?php esc_attr_e( 'Sluit kwaliteitscheck', 'publion' ); ?>">×</button>
                    </header>
                    <p id="publion-quality-modal-description" class="publion-modal-intro"><?php esc_html_e( 'Gebruik deze korte controle vóór publicatie of voordat je een artikel als landingspagina voor een campagne inzet.', 'publion' ); ?></p>
                    <div class="publion-quality-grid">
                        <section><h3><?php esc_html_e( 'SEO — organisch vinden', 'publion' ); ?></h3><ul><li><?php esc_html_e( 'Beantwoordt de titel één duidelijke zoekvraag?', 'publion' ); ?></li><li><?php esc_html_e( 'Zijn titel, meta description en eerste alinea inhoudelijk consistent?', 'publion' ); ?></li><li><?php esc_html_e( 'Zijn interne links, relevante bronnen en afbeeldingen gecontroleerd?', 'publion' ); ?></li></ul></section>
                        <section><h3><?php esc_html_e( 'SEA — campagneklaar', 'publion' ); ?></h3><ul><li><?php esc_html_e( 'Sluit de landingspagina exact aan op de advertentiebelofte?', 'publion' ); ?></li><li><?php esc_html_e( 'Is er één heldere, meetbare conversieactie?', 'publion' ); ?></li><li><?php esc_html_e( 'Kun je meerdere unieke headlines en descriptions testen zonder claims te verzinnen?', 'publion' ); ?></li></ul></section>
                        <section><h3><?php esc_html_e( 'GEO/AEO — antwoordklaar', 'publion' ); ?></h3><ul><li><?php esc_html_e( 'Staat het directe antwoord vroeg in het artikel?', 'publion' ); ?></li><li><?php esc_html_e( 'Zijn feiten specifiek, controleerbaar en niet overdreven?', 'publion' ); ?></li><li><?php esc_html_e( 'Helpen koppen, FAQ en structured data de inhoud te duiden?', 'publion' ); ?></li></ul></section>
                    </div>
                    <footer class="publion-modal-footer"><button type="button" class="button button-primary publion-modal-close" data-publion-modal-close="true"><?php esc_html_e( 'Begrepen', 'publion' ); ?></button><button type="button" class="button" data-publion-tab="publion-help"><?php esc_html_e( 'Open handleiding', 'publion' ); ?></button></footer>
                </section>
            </div>

            <!-- Tab: Category Strategy -->
            <div id="publion-category-strategy-tab" class="publion-tab-content" style="display:none;">
                <div class="publion-section-intro">
                    <p class="publion-eyebrow"><?php esc_html_e( '01 — CATEGORIEËN', 'publion' ); ?></p>
                    <h2><?php esc_html_e( 'Ontwerp een bruikbare structuur vóór je nieuwe artikelen plant.', 'publion' ); ?></h2>
                    <p><?php esc_html_e( 'Onderzoek welke hoofd- en subcategorieën werkelijk passen bij de inhoud en doelen van je website.', 'publion' ); ?></p>
                </div>
                <section id="publion-category-strategy" class="publion-category-strategy" aria-labelledby="publion-category-strategy-title">
                    <div class="publion-category-strategy-heading">
                        <div>
                            <p class="publion-eyebrow"><?php esc_html_e( 'CATEGORIESTRATEGIE', 'publion' ); ?></p>
                            <h3 id="publion-category-strategy-title"><?php esc_html_e( 'Bouw een complete categoriehiërarchie voor je website', 'publion' ); ?></h3>
                            <p><?php esc_html_e( 'Handmatig en op aanvraag. Publion leest je bestaande berichten, pagina’s en categorieën en maakt voorstellen voor hoofd- én subcategorieën. Elk voorstel bevat alle WordPress-, SEO- en GEO-velden; jij beoordeelt en bevestigt de aanmaak.', 'publion' ); ?></p>
                        </div>
                        <span class="publion-strategy-badge"><?php esc_html_e( 'Geen automatische planning', 'publion' ); ?></span>
                    </div>
                    <ol class="publion-category-strategy-steps" aria-label="<?php esc_attr_e( 'Werkwijze categorie-strategie', 'publion' ); ?>">
                        <li><span>1</span><div><strong><?php esc_html_e( 'Onderzoek', 'publion' ); ?></strong><small><?php esc_html_e( 'Analyseer actuele pagina’s, berichten en categorieën.', 'publion' ); ?></small></div></li>
                        <li><span>2</span><div><strong><?php esc_html_e( 'Beoordeel', 'publion' ); ?></strong><small><?php esc_html_e( 'Controleer hiërarchie, beschrijving, intentie en metadata.', 'publion' ); ?></small></div></li>
                        <li><span>3</span><div><strong><?php esc_html_e( 'Maak veilig aan', 'publion' ); ?></strong><small><?php esc_html_e( 'Hoofdcategorieën worden vóór subcategorieën aangemaakt.', 'publion' ); ?></small></div></li>
                    </ol>
                    <div class="publion-category-strategy-controls">
                        <label for="publion-category-intent">
                            <span><?php esc_html_e( 'Primair doel', 'publion' ); ?></span>
                            <select id="publion-category-intent">
                                <option value="gemengd"><?php esc_html_e( 'Gebalanceerde mix', 'publion' ); ?></option>
                                <option value="informatief"><?php esc_html_e( 'Informatief — expertise en bereik', 'publion' ); ?></option>
                                <option value="commercieel"><?php esc_html_e( 'Commercieel — leads en overweging', 'publion' ); ?></option>
                                <option value="transactioneel"><?php esc_html_e( 'Transactioneel — conversie of verkoop', 'publion' ); ?></option>
                            </select>
                        </label>
                        <label class="publion-category-context" for="publion-category-context">
                            <span><?php esc_html_e( 'Extra kader (optioneel)', 'publion' ); ?></span>
                            <input type="text" id="publion-category-context" maxlength="1200" placeholder="<?php esc_attr_e( 'Bijvoorbeeld: focus dit kwartaal op MKB-leads in webdesign.', 'publion' ); ?>">
                        </label>
                        <button type="button" id="publion-suggest-categories" class="button button-secondary"><?php esc_html_e( 'Categorieën onderzoeken', 'publion' ); ?></button>
                    </div>
                    <p class="description"><?php esc_html_e( 'Voorstellen zijn hoofdclusters of gerichte subclusters, geen losse blogtitels. De tool slaat niets op totdat je dit zelf per categorie of voor de hele hiërarchie bevestigt. Bestaande categorieën worden nooit automatisch overschreven.', 'publion' ); ?></p>
                    <div id="publion-category-strategy-loading" class="publion-inline-loading" style="display:none;" aria-live="polite"><span class="spinner is-active" style="float:none;"></span><em><?php esc_html_e( 'Websitecontent en categorieën worden geanalyseerd…', 'publion' ); ?></em></div>
                    <div id="publion-category-results-toolbar" class="publion-category-results-toolbar" hidden>
                        <div><strong id="publion-category-results-title"><?php esc_html_e( 'Categorievoorstellen klaar voor review', 'publion' ); ?></strong><span id="publion-category-results-status" aria-live="polite"></span></div>
                        <div class="publion-category-results-actions">
                            <button type="button" id="publion-create-category-hierarchy" class="button button-primary"><?php esc_html_e( 'Volledige hiërarchie aanmaken', 'publion' ); ?></button>
                            <button type="button" id="publion-clear-category-suggestions" class="button"><?php esc_html_e( 'Voorstellen wissen', 'publion' ); ?></button>
                        </div>
                    </div>
                    <div id="publion-category-suggestions" class="publion-category-suggestions" aria-live="polite" aria-relevant="additions text" aria-busy="false" tabindex="-1"></div>
                </section>
            </div>

            <!-- Tab: Generate Topics & Queue Posts -->
            <div id="publion-generate" class="publion-tab-content" style="display:none;">

                <div class="publion-section-intro">
                    <p class="publion-eyebrow"><?php esc_html_e( '02 — CONTENT PLANNEN', 'publion' ); ?></p>
                    <h2><?php esc_html_e( 'Kies een categorie. Publion bouwt vervolgens een SEO-brief per artikel.', 'publion' ); ?></h2>
                    <p><?php esc_html_e( 'Elke suggestie bevat een dynamisch focus-keyword, zoekintentie, invalshoek en FAQ-vragen.', 'publion' ); ?></p>
                </div>
                <select id="publion-category">
                    <option value=""><?php esc_html_e( 'Selecteer een categorie', 'publion' ); ?></option>
                    <?php
                    $categories = get_categories( [ 'hide_empty' => false ] );
                    foreach ( $categories as $cat ) {
                        if ( strtolower( $cat->name ) === 'uncategorized' ) {
                            continue;
                        }

                        $label_parts = array( $cat->name );
                        $parent_id   = (int) $cat->parent;
                        $guard       = 0;
                        while ( $parent_id && $guard < 10 ) {
                            $parent = get_category( $parent_id );
                            if ( ! $parent || is_wp_error( $parent ) ) {
                                break;
                            }
                            array_unshift( $label_parts, $parent->name );
                            $parent_id = (int) $parent->parent;
                            $guard++;
                        }
                        $label = implode( ' → ', $label_parts );

                        echo '<option value="' . esc_attr( $cat->term_id ) . '" data-publion-category-name="' . esc_attr( $cat->name ) . '">' . esc_html( $label ) . '</option>';
                    }
                    ?>
                </select>
                <button id="publion-suggest" class="button button-primary" style="margin-left:8px;"><?php esc_html_e( 'Onderwerpen voorstellen', 'publion' ); ?></button>
                <button id="publion-refresh" class="button" style="margin-left:8px; display:none;"><?php esc_html_e( 'Voorstellen vernieuwen', 'publion' ); ?></button>
                <p class="description" style="max-width:760px; margin:10px 0 0;"><?php esc_html_e( 'Voor elke aanvraag leest Publion de actuele contentkaart van bestaande berichten. Nieuwe voorstellen moeten een andere zoekvraag of invalshoek hebben; een te vergelijkbaar concept wordt vóór het opslaan geblokkeerd.', 'publion' ); ?></p>

                <h2 id="publion-suggestions-heading" style="display:none;"><?php esc_html_e( 'AI-onderwerpvoorstellen', 'publion' ); ?></h2>
                <div id="publion-loading" style="display:none; margin: 10px 0; align-items:center; gap:10px;">
                    <em><?php esc_html_e( 'Onderwerpvoorstellen laden...', 'publion' ); ?></em>
                    <span class="spinner is-active" style="float:none;"></span>
                </div>
                <ul id="publion-suggestions"></ul>

                <div id="publion-selected-topics" style="display: none;">
                    <h2><?php esc_html_e( 'Geselecteerde onderwerpen voor de wachtrij', 'publion' ); ?></h2>
                    <table id="publion-ai-queue" class="widefat striped">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Actie', 'publion' ); ?></th>
                                <th><?php esc_html_e( 'Categorie', 'publion' ); ?></th>
                                <th><?php esc_html_e( 'Onderwerp', 'publion' ); ?></th>
                                <th><?php esc_html_e( 'SEO-brief', 'publion' ); ?></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>

                    <br>
                    <button id="publion-save-queue" class="button button-primary"><?php esc_html_e( 'Toevoegen aan wachtrij voor postcreatie', 'publion' ); ?></button>
                </div>
            </div>

            <!-- Tab: Post Creation Queue -->
            <div id="publion-queue" class="publion-tab-content" style="display:none;">
            <?php
            // Fetch categories except "Uncategorized"
            $categories = get_categories(
                [
                    'hide_empty' => false,
                    'exclude'    => [ get_option( 'default_category' ) ],
                ]
            );
            ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=publion' ) ); ?>" id="publion-manual-form" style="display: flex; align-items: center; gap: 10px; margin:20px 0 15px 0; flex-wrap: wrap; max-width: 100%;">
                <input type="hidden" name="publion_manual_add_topic" value="1" />
                <?php wp_nonce_field( 'publion_manual_add_topic' ); ?>

                <label for="manual_topic" style="font-weight: 600; white-space: nowrap;"><?php esc_html_e( 'Voeg handmatig een onderwerp toe:', 'publion' ); ?></label>

                <select name="manual_category" required>
                    <option value=""><?php esc_html_e( 'Selecteer een categorie', 'publion' ); ?></option>
                    <?php
                    $categories = get_categories( [ 'hide_empty' => false ] );
                    foreach ( $categories as $cat ) {
                        if ( strtolower( $cat->name ) === 'uncategorized' ) {
                            continue;
                        }

                        $label = $cat->name;
                        if ( $cat->parent ) {
                            $parent = get_category( $cat->parent );
                            $label  = $parent->name . ' → ' . $cat->name;
                        }

                        echo '<option value="' . esc_attr( $cat->term_id ) . '">' . esc_html( $label ) . '</option>';
                    }
                    ?>
                </select>

                <input type="text" name="manual_topic" id="manual_topic" placeholder="<?php esc_attr_e( 'Onderwerp invoeren...', 'publion' ); ?>" style="flex-grow: 1; min-width: 500px; font-size: 14px;" />

                <button type="submit" class="publion-tab-button button button-primary" data-tab="post_creation"><?php esc_html_e( 'Toevoegen', 'publion' ); ?></button>
            </form>

                <h2 class="publion-accordion-heading active">
                  <span class="publion-heading-label"><?php esc_html_e( 'Wachtrij voor postcreatie', 'publion' ); ?></span>
                  <span class="publion-accordion-arrow">▲</span>
                </h2>
                <div class="publion-accordion-body" style="display:block;">
                    <div class="publion-bulk-actions" style="display:flex; align-items:center; gap:10px; margin:10px 0;">
                        <label style="display:flex; align-items:center; gap:6px; font-weight:600;">
                            <input type="checkbox" id="publion-select-all">
                            <?php esc_html_e( 'Alles selecteren', 'publion' ); ?>
                        </label>
                        <select id="publion-bulk-action">
                            <option value=""><?php esc_html_e( 'Bulkactie kiezen', 'publion' ); ?></option>
                            <option value="generate"><?php esc_html_e( 'Genereren', 'publion' ); ?></option>
                            <option value="delete"><?php esc_html_e( 'Verwijderen', 'publion' ); ?></option>
                        </select>
                        <button type="button" id="publion-bulk-apply" class="button"><?php esc_html_e( 'Toepassen', 'publion' ); ?></button>
                        <div id="publion-bulk-status" role="status" aria-live="polite" aria-atomic="true"></div>
                    </div>
                    <p class="description publion-progress-explainer"><?php esc_html_e( 'Bij “Nu maken” volgt de voortgang de echte serverstappen. Het percentage is een workflow-checkpoint, geen tijdsinschatting.', 'publion' ); ?></p>
                    <table class="widefat striped" id="publion-queue-table">
                        <thead>
                            <tr>
                                <th style="text-align:center; width:36px;"><?php esc_html_e( 'Selectie', 'publion' ); ?></th>
                                <th style="text-align: center;"><?php esc_html_e( 'Acties', 'publion' ); ?></th>
                                <th><?php esc_html_e( 'Onderwerp', 'publion' ); ?></th>
                                <th style="text-align: center;"><?php esc_html_e( 'Categorie', 'publion' ); ?></th>
                                <th style="text-align: center;"><?php esc_html_e( 'Gepland op', 'publion' ); ?></th>
                                <th style="text-align: center;"><?php esc_html_e( 'Dagen tot aanmaak', 'publion' ); ?></th>
                                <th style="text-align: center;"><?php esc_html_e( 'Onderwerp aangemaakt op', 'publion' ); ?></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <div style="text-align:center;margin-top:20px;">
                        <button id="publion-load-more" class="button"><?php esc_html_e( 'Meer laden...', 'publion' ); ?></button>
                    </div>
                </div>

                <h2 class="publion-accordion-heading">
                  <span class="publion-heading-label"><?php esc_html_e( 'Aangemaakte posts', 'publion' ); ?></span>
                  <span class="publion-accordion-arrow">▼</span>
                </h2>
                <div class="publion-accordion-body" style="display:none;">
                    <div class="publion-created-history-toolbar">
                        <p class="description"><?php esc_html_e( 'Wis alleen de Publion-historie. De originele WordPress-posts blijven altijd behouden.', 'publion' ); ?></p>
                        <button type="button" id="publion-clear-created-history" class="button button-secondary"><?php esc_html_e( 'Geschiedenis wissen', 'publion' ); ?></button>
                    </div>
                    <table class="widefat striped" id="publion-created-table">
                        <thead>
                            <tr>
                                <th style="text-align: center;"><?php esc_html_e( 'Acties', 'publion' ); ?></th>
                                <th><?php esc_html_e( 'Onderwerp', 'publion' ); ?></th>
                                <th style="text-align: center;"><?php esc_html_e( 'Categorie', 'publion' ); ?></th>
                                <th style="text-align: center;"><?php esc_html_e( 'Onderwerp aangemaakt op', 'publion' ); ?></th>
                                <th style="text-align: center;"><?php esc_html_e( 'Post aangemaakt op', 'publion' ); ?></th>
                                <th style="text-align: center;"><?php esc_html_e( 'Publicatiedatum', 'publion' ); ?></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <div style="text-align:center;margin-top:20px;">
                        <button id="publion-load-more-created" class="button"><?php esc_html_e( 'Meer laden...', 'publion' ); ?></button>
                    </div>
                </div>
            </div>

            <!-- Tab: Post Creation Settings -->
            <?php
            $settings    = get_option( 'publion_post_settings', [] );
            $cta_enabled = $settings['cta_enabled'] ?? 'no';
            $author_id   = isset( $settings['default_post_author'] ) ? (int) $settings['default_post_author'] : 0;
            $post_schedule_mode = function_exists( 'publion_get_post_schedule_mode' ) ? publion_get_post_schedule_mode( $settings ) : 'every_n_days';
            $posts_per_day = function_exists( 'publion_get_posts_per_day' ) ? publion_get_posts_per_day( $settings ) : 1;
            $post_creation_window_hours = function_exists( 'publion_get_post_creation_window_hours' ) ? publion_get_post_creation_window_hours( $settings ) : 8;
            $author_users = get_users(
                [
                    'orderby' => 'display_name',
                    'order'   => 'ASC',
                    'fields'  => [ 'ID', 'display_name', 'user_login' ],
                ]
            );
            ?>
            <div id="publion-post-settings" class="publion-tab-content" style="display:none;">
                <form id="publion-post-settings-form">
                    <?php wp_nonce_field( 'publion_nonce', 'publion_nonce' ); ?>

                    <table class="form-table">
                        <tr class="publion-settings-section-row">
                            <th colspan="2" scope="colgroup">
                                <div class="publion-settings-section-heading">
                                    <span>1</span>
                                    <div>
                                        <h3><?php esc_html_e( 'Automatische postcreatie', 'publion' ); ?></h3>
                                        <p><?php esc_html_e( 'Bepaal hoe de onderwerpen uit je wachtrij worden ingepland en als artikelconcept worden aangemaakt.', 'publion' ); ?></p>
                                    </div>
                                </div>
                            </th>
                        </tr>
                        <tr class="publion-settings-highlight-row">
                            <td colspan="2">
                                <div class="publion-automation-card">
                                    <div class="publion-automation-card-heading">
                                        <div>
                                            <strong><?php esc_html_e( 'Planning voor wachtrij-items', 'publion' ); ?></strong>
                                            <p><?php esc_html_e( 'Publion plant nieuwe items automatisch in. De server verwerkt steeds één artikel tegelijk, zodat meerdere posts per dag betrouwbaar en overzichtelijk blijven.', 'publion' ); ?></p>
                                        </div>
                                        <span class="publion-settings-badge"><?php esc_html_e( 'Wachtrij actief', 'publion' ); ?></span>
                                    </div>
                                    <div class="publion-settings-control-grid">
                                        <label for="publion_post_schedule_mode">
                                            <span><?php esc_html_e( 'Frequentie', 'publion' ); ?></span>
                                            <select id="publion_post_schedule_mode" name="post_schedule_mode">
                                                <option value="daily" <?php selected( $post_schedule_mode, 'daily' ); ?>><?php esc_html_e( 'Dagelijks (één of meerdere posts)', 'publion' ); ?></option>
                                                <option value="every_n_days" <?php selected( $post_schedule_mode, 'every_n_days' ); ?>><?php esc_html_e( 'Elke X dagen (één post)', 'publion' ); ?></option>
                                            </select>
                                        </label>
                                        <label class="publion-post-schedule-daily" for="publion_posts_per_day">
                                            <span><?php esc_html_e( 'Posts per dag', 'publion' ); ?></span>
                                            <select id="publion_posts_per_day" name="posts_per_day">
                                                <?php foreach ( array( 1, 2, 3, 4, 6, 8 ) as $posts_per_day_option ) : ?>
                                                    <option value="<?php echo esc_attr( $posts_per_day_option ); ?>" <?php selected( $posts_per_day, $posts_per_day_option ); ?>><?php echo esc_html( $posts_per_day_option ); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </label>
                                        <label class="publion-post-schedule-daily" for="publion_post_creation_window_hours">
                                            <span><?php esc_html_e( 'Spreid over', 'publion' ); ?></span>
                                            <span class="publion-input-with-suffix"><input type="number" id="publion_post_creation_window_hours" name="post_creation_window_hours" min="1" max="23" value="<?php echo esc_attr( $post_creation_window_hours ); ?>" /><em><?php esc_html_e( 'uur', 'publion' ); ?></em></span>
                                        </label>
                                        <label class="publion-post-schedule-every-days" for="publion_time_frame_days">
                                            <span><?php esc_html_e( 'Elke hoeveel dagen', 'publion' ); ?></span>
                                            <span class="publion-input-with-suffix"><input type="number" id="publion_time_frame_days" name="time_frame_days" min="1" value="<?php echo esc_attr( $settings['time_frame_days'] ?? 3 ); ?>" /><em><?php esc_html_e( 'dagen', 'publion' ); ?></em></span>
                                        </label>
                                        <label for="publion_post_creation_time">
                                            <span><?php esc_html_e( 'Eerste aanmaaktijd', 'publion' ); ?></span>
                                            <input type="time" id="publion_post_creation_time" name="post_creation_time" value="<?php echo esc_attr( $settings['post_creation_time'] ?? '00:00' ); ?>" />
                                        </label>
									</div>
									<p id="publion-post-schedule-summary" class="publion-schedule-summary" aria-live="polite"></p>
									<div class="publion-automation-topic-flow">
										<label for="publion_auto_daily_topic">
											<input type="checkbox" name="auto_daily_topic" id="publion_auto_daily_topic" value="yes" <?php checked( $settings['auto_daily_topic'] ?? '', 'yes' ); ?> />
											<strong><?php esc_html_e( 'Vul de wachtrij automatisch aan met AI-onderwerpen', 'publion' ); ?></strong>
										</label>
										<p id="publion-topic-schedule-summary" class="description"></p>
										<?php
										$next_daily_ts = (int) wp_next_scheduled( 'publion_daily_topic_hook' );
										if ( ! $next_daily_ts && ( $settings['auto_daily_topic'] ?? 'no' ) === 'yes' ) {
											$next_daily_ts = publion_calculate_initial_daily_topic_timestamp( $settings );
										}
										$next_daily_label = $next_daily_ts ? wp_date( 'M d, Y H:i', $next_daily_ts ) : __( 'Niet gepland', 'publion' );
										?>
										<p class="publion-next-topic-run">
											<?php esc_html_e( 'Volgende onderwerpaanvulling:', 'publion' ); ?>
											<span id="publion-next-daily-topic"><?php echo esc_html( $next_daily_label ); ?></span>
										</p>
									</div>
								</div>
                            </td>
                        </tr>

                        <tr>
                            <th><label for="publion_post_status"><?php esc_html_e( 'Poststatus bij aanmaken', 'publion' ); ?></label></th>
                            <td>
                                <select id="publion_post_status" name="post_status">
                                    <option value="draft" <?php selected( $settings['post_status'] ?? 'draft', 'draft' ); ?>><?php esc_html_e( 'Concept', 'publion' ); ?></option>
                                    <option value="publish" <?php selected( $settings['post_status'] ?? 'draft', 'publish' ); ?>><?php esc_html_e( 'Gepubliceerd', 'publion' ); ?></option>
                                </select>
                                <p class="description" style="margin-top:6px; max-width: 600px;">
                                    <strong><?php esc_html_e( 'Let op:', 'publion' ); ?></strong>
                                    <em><?php esc_html_e( 'Concept wordt aanbevolen. Als er geen AI-afbeeldingen gegenereerd kunnen worden, worden placeholders gebruikt. Kies je voor Gepubliceerd, dan gaat de post live met placeholders indien nodig. De SEO-conceptblokkade wordt dan automatisch uitgeschakeld, zodat deze keuze leidend blijft.', 'publion' ); ?></em>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th><label for="publion_default_post_author"><?php esc_html_e( 'Standaard auteur voor posts', 'publion' ); ?></label></th>
                            <td>
                                <select id="publion_default_post_author" name="default_post_author">
                                    <option value="0"><?php esc_html_e( 'Geen voorkeur (gebruik uitvoerende gebruiker)', 'publion' ); ?></option>
                                    <?php
                                    foreach ( $author_users as $user ) {
                                        if ( empty( $user->ID ) || ! user_can( (int) $user->ID, 'edit_posts' ) ) {
                                            continue;
                                        }
                                        $label = $user->display_name . ' (' . $user->user_login . ')';
                                        echo '<option value="' . esc_attr( $user->ID ) . '" ' . selected( $author_id, $user->ID, false ) . '>' . esc_html( $label ) . '</option>';
                                    }
                                    ?>
                                </select>
                                <p class="description" style="margin-top:6px; max-width: 600px;">
                                    <?php esc_html_e( 'Wordt gebruikt voor automatisch aangemaakte posts.', 'publion' ); ?>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php esc_html_e( 'Posttitel verbergen', 'publion' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="hide_title" id="publion_hide_title" value="yes" <?php checked( $settings['hide_title'] ?? '', 'yes' ); ?> />
                                    <?php esc_html_e( 'Verberg de posttitel (voor thema\'s die deze automatisch tonen)', 'publion' ); ?>
                                </label>
                            </td>
                        </tr>

                        <tr class="publion-settings-section-row">
                            <th colspan="2" scope="colgroup">
                                <div class="publion-settings-section-heading">
                                    <span>2</span>
                                    <div>
                                        <h3><?php esc_html_e( 'Onderwerpen en categorieën', 'publion' ); ?></h3>
                                        <p><?php esc_html_e( 'Beheer hier de SEO- en GEO-categoriestructuur die Publion voor nieuwe onderwerpen gebruikt.', 'publion' ); ?></p>
                                    </div>
                                </div>
                            </th>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e( 'Categorieën maken', 'publion' ); ?></th>
                            <td>
                                <div class="publion-settings-linked-workflow">
                                    <div>
                                        <strong><?php esc_html_e( 'Hoofd- en subcategorieën plannen', 'publion' ); ?></strong>
                                        <p><?php esc_html_e( 'Categorieën worden bewust pas aangemaakt nadat je de SEO-, GEO- en hiërarchievoorstellen hebt gecontroleerd. Open Categorie-strategie om ze handmatig te genereren en als volledige hiërarchie aan te maken.', 'publion' ); ?></p>
                                    </div>
                                    <button type="button" class="button" data-publion-tab="publion-category-strategy-tab"><?php esc_html_e( 'Open Categorie-strategie', 'publion' ); ?></button>
                                </div>
                            </td>
                        </tr>

                        <tr class="publion-settings-section-row">
                            <th colspan="2" scope="colgroup">
                                <div class="publion-settings-section-heading">
                                    <span>3</span>
                                    <div>
                                        <h3><?php esc_html_e( 'Bronnen en research', 'publion' ); ?></h3>
                                        <p><?php esc_html_e( 'Stel betrouwbare bronlinks en optioneel live webonderzoek per artikel in.', 'publion' ); ?></p>
                                    </div>
                                </div>
                            </th>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e( 'Externe bronwebsite', 'publion' ); ?></th>
                            <td>
                                <input type="text" id="publion_preferred_external_domain" name="preferred_external_domain" style="width:320px;"
                                       value="<?php echo esc_attr( $settings['preferred_external_domain'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Bijv. refacthor.nl', 'publion' ); ?>" />
                                <p class="description" style="margin-top:6px; max-width: 600px;">
                                    <?php esc_html_e( 'Vul het domein van een betrouwbare externe bron in. Publion gebruikt de HTTPS-homepage als veilige bronlink wanneer je geen specifieke URL toevoegt.', 'publion' ); ?>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php esc_html_e( 'Live brononderzoek op internet', 'publion' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" id="publion_web_research_enabled" name="web_research_enabled" value="yes" <?php checked( $settings['web_research_enabled'] ?? '', 'yes' ); ?> />
                                    <?php esc_html_e( 'Zoek actuele externe bronnen voordat een artikel wordt geschreven', 'publion' ); ?>
                                </label>
                                <p class="description" style="margin-top:6px; max-width:760px;">
                                    <?php esc_html_e( 'Publion gebruikt de OpenAI Responses API met webzoekfunctie. Alleen de werkelijk teruggegeven HTTPS-bronnen worden aan de AI meegegeven en kunnen als klikbare bronnenlijst in het artikel verschijnen. Dit kan extra API-kosten en generatietijd geven.', 'publion' ); ?>
                                </p>
                                <div class="publion-web-research-options" style="margin-top:14px; max-width:760px; padding:14px; border:1px solid #d9e2f0; border-radius:8px; background:#f8fafc;">
                                    <p style="margin-top:0;"><strong><?php esc_html_e( 'Onderzoeksregels', 'publion' ); ?></strong></p>
                                    <p>
                                        <strong><?php esc_html_e( 'Model voor brononderzoek', 'publion' ); ?></strong><br>
                                        <code><?php echo esc_html( $openai_model ); ?></code>
                                        <span class="description"><?php esc_html_e( 'Brononderzoek gebruikt altijd het hierboven geselecteerde OpenAI-model. Als dit model geen Responses API met webzoekfunctie ondersteunt, toont OpenAI een fout in plaats van stil een ander model te gebruiken.', 'publion' ); ?></span>
                                    </p>
                                    <p>
                                        <label for="publion_web_research_source_count"><strong><?php esc_html_e( 'Aantal bronnen per artikel', 'publion' ); ?></strong></label><br>
                                        <select id="publion_web_research_source_count" name="web_research_source_count">
                                            <?php for ( $source_count = 1; $source_count <= 5; $source_count++ ) : ?>
                                                <option value="<?php echo esc_attr( $source_count ); ?>" <?php selected( (int) ( $settings['web_research_source_count'] ?? 3 ), $source_count ); ?>><?php echo esc_html( $source_count ); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                        <label for="publion_web_research_context_size" style="margin-left:14px;"><strong><?php esc_html_e( 'Onderzoeksdiepte', 'publion' ); ?></strong></label>
                                        <select id="publion_web_research_context_size" name="web_research_context_size">
                                            <option value="low" <?php selected( $settings['web_research_context_size'] ?? 'medium', 'low' ); ?>><?php esc_html_e( 'Laag (snel)', 'publion' ); ?></option>
                                            <option value="medium" <?php selected( $settings['web_research_context_size'] ?? 'medium', 'medium' ); ?>><?php esc_html_e( 'Gemiddeld (aanbevolen)', 'publion' ); ?></option>
                                            <option value="high" <?php selected( $settings['web_research_context_size'] ?? 'medium', 'high' ); ?>><?php esc_html_e( 'Hoog (meer context)', 'publion' ); ?></option>
                                        </select>
                                    </p>
                                    <p>
                                        <label>
                                            <input type="checkbox" id="publion_web_research_live_access" name="web_research_live_access" value="yes" <?php checked( $settings['web_research_live_access'] ?? 'yes', 'yes' ); ?> />
                                            <?php esc_html_e( 'Gebruik actuele live webinhoud (aanbevolen)', 'publion' ); ?>
                                        </label>
                                    </p>
                                    <p>
                                        <label for="publion_web_research_allowed_domains"><strong><?php esc_html_e( 'Alleen deze domeinen (optioneel)', 'publion' ); ?></strong></label><br>
                                        <textarea id="publion_web_research_allowed_domains" name="web_research_allowed_domains" rows="3" style="width:100%;"><?php echo esc_textarea( $settings['web_research_allowed_domains'] ?? '' ); ?></textarea>
                                        <span class="description"><?php esc_html_e( 'Eén domein per regel, zonder https://. Gebruik dit voor bijvoorbeeld overheid-, fabrikant- of kennisbankbronnen. Subdomeinen worden meegenomen.', 'publion' ); ?></span>
                                    </p>
                                    <p>
                                        <label for="publion_web_research_blocked_domains"><strong><?php esc_html_e( 'Deze domeinen uitsluiten (optioneel)', 'publion' ); ?></strong></label><br>
                                        <textarea id="publion_web_research_blocked_domains" name="web_research_blocked_domains" rows="3" style="width:100%;"><?php echo esc_textarea( $settings['web_research_blocked_domains'] ?? '' ); ?></textarea>
                                        <span class="description"><?php esc_html_e( 'Eén domein per regel. Handig voor concurrenten, forums of bronnen die niet bij je redactiebeleid passen.', 'publion' ); ?></span>
                                    </p>
                                    <p>
                                        <label>
                                            <input type="checkbox" id="publion_web_research_display_sources" name="web_research_display_sources" value="yes" <?php checked( $settings['web_research_display_sources'] ?? 'yes', 'yes' ); ?> />
                                            <?php esc_html_e( 'Plaats automatisch een klikbare bronnenlijst onder elk onderzocht artikel', 'publion' ); ?>
                                        </label>
                                    </p>
                                    <p style="margin-bottom:0;">
                                        <label for="publion_web_research_failure_mode"><strong><?php esc_html_e( 'Als brononderzoek mislukt', 'publion' ); ?></strong></label><br>
                                        <select id="publion_web_research_failure_mode" name="web_research_failure_mode">
                                            <option value="stop" <?php selected( $settings['web_research_failure_mode'] ?? 'stop', 'stop' ); ?>><?php esc_html_e( 'Stop de artikelgeneratie en toon een duidelijke foutmelding (aanbevolen)', 'publion' ); ?></option>
                                            <option value="continue" <?php selected( $settings['web_research_failure_mode'] ?? 'stop', 'continue' ); ?>><?php esc_html_e( 'Ga door zonder live bronnen en sla een waarschuwing op', 'publion' ); ?></option>
                                        </select>
                                    </p>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php esc_html_e( 'Ingestelde externe bron-URL\'s', 'publion' ); ?></th>
                            <td>
                                <textarea id="publion_preferred_external_urls" name="preferred_external_urls" rows="4" style="width:100%; max-width:600px;"><?php echo esc_textarea( $settings['preferred_external_urls'] ?? '' ); ?></textarea>
                                <p class="description" style="margin-top:6px; max-width: 600px;">
                                    <?php esc_html_e( 'Zet één veilige HTTPS-URL per regel. Publion gebruikt precies één passende URL per artikel en verzint nooit bronnen. Voeg hier minstens één relevante bron toe om een externe link in elk artikel te garanderen.', 'publion' ); ?>
                                </p>
                            </td>
                        </tr>

                        <tr class="publion-settings-section-row">
                            <th colspan="2" scope="colgroup">
                                <div class="publion-settings-section-heading">
                                    <span>4</span>
                                    <div>
                                        <h3><?php esc_html_e( 'SEO en artikelkwaliteit', 'publion' ); ?></h3>
                                        <p><?php esc_html_e( 'Bepaal de SEO-structuur en de opmaak die nieuwe artikelen meekrijgen.', 'publion' ); ?></p>
                                    </div>
                                </div>
                            </th>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e( 'SEO/GEO-kwaliteit', 'publion' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="rank_math_integration" id="publion_rank_math_integration" value="yes" <?php checked( $settings['rank_math_integration'] ?? '', 'yes' ); ?> />
                                    <?php esc_html_e( 'Gebruik de volledige SEO/GEO-contentcontrole voor nieuwe Publion-artikelen', 'publion' ); ?>
                                </label>
                                <p class="description" style="margin-top:6px; max-width:720px;">
                                    <?php esc_html_e( 'Publion controleert focus-keyword, SEO-titel, korte URL, meta description, intro, koppen, keyworddichtheid, lengte, alinea’s, links, inhoudsopgave en afbeeldingen. Mist een harde inhoudsvoorwaarde, dan volgt één feitelijke herstelronde; lukt dat niet, dan blijft de post altijd een concept. In de WordPress-editor toont de Publion SEO/GEO-controle precies wat nog redactionele aandacht vraagt.', 'publion' ); ?>
                                </p>
                                <div id="publion-rank-math-options" class="publion-rank-math-options">
                                    <p><strong><?php esc_html_e( 'Kwaliteitsregels voor nieuwe artikelen', 'publion' ); ?></strong></p>
                                    <div class="publion-rank-math-fields">
                                        <label><?php esc_html_e( 'Minimaal aantal woorden', 'publion' ); ?><input type="number" name="rank_math_target_word_count" id="publion_rank_math_target_word_count" min="1200" max="5000" value="<?php echo esc_attr( $settings['rank_math_target_word_count'] ?? 2500 ); ?>" /></label>
                                        <label><?php esc_html_e( 'Keyworddichtheid (alleen advies) van', 'publion' ); ?><input type="number" name="rank_math_density_min" id="publion_rank_math_density_min" min="0.5" max="2" step="0.1" value="<?php echo esc_attr( $settings['rank_math_density_min'] ?? 1 ); ?>" /></label>
                                        <label><?php esc_html_e( 'tot', 'publion' ); ?><input type="number" name="rank_math_density_max" id="publion_rank_math_density_max" min="0.5" max="2.5" step="0.1" value="<?php echo esc_attr( $settings['rank_math_density_max'] ?? 1.5 ); ?>" /></label>
                                        <label><?php esc_html_e( 'Max. woorden per alinea', 'publion' ); ?><input type="number" name="rank_math_max_paragraph_words" id="publion_rank_math_max_paragraph_words" min="60" max="180" value="<?php echo esc_attr( $settings['rank_math_max_paragraph_words'] ?? 120 ); ?>" /></label>
                                    </div>
                                    <div class="publion-rank-math-toggles">
                                        <label><input type="checkbox" id="publion_rank_math_auto_repair" <?php checked( $settings['rank_math_auto_repair'] ?? 'yes', 'yes' ); ?> /> <?php esc_html_e( 'Herstel harde inhoudschecks eenmaal automatisch', 'publion' ); ?></label>
                                        <label><input type="checkbox" id="publion_rank_math_publish_gate" <?php checked( ( $settings['rank_math_publish_gate'] ?? 'yes' ) === 'yes' ); ?> /> <?php esc_html_e( 'Bewaar bij harde fouten altijd als concept', 'publion' ); ?></label>
                                        <label><input type="checkbox" id="publion_rank_math_add_toc" <?php checked( $settings['rank_math_add_toc'] ?? 'yes', 'yes' ); ?> /> <?php esc_html_e( 'Voeg een inhoudsopgave toe', 'publion' ); ?></label>
                                        <label><input type="checkbox" id="publion_rank_math_check_image_alt" <?php checked( $settings['rank_math_check_image_alt'] ?? 'yes', 'yes' ); ?> /> <?php esc_html_e( 'Controleer keyword in relevante alt-tekst', 'publion' ); ?></label>
                                        <label><input type="checkbox" id="publion_rank_math_check_external_link" <?php checked( $settings['rank_math_check_external_link'] ?? 'yes', 'yes' ); ?> /> <?php esc_html_e( 'Toon externe bronlink als reviewpunt', 'publion' ); ?></label>
                                        <label><input type="checkbox" id="publion_rank_math_check_internal_link" <?php checked( $settings['rank_math_check_internal_link'] ?? 'yes', 'yes' ); ?> /> <?php esc_html_e( 'Toon relevante interne link als reviewpunt', 'publion' ); ?></label>
                                    </div>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php esc_html_e( 'Gestructureerde artikeldata', 'publion' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="structured_data" id="publion_structured_data" value="yes" <?php checked( $settings['structured_data'] ?? 'yes', 'yes' ); ?> />
                                    <?php esc_html_e( 'Voeg BlogPosting- en FAQ-data toe aan Publion-artikelen', 'publion' ); ?>
                                </label>
                                <p class="description"><?php esc_html_e( 'De data wordt dynamisch opgebouwd uit de definitieve titel, auteur, afbeeldingen en FAQ-sectie.', 'publion' ); ?></p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="publion_image_border_radius"><?php esc_html_e( 'Afronding van afbeeldingen', 'publion' ); ?></label></th>
                            <td>
                                <input type="number" id="publion_image_border_radius" name="image_border_radius" min="0" max="48" step="1" value="<?php echo esc_attr( $settings['image_border_radius'] ?? 8 ); ?>" /> px
                                <p class="description"><?php esc_html_e( 'Standaard 8px (0-48px). Wordt ook toegepast als het thema een eigen image-regel heeft. Nieuwe artikelen wisselen brede 16:9- en vierkante 1:1-beelden af; deze instelling geldt voor beide.', 'publion' ); ?></p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="publion_article_style_mode"><?php esc_html_e( 'Artikelstijl', 'publion' ); ?></label></th>
                            <td>
                                <select id="publion_article_style_mode" name="article_style_mode">
                                    <option value="inherit" <?php selected( $settings['article_style_mode'] ?? 'inherit', 'inherit' ); ?>><?php esc_html_e( 'Thema volgen (aanbevolen)', 'publion' ); ?></option>
                                    <option value="refined" <?php selected( $settings['article_style_mode'] ?? 'inherit', 'refined' ); ?>><?php esc_html_e( 'Verfijnde Publion-leesstijl', 'publion' ); ?></option>
                                </select>
                                <p class="description"><?php esc_html_e( 'Thema volgen behoudt de typografie en kleuren van je WordPress-thema. De verfijnde stijl voegt alleen een leesbreedte, nette links en consistente beeldweergave toe.', 'publion' ); ?></p>
                            </td>
                        </tr>

                        <tr class="publion-refined-style-control">
                            <th scope="row"><label for="publion_content_accent_color"><?php esc_html_e( 'Accentkleur voor links', 'publion' ); ?></label></th>
                            <td>
                                <input type="color" id="publion_content_accent_color" name="content_accent_color" value="<?php echo esc_attr( $settings['content_accent_color'] ?? '#4f46e5' ); ?>" />
                                <p class="description"><?php esc_html_e( 'Alleen gebruikt in de verfijnde Publion-leesstijl. Kies bij voorkeur een kleur die voldoende contrast heeft binnen je thema.', 'publion' ); ?></p>
                            </td>
                        </tr>

                        <tr class="publion-refined-style-control">
                            <th scope="row"><label for="publion_content_max_width"><?php esc_html_e( 'Maximale leesbreedte', 'publion' ); ?></label></th>
                            <td>
                                <input type="number" id="publion_content_max_width" name="content_max_width" min="560" max="1200" step="10" value="<?php echo esc_attr( $settings['content_max_width'] ?? 760 ); ?>" /> px
                                <p class="description"><?php esc_html_e( 'Alleen gebruikt in de verfijnde stijl. 720–800px is voor de meeste long-form artikelen prettig leesbaar.', 'publion' ); ?></p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="publion_custom_article_css"><?php esc_html_e( 'Eigen CSS voor Publion-artikelen', 'publion' ); ?></label></th>
                            <td>
                                <textarea id="publion_custom_article_css" name="custom_article_css" rows="7" style="width:100%; max-width:700px; font-family:monospace;" placeholder=".publion-generated-post .entry-content h2 { letter-spacing: -0.02em; }"><?php echo esc_textarea( $settings['custom_article_css'] ?? '' ); ?></textarea>
                                <p class="description"><?php esc_html_e( 'Optioneel voor beheerders. Scope elke selector met .publion-generated-post, zodat je alleen door Publion gemaakte artikelen aanpast. @import en &lt;style&gt;-tags worden verwijderd.', 'publion' ); ?></p>
                            </td>
                        </tr>

                        <tr class="publion-settings-section-row">
                            <th colspan="2" scope="colgroup">
                                <div class="publion-settings-section-heading">
                                    <span>5</span>
                                    <div>
                                        <h3><?php esc_html_e( 'Meten en opvolgen', 'publion' ); ?></h3>
                                        <p><?php esc_html_e( 'Koppel je rapporten, voeg een call-to-action toe en ontvang meldingen na creatie.', 'publion' ); ?></p>
                                    </div>
                                </div>
                            </th>
                        </tr>
                        <tr>
                            <th scope="row"><label for="publion_search_console_url"><?php esc_html_e( 'Google Search Console-rapport', 'publion' ); ?></label></th>
                            <td>
                                <input type="url" id="publion_search_console_url" name="search_console_url" style="width:100%; max-width:600px;" value="<?php echo esc_url( $settings['search_console_url'] ?? '' ); ?>" placeholder="https://search.google.com/search-console/..." />
                                <p class="description"><?php esc_html_e( 'Optioneel. Plak de link naar de juiste property of een opgeslagen rapport. Het dashboard opent die link rechtstreeks.', 'publion' ); ?></p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="publion_ga4_url"><?php esc_html_e( 'Google Analytics-rapport', 'publion' ); ?></label></th>
                            <td>
                                <input type="url" id="publion_ga4_url" name="ga4_url" style="width:100%; max-width:600px;" value="<?php echo esc_url( $settings['ga4_url'] ?? '' ); ?>" placeholder="https://analytics.google.com/..." />
                                <p class="description"><?php esc_html_e( 'Optioneel. Hiermee houd je Publion eenvoudig verbonden met je eigen GA4-overzicht, zonder extra toegangsrechten in deze plugin.', 'publion' ); ?></p>
                            </td>
                        </tr>

                        <tr>
                            <th><label for="publion_cta_enabled"><?php esc_html_e( 'Call-to-action in footer toevoegen?', 'publion' ); ?></label></th>
                            <td>
                                <select id="publion_cta_enabled" name="cta_enabled">
                                    <option value="no" <?php selected( $cta_enabled, 'no' ); ?>><?php esc_html_e( 'Nee', 'publion' ); ?></option>
                                    <option value="yes" <?php selected( $cta_enabled, 'yes' ); ?>><?php esc_html_e( 'Ja', 'publion' ); ?></option>
                                </select>
                            </td>
                        </tr>

                        <tr id="publion_cta_fields" style="<?php echo ( $cta_enabled === 'yes' ) ? '' : 'display:none;'; ?>">
                            <th><label for="publion_cta_text"><?php esc_html_e( 'Call-to-action tekst', 'publion' ); ?></label></th>
                            <td>
                                <input type="text" id="publion_cta_text" name="cta_text" style="width:100%;"
                                    value="<?php echo esc_attr( $settings['cta_text'] ?? '' ); ?>" />
                            </td>
                        </tr>

                        <tr class="publion_cta_link_row" style="<?php echo ( $cta_enabled === 'yes' ) ? '' : 'display:none;'; ?>">
                            <th><label for="publion_cta_link"><?php esc_html_e( 'Call-to-action link (URL)', 'publion' ); ?></label></th>
                            <td>
                                <input type="url" id="publion_cta_link" name="cta_link" style="width:100%;"
                                    value="<?php echo esc_url( $settings['cta_link'] ?? '' ); ?>" />
                            </td>
                        </tr>

                        <tr>
                            <th><label for="publion_notification_email"><?php esc_html_e( 'E-mailadres voor meldingen', 'publion' ); ?></label></th>
                            <td>
                                <input type="email" id="publion_notification_email" name="notification_email" style="width:250px;"
                                       value="<?php echo esc_attr( $settings['notification_email'] ?? '' ); ?>" />
                                <p class="description" style="margin-top:6px;">
                                    <?php esc_html_e( 'Optioneel: ontvang een e-mail wanneer automatisch een post is aangemaakt.', 'publion' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>

                    <button type="submit" id="publion-save-button" class="button button-primary"><?php esc_html_e( 'Instellingen opslaan', 'publion' ); ?></button>
                    <span id="publion-save-status" style="margin-left:10px;"></span>
                </form>
            </div>

            <!-- OpenAI/ChatGPT instellingen -->
            <div id="publion-settings" class="publion-tab-content" style="display:none;margin-top:20px;">
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
                    <h3 style="margin:0;font-size:1.09em;"><?php esc_html_e( 'OpenAI API-sleutel', 'publion' ); ?></h3>
                    <a href="https://platform.openai.com/api-keys" target="_blank" class="button"><?php esc_html_e( 'API-sleutel aanmaken', 'publion' ); ?></a>
                    <span class="publion-api-key-warning" style="color:#d90000; margin-left:10px; font-weight:bold; <?php echo esc_html( $warning_display ); ?>">
                        <?php esc_html_e( 'Voer een API-sleutel in om de AI-functie te laten werken.', 'publion' ); ?><br/>
                        <span style="color:#000000; font-weight:normal; font-size:12px;">
                            <strong><?php esc_html_e( 'Let op:', 'publion' ); ?></strong>
                            <?php esc_html_e( 'Vereist een Plus- of Pro-account bij OpenAI', 'publion' ); ?>
                        </span>
                    </span>
                </div>

                <div style="display:flex; align-items:flex-start; gap:18px; margin-top:22px;">
                    <!-- API Key Field -->
                    <div style="max-width:600px; flex:0 0 600px;">
                        <label class="screen-reader-text" for="publion_api_key"><?php esc_html_e( 'Nieuwe OpenAI API-sleutel', 'publion' ); ?></label>
                        <input type="password" name="publion_api_key" id="publion_api_key"
                            value="" placeholder="<?php echo esc_attr( empty( $openai_api_key ) ? 'sk-...' : __( 'Er is al een sleutel opgeslagen; plak hier alleen een vervanging.', 'publion' ) ); ?>"
                            style="width:100%;" autocomplete="new-password">
                        <p class="description publion-key-help">
                            <?php echo empty( $openai_api_key ) ? esc_html__( 'Plak hier je OpenAI API-sleutel.', 'publion' ) : esc_html__( 'Er is een API-sleutel opgeslagen. Die wordt om veiligheidsredenen niet opnieuw weergegeven.', 'publion' ); ?>
                        </p>
                        <button type="button" id="publion-save-api-key" class="button button-primary" style="margin-top:8px;">
                            <?php esc_html_e( 'Sleutel opslaan', 'publion' ); ?>
                        </button>
                        <span id="publion-api-key-status" class="publion-save-status" style="position:relative; top:8px;"></span>
                        <div style="margin-top:10px;">
                            <button type="button" id="publion-test-openai-connection" class="button">
                                <?php esc_html_e( 'Verbinding testen', 'publion' ); ?>
                            </button>
                            <span id="publion-connection-status" class="publion-save-status" aria-live="polite" style="margin-left:8px;"></span>
                            <p class="description" style="margin-top:6px;">
                                <?php esc_html_e( 'Controleert veilig of de opgeslagen API-sleutel werkt en of de gekozen tekst- en afbeeldingsmodellen voor dit API-project beschikbaar zijn. Dit maakt geen generatie.', 'publion' ); ?>
                            </p>
                        </div>

                        <div class="publion-model-control" style="margin-top:16px;">
                            <label for="publion_openai_model" style="display:block; font-weight:600; margin-bottom:6px;">
                                <?php esc_html_e( 'OpenAI-model', 'publion' ); ?>
                            </label>
                            <select id="publion_openai_model" aria-describedby="publion-model-help" style="width:100%; max-width:420px;">
                                <?php foreach ( $model_options as $value => $label ) : ?>
                                    <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $openai_model, $value ); ?>>
                                        <?php echo esc_html( $label ); ?>
                                    </option>
                                <?php endforeach; ?>
                                <option value="__custom__" <?php selected( ! empty( $custom_model ) ); ?>><?php esc_html_e( 'Eigen OpenAI model-ID…', 'publion' ); ?></option>
                            </select>
                            <div id="publion-custom-model-wrap" class="publion-custom-model-wrap">
                                <label for="publion_custom_openai_model"><?php esc_html_e( 'Exacte model-ID', 'publion' ); ?></label>
                                <input type="text" id="publion_custom_openai_model" value="<?php echo esc_attr( $openai_model ); ?>" placeholder="gpt-5.6-sol" maxlength="128" spellcheck="false" autocomplete="off" <?php disabled( empty( $custom_model ) ); ?>>
                            </div>
                            <p id="publion-model-help" class="description publion-model-help">
                                <?php esc_html_e( 'Kies Terra voor de beste balans bij artikelen, Sol voor maximale kwaliteit of Luna voor veel snelle taken. Een eigen ID moet exact overeenkomen met een model dat voor jouw OpenAI API-project beschikbaar is.', 'publion' ); ?>
                            </p>
                            <div class="publion-model-actions">
                                <button type="button" id="publion-save-model" class="button">
                                    <?php esc_html_e( 'Model opslaan', 'publion' ); ?>
                                </button>
                                <span id="publion-model-status" class="publion-save-status" aria-live="polite"></span>
                            </div>
                        </div>

                        <div class="publion-model-control publion-image-model-control" style="margin-top:12px;">
                            <label for="publion_openai_image_model" style="display:block; font-weight:600; margin-bottom:6px;">
                                <?php esc_html_e( 'OpenAI-afbeeldingsmodel', 'publion' ); ?>
                            </label>
                            <select id="publion_openai_image_model" aria-describedby="publion-image-model-help" style="width:100%; max-width:420px;">
                                <?php foreach ( $image_model_options as $value => $label ) : ?>
                                    <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $image_model, $value ); ?>>
                                        <?php echo esc_html( $label ); ?>
                                    </option>
                                <?php endforeach; ?>
                                <option value="__custom__" <?php selected( ! empty( $custom_image_model ) ); ?>><?php esc_html_e( 'Eigen afbeeldingsmodel-ID…', 'publion' ); ?></option>
                            </select>
                            <div id="publion-custom-image-model-wrap" class="publion-custom-model-wrap">
                                <label for="publion_custom_openai_image_model"><?php esc_html_e( 'Exacte afbeeldingsmodel-ID', 'publion' ); ?></label>
                                <input type="text" id="publion_custom_openai_image_model" value="<?php echo esc_attr( $image_model ); ?>" placeholder="gpt-image-2" maxlength="128" spellcheck="false" autocomplete="off" <?php disabled( empty( $custom_image_model ) ); ?>>
                            </div>
                            <p id="publion-image-model-help" class="description publion-model-help">
                                <?php esc_html_e( 'GPT Image 2 is de aanbevolen keuze. Een eigen model-ID moet afbeeldingen via de OpenAI Images API kunnen genereren én beschikbaar zijn voor jouw API-project.', 'publion' ); ?>
                            </p>
                            <div class="publion-model-actions">
                                <button type="button" id="publion-save-image-model" class="button">
                                    <?php esc_html_e( 'Afbeeldingsmodel opslaan', 'publion' ); ?>
                                </button>
                                <span id="publion-image-model-status" class="publion-save-status" aria-live="polite"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Instructions Accordion -->
                    <div class="publion-openai-instructions-accordion-wrap" style="min-width:230px;max-width:320px;margin:0;">
                        <div class="publion-openai-instructions-header" style="cursor:pointer;user-select:none;display:flex;align-items:center;gap:8px;font-size:1.07em;font-weight:600;">
                            <span><?php esc_html_e( 'Instructies', 'publion' ); ?></span>
                            <span class="dashicons dashicons-arrow-down publion-accordion-arrow" style="font-size:1.25em;transition:transform .2s;"></span>
                        </div>
                        <div class="publion-openai-instructions-body" style="display:none;padding:13px 16px 10px 8px;background:#f8f8fc;border-radius:6px;border:1px solid #eee;margin-top:5px;">
                            <ol style="margin:0 0 0 16px;padding:0;line-height:1.7;">
                                <li><?php esc_html_e( 'Klik op "API-sleutel aanmaken"', 'publion' ); ?></li>
                                <li><?php esc_html_e( 'Klik op de OpenAI-pagina op "Create new secret key"', 'publion' ); ?></li>
                                <li><?php esc_html_e( 'Voer een naam in, kies "Default Project", zet Permissions op All en klik op "Create secret key"', 'publion' ); ?></li>
                                <li><?php esc_html_e( 'Kopieer de sleutel, kom terug, plak in het veld en klik op "Sleutel opslaan"', 'publion' ); ?></li>
                                <li><strong><em><?php esc_html_e( 'Zorg dat je API-project facturatie en tegoed heeft. Een ChatGPT Plus- of Pro-abonnement is niet hetzelfde als API-facturatie.', 'publion' ); ?></em></strong></li>
                            </ol>
                        </div>
                    </div>
                </div>

                <h3 style="margin-bottom:4px; font-size:1.09em; margin-top:20px;">
                    <?php esc_html_e( 'Publion-prompt', 'publion' ); ?>
                    <?php if ( $openai_prompt === $default_prompt ) echo '(Standaard)'; ?>
                </h3>
                <p style="margin-top:0;">
                    <?php
                    esc_html_e( 'De Publion-prompt is de centrale redactionele instructie voor onderwerpideeën en volledige artikelinhoud.', 'publion' );
                    echo '<br>';
                    esc_html_e( 'Leg hier het doel van je website, doelgroep, expertise, tone of voice en merkpersoonlijkheid vast.', 'publion' );
                    echo '<br>';
                    ?>
                    <em><strong><?php esc_html_e( 'Tip:', 'publion' ); ?></strong> <?php esc_html_e( 'Maak de instructie concreet: benoem wat Publion wel en niet mag beweren, welke bronnen gewenst zijn en hoe een artikel moet klinken.', 'publion' ); ?></em>
                </p>

                <div style="width:600px; display:inline-block;">
                    <textarea name="publion_prompt" id="publion_prompt" style="width:100%;height:365px;"><?php echo esc_textarea( stripslashes( $openai_prompt ) ); ?></textarea>
                    <button type="button" id="publion-save-prompt" class="button button-primary" style="margin-top:8px;"><?php esc_html_e( 'Publion-prompt opslaan', 'publion' ); ?></button>
                    <span id="publion-prompt-status" class="publion-save-status" style="position:relative; top:8px;"></span>
                </div>

                <?php if ( $openai_prompt !== $default_prompt ) : ?>
                    <form method="post" style="display:inline;">
                        <?php wp_nonce_field( 'publion_reset_prompt' ); ?>
                        <button type="submit" name="publion_reset_prompt" class="button"><?php esc_html_e( 'Standaard Publion-prompt herstellen', 'publion' ); ?></button>
                    </form>
                <?php endif; ?>
            </div>

            <!-- Help and diagnostics -->
            <div id="publion-help" class="publion-tab-content" style="display:none;">
                <div class="publion-section-intro">
                    <p class="publion-eyebrow"><?php esc_html_e( 'HANDLEIDING', 'publion' ); ?></p>
                    <h2><?php esc_html_e( 'Een veilige, herhaalbare contentworkflow.', 'publion' ); ?></h2>
                    <p><?php esc_html_e( 'Gebruik Publion om sneller te werken, maar review iedere conceptpost altijd inhoudelijk vóór publicatie.', 'publion' ); ?></p>
                </div>
                <div class="publion-help-grid">
                    <section class="publion-dashboard-panel">
                        <h3><?php esc_html_e( 'Snel starten', 'publion' ); ?></h3>
                        <ol class="publion-guide-list">
                            <li><strong><?php esc_html_e( 'Verbind OpenAI.', 'publion' ); ?></strong> <?php esc_html_e( 'Voeg in AI-instellingen een API-sleutel toe en sla die op.', 'publion' ); ?></li>
                            <li><strong><?php esc_html_e( 'Kies een categorie.', 'publion' ); ?></strong> <?php esc_html_e( 'Laat Publion vijf invalshoeken maken en lees per voorstel de zoekintentie en FAQ-vragen.', 'publion' ); ?></li>
                            <li><strong><?php esc_html_e( 'Plan met aandacht.', 'publion' ); ?></strong> <?php esc_html_e( 'Zet alleen relevante onderwerpen in de wachtrij en kies een veilig publicatieritme.', 'publion' ); ?></li>
                            <li><strong><?php esc_html_e( 'Review elk concept.', 'publion' ); ?></strong> <?php esc_html_e( 'Controleer feiten, links, auteursrecht, merktoon, titel, meta description en afbeeldingen.', 'publion' ); ?></li>
                            <li><strong><?php esc_html_e( 'Meet en verbeter.', 'publion' ); ?></strong> <?php esc_html_e( 'Kijk na publicatie in Search Console naar vertoningen, klikken, CTR en positie. Start met pagina’s die veel vertoningen maar weinig klikken krijgen.', 'publion' ); ?></li>
                        </ol>
                    </section>
                    <section class="publion-dashboard-panel">
                        <h3><?php esc_html_e( 'Problemen oplossen', 'publion' ); ?></h3>
                        <dl class="publion-troubleshooting-list">
                            <div><dt><?php esc_html_e( 'Geen AI-antwoord', 'publion' ); ?></dt><dd><?php esc_html_e( 'Controleer de API-sleutel, facturatie, netwerkverbinding en het gekozen model. Probeer daarna opnieuw met één onderwerp.', 'publion' ); ?></dd></div>
                            <div><dt><?php esc_html_e( 'Afbeelding ontbreekt', 'publion' ); ?></dt><dd><?php esc_html_e( 'Publion gebruikt een placeholder wanneer beeldgeneratie faalt. Vervang die vóór publicatie en controleer de foutmelding in Overzicht.', 'publion' ); ?></dd></div>
                            <div><dt><?php esc_html_e( 'Geplande post verschijnt niet', 'publion' ); ?></dt><dd><?php esc_html_e( 'WordPress Cron draait bij websitebezoek. Controleer eerst de planning en gebruik zo nodig een echte servercron.', 'publion' ); ?></dd></div>
                            <div><dt><?php esc_html_e( 'Resultaten blijven uit', 'publion' ); ?></dt><dd><?php esc_html_e( 'Verbeter de zoekintentie, titel en inhoud op basis van Search Console-data. Publiceer geen ongecontroleerde of vergelijkbare artikelen in bulk.', 'publion' ); ?></dd></div>
                        </dl>
                    </section>
                </div>
                <nav class="publion-guide-nav" aria-label="<?php esc_attr_e( 'Onderdelen van de handleiding', 'publion' ); ?>">
                    <a href="#publion-guide-workflow"><?php esc_html_e( 'Workflow', 'publion' ); ?></a>
                    <a href="#publion-guide-quality"><?php esc_html_e( 'Kwaliteit & SEO', 'publion' ); ?></a>
                    <a href="#publion-guide-style"><?php esc_html_e( 'Beelden & styling', 'publion' ); ?></a>
                    <a href="#publion-guide-analytics"><?php esc_html_e( 'Meten', 'publion' ); ?></a>
                    <a href="#publion-guide-diagnosis"><?php esc_html_e( 'Diagnose', 'publion' ); ?></a>
                </nav>
                <section id="publion-guide-workflow" class="publion-dashboard-panel publion-guide-section">
                    <p class="publion-eyebrow"><?php esc_html_e( '01 - WERKWIJZE', 'publion' ); ?></p>
                    <h3><?php esc_html_e( 'Van categorie naar gecontroleerd concept', 'publion' ); ?></h3>
                    <div class="publion-guide-columns">
                        <div><strong><?php esc_html_e( '1. Verbinden en kader stellen', 'publion' ); ?></strong><p><?php esc_html_e( 'Sla de OpenAI API-sleutel op, kies een tekst- en afbeeldingsmodel en beschrijf doelgroep, expertise en toon in de Publion-prompt. Deel nooit sleutels of vertrouwelijke klantinformatie.', 'publion' ); ?></p></div>
                        <div><strong><?php esc_html_e( '2. Plannen met een SEO-brief', 'publion' ); ?></strong><p><?php esc_html_e( 'Kies een categorie. Publion leest de actuele contentkaart en vraagt vijf nieuwe kansen op. Beoordeel titel, focus-keyword, intentie, unieke invalshoek en FAQ-vragen voordat je iets bewaart.', 'publion' ); ?></p></div>
                        <div><strong><?php esc_html_e( '3. Wachtrij en concept', 'publion' ); ?></strong><p><?php esc_html_e( 'Voeg alleen passende kansen toe. Kies bij voorkeur Concept als poststatus. Met Nu maken zie je de feitelijke stappen: onderzoek, tekst, beeld, SEO, opslaan en afronden.', 'publion' ); ?></p></div>
                        <div><strong><?php esc_html_e( '4. Redactionele review', 'publion' ); ?></strong><p><?php esc_html_e( 'Controleer feiten, bronnen, links, merktoon, auteursrecht, meta description, afbeeldingen en placeholders. Publicatie blijft altijd een menselijke beslissing.', 'publion' ); ?></p></div>
                    </div>
                </section>
                <section id="publion-guide-quality" class="publion-dashboard-panel publion-guide-section">
                    <p class="publion-eyebrow"><?php esc_html_e( '02 - KWALITEIT', 'publion' ); ?></p>
                    <h3><?php esc_html_e( 'Originaliteit, SEO, SEA en GEO/AEO', 'publion' ); ?></h3>
                    <div class="publion-guide-columns">
                        <div><strong><?php esc_html_e( 'Geen duplicate content', 'publion' ); ?></strong><p><?php esc_html_e( 'Voorstellen en artikelen worden vergeleken met bestaande berichten, concepten en ingeplande posts. Een te vergelijkbare titel of inhoud wordt geblokkeerd. Controleer daarnaast zelf op zoekwoordcannibalisatie.', 'publion' ); ?></p></div>
                        <div><strong><?php esc_html_e( 'SEO en antwoordmachines', 'publion' ); ?></strong><p><?php esc_html_e( 'Werk vanuit een concrete zoekvraag, een direct antwoord, duidelijke h2- en h3-koppen, verifieerbare feiten, relevante interne links en alleen bruikbare bronnen. Vermijd keyword stuffing.', 'publion' ); ?></p></div>
                        <div><strong><?php esc_html_e( 'SEA verantwoord gebruiken', 'publion' ); ?></strong><p><?php esc_html_e( 'Laat advertentiebelofte, landingspagina en conversieactie op elkaar aansluiten. Gebruik het artikel niet als excuus voor verzonnen prijzen, claims of kortingen.', 'publion' ); ?></p></div>
                        <div><strong><?php esc_html_e( 'Structured data', 'publion' ); ?></strong><p><?php esc_html_e( 'Publion maakt optioneel BlogPosting- en FAQ-data. Bij Rank Math, Yoast of All in One SEO geeft Publion die artikeldata uit handen om dubbele schema-output te voorkomen.', 'publion' ); ?></p></div>
                    </div>
                </section>
                <section id="publion-guide-style" class="publion-dashboard-panel publion-guide-section">
                    <p class="publion-eyebrow"><?php esc_html_e( '03 - BEELD EN VORM', 'publion' ); ?></p>
                    <h3><?php esc_html_e( 'Afbeeldingen, alt-tekst en thema-integratie', 'publion' ); ?></h3>
                    <div class="publion-guide-columns">
                        <div><strong><?php esc_html_e( 'Beeldopmaak', 'publion' ); ?></strong><p><?php esc_html_e( 'Nieuwe artikelen gebruiken een ritme van brede 16:9- en vierkante 1:1-beelden. De afbeeldingsradius is standaard 8px en is onder Instellingen voor postcreatie aanpasbaar van 0 tot 48px.', 'publion' ); ?></p></div>
                        <div><strong><?php esc_html_e( 'Alt-tekst', 'publion' ); ?></strong><p><?php esc_html_e( 'Alt-tekst is kort en contextueel. Controleer in de mediabibliotheek of de tekst het daadwerkelijke beeld beschrijft; herhaal niet alleen het focus-keyword.', 'publion' ); ?></p></div>
                        <div><strong><?php esc_html_e( 'Thema volgen of verfijnen', 'publion' ); ?></strong><p><?php esc_html_e( 'Thema volgen behoudt de bestaande vormgeving. De verfijnde leesstijl voegt leesbreedte, consistente links en beeldweergave toe. Eigen CSS blijft beperkt tot Publion-artikelen.', 'publion' ); ?></p></div>
                        <div><strong><?php esc_html_e( 'Bestaande artikelen', 'publion' ); ?></strong><p><?php esc_html_e( 'De radiusregel geldt ook voor bestaande Publion-beelden. Vervang bestaande beelden of maak een nieuw concept als je de nieuwe 16:9/1:1-structuur wilt gebruiken.', 'publion' ); ?></p></div>
                    </div>
                </section>
                <section id="publion-guide-analytics" class="publion-dashboard-panel publion-guide-section">
                    <p class="publion-eyebrow"><?php esc_html_e( '04 - METEN', 'publion' ); ?></p>
                    <h3><?php esc_html_e( 'Verbeter met echte brondata', 'publion' ); ?></h3>
                    <p><?php esc_html_e( 'Voeg directe links naar de juiste Google Search Console-property en GA4-rapporten toe onder Instellingen voor postcreatie. Publion toont geen geschatte rankings, bezoekers of AI-verkeer.', 'publion' ); ?></p>
                    <ul class="publion-guide-checklist"><li><?php esc_html_e( 'Veel vertoningen en lage CTR: verbeter eerst titel en meta description.', 'publion' ); ?></li><li><?php esc_html_e( 'Veel klikken: analyseer welke zoekvragen en structuur werken en gebruik dat in nieuwe briefs.', 'publion' ); ?></li><li><?php esc_html_e( 'Dalende resultaten: controleer actualiteit, intentie, techniek en interne links voordat je meer content publiceert.', 'publion' ); ?></li></ul>
                </section>
                <section id="publion-guide-diagnosis" class="publion-dashboard-panel publion-guide-section">
                    <p class="publion-eyebrow"><?php esc_html_e( '05 - DIAGNOSE', 'publion' ); ?></p>
                    <h3><?php esc_html_e( 'Veilig problemen oplossen', 'publion' ); ?></h3>
                    <dl class="publion-troubleshooting-list publion-troubleshooting-list-wide">
                        <div><dt><?php esc_html_e( 'Lees een foutmelding stap voor stap', 'publion' ); ?></dt><dd><?php esc_html_e( 'Elke actuele fout noemt de actie, oorzaak, vervolgstap en foutreferentie. Gebruik de voorgestelde knop; deel bij ondersteuning alleen de referentie en nooit je API-sleutel.', 'publion' ); ?></dd></div>
                        <div><dt><?php esc_html_e( 'JSON-fout bij voorstellen', 'publion' ); ?></dt><dd><?php esc_html_e( 'Er is niets opgeslagen. Vernieuw de voorstellen; kies eventueel een ondersteund model of verkort een extreem lange Publion-prompt.', 'publion' ); ?></dd></div>
                        <div><dt><?php esc_html_e( 'Afbeelding of tekst mislukt', 'publion' ); ?></dt><dd><?php esc_html_e( 'Controleer de veilige foutmelding, API-project, facturatie, netwerk en gekozen model. Vervang placeholders altijd voor publicatie.', 'publion' ); ?></dd></div>
                        <div><dt><?php esc_html_e( 'Planning komt niet op gang', 'publion' ); ?></dt><dd><?php esc_html_e( 'WordPress Cron draait bij bezoek. Controleer tijdzone en planning; gebruik voor een betrouwbare productieplanning een echte servercron.', 'publion' ); ?></dd></div>
                    </dl>
                </section>
                <div class="publion-resource-bar">
                    <a class="button button-primary" href="#publion-guide-workflow"><?php esc_html_e( 'Naar de workflow', 'publion' ); ?></a>
                    <a class="button" href="<?php echo esc_url( PUBLION_URL . 'publion-documentation.html' ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open handleiding', 'publion' ); ?></a>
                    <a class="button" href="https://support.google.com/webmasters/answer/7576553" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Lees Search Console-metrics', 'publion' ); ?></a>
                    <a class="button" href="https://support.google.com/webmasters/answer/17010961" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Vind kansen met lage CTR', 'publion' ); ?></a>
                </div>
            </div>

            <p style="margin-top: 40px; font-size: 12px; color: #666;">
                <?php printf( esc_html__( 'Afbeeldingen in posts worden gegenereerd door OpenAI (%s).', 'publion' ), esc_html( $image_model ) ); ?>
                <?php
                $image_error = get_option( 'publion_last_image_error', '' );
                if ( ! empty( $image_error ) ) {
                    echo '<div class="publion-inline-error publion-operation-error" role="alert" style="margin-top:10px; max-width:760px; border-left:3px solid #dc2626;">';
                    echo '<button type="button" class="publion-dismiss-notice" aria-label="' . esc_attr__( 'Melding sluiten', 'publion' ) . '" title="' . esc_attr__( 'Melding sluiten', 'publion' ) . '">&times;</button>';
                    echo '<strong>' . esc_html__( 'Afbeelding heeft aandacht nodig', 'publion' ) . '</strong><br>' . esc_html( $image_error );
                    echo '</div>';
                }
                ?>
            </p>
        </div>
        <?php
    }
}
