<?php
function publion_get_allowed_openai_models() {
    $models = [
        'gpt-5.6-sol'           => 'GPT-5.6 Sol — hoogste kwaliteit',
        'gpt-5.6-terra'         => 'GPT-5.6 Terra — beste balans',
        'gpt-5.6-luna'          => 'GPT-5.6 Luna — snel en schaalbaar',
        'gpt-5.6'               => 'GPT-5.6 — alias voor Sol',
        'gpt-5.5'               => 'GPT-5.5',
        'gpt-5.4'               => 'GPT-5.4',
        'gpt-5.4-mini'          => 'GPT-5.4 Mini',
        'gpt-5.4-nano'          => 'GPT-5.4 Nano — voordelig voor volume',
        'gpt-5.2-2025-12-11'    => 'GPT-5.2 — eerdere versie',
        'gpt-5-mini-2025-08-07' => 'GPT-5 Mini — eerdere versie',
        'gpt-4o' => 'GPT-4o',
        'gpt-4o-mini' => 'GPT-4o Mini',
    ];

    return apply_filters( 'publion/openai_models', $models );
}

/**
 * Keep custom model IDs predictable and safe to pass to the API.
 * OpenAI model IDs use letters, numbers, dots, underscores, colons and hyphens.
 */
function publion_normalize_openai_model_id( $model ) {
    $model = sanitize_text_field( wp_strip_all_tags( (string) $model ) );
    $model = strtolower( trim( $model ) );

    if ( ! preg_match( '/^[a-z0-9][a-z0-9._:-]{0,127}$/', $model ) ) {
        return '';
    }

    return $model;
}

function publion_get_openai_model() {
    $default  = 'gpt-5.6-terra';
    $selected = publion_normalize_openai_model_id( get_option( 'publion_openai_model', $default ) );

    if ( '' === $selected ) {
        $selected = $default;
    }

    // A project can expose a model that is not in the curated list. Its availability
    // remains checked by OpenAI on the first request, while the format is validated here.
    return $selected;
}

/**
 * Returns settings for optional, live web-grounded article research.
 *
 * Research is a text generation path, so it deliberately uses the single
 * model selected in the OpenAI settings. Do not add a research-specific
 * model or fallback here: doing so makes the model shown in API usage differ
 * from the model selected by the user.
 */
function publion_get_web_research_settings() {
    $saved        = get_option( 'publion_post_settings', array() );
    $context_size = $saved['web_research_context_size'] ?? 'medium';
    $failure_mode = $saved['web_research_failure_mode'] ?? 'stop';

    return array(
        'enabled'          => ( $saved['web_research_enabled'] ?? 'no' ) === 'yes',
        'model'            => publion_get_openai_model(),
        'source_count'     => max( 1, min( 5, (int) ( $saved['web_research_source_count'] ?? 3 ) ) ),
        'context_size'     => in_array( $context_size, array( 'low', 'medium', 'high' ), true ) ? $context_size : 'medium',
        'live_access'      => ( $saved['web_research_live_access'] ?? 'yes' ) === 'yes',
        'allowed_domains'  => publion_parse_web_research_domains( $saved['web_research_allowed_domains'] ?? '' ),
        'blocked_domains'  => publion_parse_web_research_domains( $saved['web_research_blocked_domains'] ?? '' ),
        'display_sources'  => ( $saved['web_research_display_sources'] ?? 'yes' ) === 'yes',
        'failure_mode'     => in_array( $failure_mode, array( 'stop', 'continue' ), true ) ? $failure_mode : 'stop',
    );
}

/** Read the editor-configurable SEO/GEO safeguards with safe defaults. */
function publion_get_rank_math_settings( $saved = null ) {
    $saved = is_array( $saved ) ? $saved : get_option( 'publion_post_settings', array() );
    $density_min = max( 0.5, min( 2.0, (float) ( $saved['rank_math_density_min'] ?? 1.0 ) ) );
    $density_max = max( $density_min, min( 2.5, (float) ( $saved['rank_math_density_max'] ?? 1.5 ) ) );
	// An explicit Publish choice is the final publication preference. Do not
	// silently turn it into a draft because of a quality-review preference.
	$publish_gate = ( $saved['rank_math_publish_gate'] ?? 'yes' ) === 'yes' && ( $saved['post_status'] ?? 'draft' ) !== 'publish';
    return array(
        'enabled'             => ( $saved['rank_math_integration'] ?? 'no' ) === 'yes',
        'target_word_count'   => max( 1200, min( 5000, (int) ( $saved['rank_math_target_word_count'] ?? 2500 ) ) ),
        'density_min'         => $density_min,
        'density_max'         => $density_max,
        'max_paragraph_words' => max( 60, min( 180, (int) ( $saved['rank_math_max_paragraph_words'] ?? 120 ) ) ),
        'auto_repair'         => ( $saved['rank_math_auto_repair'] ?? 'yes' ) === 'yes',
        'publish_gate'        => $publish_gate,
        'add_toc'             => ( $saved['rank_math_add_toc'] ?? 'yes' ) === 'yes',
        'check_image_alt'     => ( $saved['rank_math_check_image_alt'] ?? 'yes' ) === 'yes',
        'check_external_link' => ( $saved['rank_math_check_external_link'] ?? 'yes' ) === 'yes',
        'check_internal_link' => ( $saved['rank_math_check_internal_link'] ?? 'yes' ) === 'yes',
    );
}

/**
 * Normalises one domain per line (or comma-separated) for OpenAI web-search
 * filters. Protocols and paths are intentionally removed: the API expects hostnames.
 */
function publion_parse_web_research_domains( $raw ) {
    $domains = preg_split( '/[\r\n,]+/', (string) $raw, -1, PREG_SPLIT_NO_EMPTY );
    $valid   = array();

    foreach ( (array) $domains as $domain ) {
        $domain = trim( (string) $domain );
        if ( '' === $domain ) {
            continue;
        }
        if ( ! preg_match( '/^https?:\/\//i', $domain ) ) {
            $domain = 'https://' . $domain;
        }
        $host = strtolower( (string) wp_parse_url( $domain, PHP_URL_HOST ) );
        if ( $host && preg_match( '/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i', $host ) ) {
            $valid[ $host ] = $host;
        }
    }

    return array_slice( array_values( $valid ), 0, 100 );
}

/**
 * Pull a concise, editor-safe source set from a Responses API web-search result.
 */
function publion_extract_web_research_sources( $response_data, $limit = 3 ) {
    $sources = array();
    $items   = is_array( $response_data['output'] ?? null ) ? $response_data['output'] : array();

    foreach ( $items as $item ) {
        $candidates = array();
        if ( is_array( $item['action']['sources'] ?? null ) ) {
            $candidates = array_merge( $candidates, $item['action']['sources'] );
        }
        if ( is_array( $item['sources'] ?? null ) ) {
            $candidates = array_merge( $candidates, $item['sources'] );
        }
        foreach ( (array) ( $item['content'] ?? array() ) as $content ) {
            foreach ( (array) ( $content['annotations'] ?? array() ) as $annotation ) {
                if ( 'url_citation' === ( $annotation['type'] ?? '' ) ) {
                    $candidates[] = $annotation;
                }
            }
        }

        foreach ( $candidates as $candidate ) {
            $url    = esc_url_raw( (string) ( $candidate['url'] ?? '' ), array( 'https' ) );
            $host   = (string) wp_parse_url( $url, PHP_URL_HOST );
            $title  = sanitize_text_field( (string) ( $candidate['title'] ?? '' ) );
            $site   = (string) wp_parse_url( home_url(), PHP_URL_HOST );
            if ( '' === $url || '' === $host || ( $site && 0 === strcasecmp( $host, $site ) ) ) {
                continue;
            }
            $key = untrailingslashit( strtolower( $url ) );
            if ( ! isset( $sources[ $key ] ) ) {
                $sources[ $key ] = array(
                    'url'   => $url,
                    'title' => $title ?: $host,
                );
            }
        }
    }

    return array_slice( array_values( $sources ), 0, max( 1, min( 5, (int) $limit ) ) );
}

function publion_get_web_research_response_text( $response_data ) {
    $text = sanitize_textarea_field( (string) ( $response_data['output_text'] ?? '' ) );
    if ( '' !== $text ) {
        return $text;
    }

    $parts = array();
    foreach ( (array) ( $response_data['output'] ?? array() ) as $item ) {
        foreach ( (array) ( $item['content'] ?? array() ) as $content ) {
            if ( ! empty( $content['text'] ) ) {
                $parts[] = sanitize_textarea_field( (string) $content['text'] );
            }
        }
    }

    return trim( implode( "\n", array_filter( $parts ) ) );
}

/**
 * Searches the live web before article generation. The source URLs returned by
 * the hosted tool become the sole automatically-added research sources; this
 * keeps the article traceable without pretending that a model browsed a URL.
 */
function publion_research_web_sources( $topic, $category_name, $seo_brief = array() ) {
    $settings = publion_get_web_research_settings();
    if ( ! $settings['enabled'] ) {
        return array( 'enabled' => false, 'sources' => array(), 'summary' => '' );
    }

    $api_key = get_option( 'publion_api_key', false );
    if ( ! $api_key ) {
        $api_key = maybe_unserialize( get_option( 'publion_api_key' ) );
    }
    if ( ! is_string( $api_key ) || '' === trim( $api_key ) ) {
        return new WP_Error( 'publion_web_research_key_missing', __( 'Live brononderzoek is ingeschakeld, maar er is geen geldige OpenAI API-sleutel gevonden.', 'publion' ) );
    }

    $focus_keyword = sanitize_text_field( $seo_brief['focus_keyword'] ?? $topic );
    $tool           = array(
        'type'                => 'web_search',
        'search_context_size' => $settings['context_size'],
        'external_web_access' => (bool) $settings['live_access'],
    );
    $filters = array();
    if ( ! empty( $settings['allowed_domains'] ) ) {
        $filters['allowed_domains'] = $settings['allowed_domains'];
    }
    if ( ! empty( $settings['blocked_domains'] ) ) {
        $filters['blocked_domains'] = $settings['blocked_domains'];
    }
    if ( ! empty( $filters ) ) {
        $tool['filters'] = $filters;
    }

    $research_prompt = sprintf(
        "Onderzoek actuele, feitelijke en niet-commerciÃ«le bronnen voor een Nederlands artikel over: %s. Categorie: %s. Focuszoekterm: %s. Zoek alleen informatie die direct relevant is voor de lezer. Geef geen advies of artikel terug; voer de webzoekactie uit en gebruik betrouwbare primaire bronnen, overheid, kennisinstituten of vakorganisaties waar mogelijk. Vermijd advertorials, affiliatepagina's, forums en directe concurrenten.",
        sanitize_text_field( $topic ),
        sanitize_text_field( $category_name ),
        $focus_keyword
    );
    $response = publion_openai_post(
        'https://api.openai.com/v1/responses',
        array(
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ),
            'body'    => wp_json_encode(
                array(
                    'model'       => $settings['model'],
                    'tools'       => array( $tool ),
                    'tool_choice' => 'required',
                    'include'     => array( 'web_search_call.action.sources' ),
                    'input'       => $research_prompt,
                )
            ),
            'timeout' => 120,
        ),
        'web_research'
    );

    if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
        $message = publion_get_openai_request_error( $response, $settings['model'] );
        if ( 'continue' === $settings['failure_mode'] ) {
            update_option( 'publion_last_openai_error', $message );
            return array( 'enabled' => true, 'sources' => array(), 'summary' => '', 'warning' => $message );
        }
        return new WP_Error( 'publion_web_research_failed', sprintf( __( 'Live brononderzoek kon niet worden uitgevoerd: %s', 'publion' ), $message ) );
    }

    $data    = json_decode( wp_remote_retrieve_body( $response ), true );
    $sources = is_array( $data ) ? publion_extract_web_research_sources( $data, $settings['source_count'] ) : array();
    if ( empty( $sources ) ) {
        $message = __( 'Live brononderzoek leverde geen bruikbare, externe HTTPS-bronnen op. Pas de domeinfilters aan of probeer opnieuw.', 'publion' );
        if ( 'continue' === $settings['failure_mode'] ) {
            update_option( 'publion_last_openai_error', $message );
            return array( 'enabled' => true, 'sources' => array(), 'summary' => '', 'warning' => $message );
        }
        return new WP_Error( 'publion_web_research_no_sources', $message );
    }

    return array(
        'enabled' => true,
        'sources' => $sources,
        'summary' => publion_get_web_research_response_text( $data ),
    );
}

function publion_format_web_research_context( $research ) {
    $sources = is_array( $research['sources'] ?? null ) ? $research['sources'] : array();
    if ( empty( $sources ) ) {
        return '';
    }

    $rows = array();
    foreach ( $sources as $source ) {
        $rows[] = '- ' . sanitize_text_field( $source['title'] ?? '' ) . ': ' . esc_url_raw( $source['url'] ?? '', array( 'https' ) );
    }
    $summary = publion_trim_text_at_word_boundary( (string) ( $research['summary'] ?? '' ), 6000 );

    $source_instruction = publion_get_web_research_settings()['display_sources']
        ? 'De geverifieerde bronnenlijst wordt automatisch onder het artikel geplaatst; maak zelf geen tweede bronnenlijst.'
        : 'Verwerk ten minste één passende bronlink natuurlijk in de inhoud, met duidelijke ankertekst.';

    return "\n\n=== ACTUELE WEBBRONNEN ===\n" . implode( "\n", $rows ) . ( $summary ? "\n\nOnderzoekssamenvatting (alleen als controleerbare achtergrond, geen bron om letterlijk over te nemen):\n" . $summary : '' ) . "\n=== EINDE WEBBRONNEN ===\nGebruik alleen deze bronnen voor feitelijke externe verwijzingen. Schrijf geen bronclaim die deze pagina's niet ondersteunt en verzin geen extra bron-URL's. " . $source_instruction;
}

function publion_append_web_research_sources( $html, $sources ) {
    if ( empty( $html ) || empty( $sources ) || ! is_array( $sources ) ) {
        return $html;
    }

    $items = array();
    foreach ( $sources as $source ) {
        $url   = esc_url_raw( (string) ( $source['url'] ?? '' ), array( 'https' ) );
        $title = sanitize_text_field( (string) ( $source['title'] ?? '' ) );
        if ( '' === $url ) {
            continue;
        }
        $items[] = '<li><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $title ?: wp_parse_url( $url, PHP_URL_HOST ) ) . '</a></li>';
    }

    if ( empty( $items ) ) {
        return $html;
    }

    return $html . '<div class="publion-research-sources"><h2>' . esc_html__( 'Bronnen en verdieping', 'publion' ) . '</h2><p>' . esc_html__( 'Voor dit artikel is actueel brononderzoek uitgevoerd. Controleer deze bronnen altijd voordat je publiceert.', 'publion' ) . '</p><ul>' . implode( '', $items ) . '</ul></div>';
}

/**
 * Return a user-safe explanation for failed OpenAI requests, without ever exposing a key.
 */
function publion_get_openai_request_error( $response, $model = '' ) {
    if ( is_wp_error( $response ) ) {
        $transport_error = strtolower( (string) $response->get_error_message() );
        if ( false !== strpos( $transport_error, 'timed out' ) || false !== strpos( $transport_error, 'timeout' ) || false !== strpos( $transport_error, 'curl error 28' ) ) {
            return __( 'OpenAI gaf niet op tijd een antwoord. Publion heeft de aanvraag automatisch opnieuw geprobeerd, maar kreeg nog geen reactie. Dit kan tijdelijk gebeuren bij een trage verbinding, firewall of drukte bij de dienst.', 'publion' );
        }
        return sprintf(
            /* translators: %s: transport error returned by WordPress. */
            __( 'OpenAI is niet bereikbaar: %s', 'publion' ),
            sanitize_text_field( $response->get_error_message() )
        );
    }

    $status = (int) wp_remote_retrieve_response_code( $response );
    $body   = json_decode( wp_remote_retrieve_body( $response ), true );
    $detail = is_array( $body ) ? sanitize_text_field( $body['error']['message'] ?? '' ) : '';
    $label  = $model ? ' (' . $model . ')' : '';

    if ( 401 === $status ) {
        return __( 'OpenAI heeft de API-sleutel geweigerd. Vervang de sleutel en controleer het API-project.', 'publion' );
    }

    if ( 429 === $status ) {
        return __( 'OpenAI heeft deze aanvraag tijdelijk beperkt. Controleer tegoed, facturatie en rate limits en probeer later opnieuw.', 'publion' );
    }

    if ( $detail ) {
        return sprintf(
            /* translators: 1: selected model ID, 2: error returned by OpenAI. */
            __( 'OpenAI kon het geselecteerde model%s niet gebruiken: %s', 'publion' ),
            $label,
            $detail
        );
    }

    return sprintf(
        /* translators: %d: HTTP status returned by OpenAI. */
        __( 'OpenAI gaf een onverwachte fout terug (HTTP %d).', 'publion' ),
        $status
    );
}

/** Decide whether an OpenAI request may be retried once. */
function publion_should_retry_openai_response( $response ) {
    if ( is_wp_error( $response ) ) {
        $message = strtolower( (string) $response->get_error_message() );
        foreach ( array( 'timed out', 'timeout', 'curl error 28', 'connection', 'could not resolve host', 'ssl' ) as $needle ) {
            if ( false !== strpos( $message, $needle ) ) {
                return true;
            }
        }
        return false;
    }

    $status = (int) wp_remote_retrieve_response_code( $response );
    return 408 === $status || $status >= 500;
}

/**
 * Send an OpenAI POST request with one bounded retry for transient transport
 * failures. No WordPress post is created until the response passes all local
 * validation and duplicate checks.
 */
function publion_openai_post( $url, $args, $operation = 'general' ) {
    $args     = is_array( $args ) ? $args : array();
    $attempts = max( 1, min( 2, (int) apply_filters( 'publion/openai_request_attempts', 2, $operation ) ) );
    $response = null;

    for ( $attempt = 1; $attempt <= $attempts; $attempt++ ) {
        $response = wp_remote_post( $url, $args );
        if ( ! publion_should_retry_openai_response( $response ) || $attempt === $attempts ) {
            return $response;
        }

        // Short exponential backoff with jitter; never retry in a tight loop.
        $delay_us = (int) apply_filters( 'publion/openai_retry_delay_microseconds', ( 500000 * $attempt ) + wp_rand( 0, 250000 ), $attempt, $operation, $response );
        if ( $delay_us > 0 ) {
            usleep( min( 2000000, $delay_us ) );
        }
    }

    return $response;
}

/**
 * Build a Chat Completions payload that is compatible with both the newer GPT-5
 * reasoning family and the retained GPT-4o models.
 */
function publion_build_openai_chat_body( $model, $messages, $max_output_tokens, $temperature = 0.7 ) {
    $body = array(
        'model'    => $model,
        'messages' => $messages,
    );

    if ( 0 === strpos( $model, 'gpt-5' ) ) {
        // GPT-5 reasoning models use max_completion_tokens and do not accept
        // custom sampling temperatures in Chat Completions.
        $body['max_completion_tokens'] = (int) $max_output_tokens;
    } else {
        $body['temperature'] = (float) $temperature;
        $body['max_tokens']  = (int) $max_output_tokens;
    }

    return $body;
}

/**
 * Read the local editorial archive on every AI run. The map preserves every
 * post title and heading, then adds a substantial body excerpt for context.
 * This keeps the request useful for normal API context limits while the
 * duplicate gate below still compares against the complete local post body.
 */
function publion_get_existing_content_map( $exclude_post_id = 0, $post_types = array( 'post' ) ) {
	$post_types = array_values( array_filter( array_map( 'sanitize_key', (array) $post_types ) ) );
	if ( empty( $post_types ) ) {
		$post_types = array( 'post' );
	}
    $posts = get_posts(
        array(
            'post_type'              => $post_types,
            'post_status'            => array( 'publish', 'future', 'draft', 'pending', 'private' ),
            'posts_per_page'         => -1,
            'orderby'                => 'modified',
            'order'                  => 'DESC',
            'post__not_in'           => $exclude_post_id ? array( (int) $exclude_post_id ) : array(),
            'ignore_sticky_posts'    => true,
            'suppress_filters'       => false,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        )
    );

    if ( empty( $posts ) ) {
        return array(
            'count'   => 0,
            'context' => "Er zijn nog geen bestaande WordPress-berichten. Schrijf daarom een duidelijk afgebakend, origineel eerste artikel.",
        );
    }

    // Preserve every title and heading, but keep body extracts compact enough
    // for a reliable API response on large editorial archives.
    $max_context_chars = (int) apply_filters( 'publion/content_map_max_chars', 120000 );
    $excerpt_chars     = (int) apply_filters( 'publion/content_map_excerpt_chars', 1200 );
    $context           = array();
    $used_chars        = 0;

    foreach ( $posts as $post ) {
        $title    = sanitize_text_field( get_the_title( $post ) );
        $headings = array();
        if ( preg_match_all( '/<h[1-3][^>]*>(.*?)<\/h[1-3]>/is', (string) $post->post_content, $matches ) ) {
            $headings = array_slice( array_filter( array_map( 'wp_strip_all_tags', $matches[1] ) ), 0, 12 );
        }

        $plain_content = preg_replace( '/\s+/', ' ', wp_strip_all_tags( strip_shortcodes( (string) $post->post_content ) ) );
        $plain_content = trim( (string) $plain_content );
        $excerpt       = function_exists( 'mb_substr' ) ? mb_substr( $plain_content, 0, $excerpt_chars ) : substr( $plain_content, 0, $excerpt_chars );
        $entry         = "BERICHT #" . (int) $post->ID . ": " . $title;
        $entry        .= "\nKoppen: " . ( ! empty( $headings ) ? implode( ' | ', array_map( 'sanitize_text_field', $headings ) ) : 'geen koppen gevonden' );
        $entry        .= "\nInhoudsextract: " . ( $excerpt ?: 'geen inhoudsextract beschikbaar' ) . "\n";

        // Always preserve an entry for the post; shorten only the body extract
        // when a very large archive approaches the API safety budget.
        if ( $used_chars + strlen( $entry ) > $max_context_chars ) {
            $entry = "BERICHT #" . (int) $post->ID . ": " . $title . "\nKoppen: " . ( ! empty( $headings ) ? implode( ' | ', array_map( 'sanitize_text_field', $headings ) ) : 'geen koppen gevonden' ) . "\n";
        }

        $context[]  = $entry;
        $used_chars += strlen( $entry );
    }

    return array(
        'count'   => count( $posts ),
        'context' => implode( "\n", $context ),
    );
}

function publion_normalize_content_for_comparison( $text ) {
    $text = wp_strip_all_tags( (string) $text );
    $text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
    $text = preg_replace( '/[^\p{L}\p{N}\s]+/u', ' ', $text );
    $text = preg_replace( '/\s+/u', ' ', $text );
    return trim( (string) $text );
}

function publion_get_content_word_set( $text ) {
    $words = preg_split( '/\s+/u', publion_normalize_content_for_comparison( $text ) );
    $set   = array();
    foreach ( (array) $words as $word ) {
        if ( 3 > ( function_exists( 'mb_strlen' ) ? mb_strlen( $word, 'UTF-8' ) : strlen( $word ) ) ) {
            continue;
        }
        $set[ $word ] = true;
    }
    return $set;
}

function publion_get_content_shingles( $text, $size = 5 ) {
    $raw_words = preg_split( '/\s+/u', publion_normalize_content_for_comparison( $text ) );
    $words     = array();
    $shingles  = array();
    foreach ( (array) $raw_words as $word ) {
        if ( 3 <= ( function_exists( 'mb_strlen' ) ? mb_strlen( $word, 'UTF-8' ) : strlen( $word ) ) ) {
            $words[] = $word;
        }
    }
    $word_count = count( $words );
    for ( $index = 0; $index <= $word_count - $size; $index++ ) {
        $shingles[ implode( ' ', array_slice( $words, $index, $size ) ) ] = true;
    }
    return $shingles;
}

/**
 * Check a candidate against every local post. Exact/near-identical titles and
 * repeated five-word sequences are blocked before WordPress creates a draft.
 */
function publion_find_existing_content_conflict( $candidate_title, $candidate_html = '', $exclude_post_id = 0 ) {
    $candidate_title = publion_normalize_content_for_comparison( $candidate_title );
    $candidate_words = $candidate_html ? publion_get_content_word_set( $candidate_html ) : array();
    $candidate_shingles = $candidate_html ? publion_get_content_shingles( $candidate_html ) : array();

    foreach ( get_posts(
        array(
            'post_type'              => 'post',
            'post_status'            => array( 'publish', 'future', 'draft', 'pending', 'private' ),
            'posts_per_page'         => -1,
            'post__not_in'           => $exclude_post_id ? array( (int) $exclude_post_id ) : array(),
            'ignore_sticky_posts'    => true,
            'suppress_filters'       => false,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        )
    ) as $post ) {
        $existing_title = publion_normalize_content_for_comparison( get_the_title( $post ) );
        $title_score    = 0.0;
        if ( $candidate_title && $existing_title ) {
            similar_text( $candidate_title, $existing_title, $title_score );
            if ( $candidate_title === $existing_title || $title_score >= 88 ) {
                return array( 'post_id' => (int) $post->ID, 'title' => get_the_title( $post ), 'reason' => 'titel' );
            }
        }

        if ( empty( $candidate_words ) || empty( $candidate_shingles ) ) {
            continue;
        }

        $existing_content  = (string) $post->post_content;
        $existing_words    = publion_get_content_word_set( $existing_content );
        $existing_shingles = publion_get_content_shingles( $existing_content );
        if ( empty( $existing_words ) || empty( $existing_shingles ) ) {
            continue;
        }

        $shared_words = count( array_intersect_key( $candidate_words, $existing_words ) );
        $word_union   = count( $candidate_words ) + count( $existing_words ) - $shared_words;
        $word_score   = $word_union ? $shared_words / $word_union : 0;
        $shared_phrases = count( array_intersect_key( $candidate_shingles, $existing_shingles ) );
        $shortest_phrase_set = min( count( $candidate_shingles ), count( $existing_shingles ) );
        $phrase_score = $shortest_phrase_set ? $shared_phrases / $shortest_phrase_set : 0;

        if ( ( $word_score >= 0.82 && $shared_words >= 80 ) || ( $phrase_score >= 0.16 && $shared_phrases >= 18 ) || ( $title_score >= 75 && $word_score >= 0.68 ) ) {
            return array( 'post_id' => (int) $post->ID, 'title' => get_the_title( $post ), 'reason' => 'inhoud' );
        }
    }

    return false;
}

/**
 * Reject a duplicate subject before any article or image request starts.
 *
 * The full-content validation still runs after generation; this inexpensive
 * title validation prevents an already-known duplicate from consuming a slot.
 */
function publion_validate_topic_originality( $topic, $exclude_post_id = 0 ) {
    $content_conflict = publion_find_existing_content_conflict( $topic, '', $exclude_post_id );
    if ( ! $content_conflict ) {
        return true;
    }

    $error = sprintf(
        /* translators: 1: duplicate type, 2: existing post title. */
        __( 'Concept overgeslagen: de nieuwe %1$s lijkt te veel op bestaand bericht “%2$s”. Kies een duidelijk andere zoekvraag of invalshoek.', 'publion' ),
        __( 'titel', 'publion' ),
        $content_conflict['title']
    );

    return new WP_Error( 'publion_duplicate_content', $error, array( 'conflict' => $content_conflict ) );
}

function publion_get_preferred_external_domain() {
    $settings = get_option( 'publion_post_settings', [] );
    $domain = sanitize_text_field( $settings['preferred_external_domain'] ?? '' );
    return trim( $domain );
}

function publion_get_preferred_external_urls() {
    $settings = get_option( 'publion_post_settings', [] );
    $raw = $settings['preferred_external_urls'] ?? '';
    if ( empty( $raw ) ) {
        return [];
    }
    $urls = array_filter( array_map( 'trim', explode( "\n", str_replace( "\r", '', (string) $raw ) ) ) );
    return $urls;
}

/**
 * Returns the editor-approved external sources that may be used in an article.
 *
 * A URL supplied by an editor is the only link Publion can guarantee without
 * fabricating a source. The optional domain remains backwards compatible and
 * is used as its HTTPS homepage when no more specific URL is supplied.
 */
function publion_get_configured_external_reference_urls() {
    $urls   = publion_get_preferred_external_urls();
    $domain = publion_get_preferred_external_domain();

    if ( '' !== $domain ) {
        $urls[] = preg_match( '/^https?:\/\//i', $domain ) ? $domain : 'https://' . $domain;
    }

    $site_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
    $valid     = array();

    foreach ( $urls as $url ) {
        $url    = esc_url_raw( trim( (string) $url ), array( 'https' ) );
        $scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
        $host   = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );

        if ( '' === $url || 'https' !== $scheme || '' === $host || ( $site_host && 0 === strcasecmp( $site_host, $host ) ) ) {
            continue;
        }

        $key = untrailingslashit( strtolower( $url ) );
        if ( ! isset( $valid[ $key ] ) ) {
            $valid[ $key ] = $url;
        }
    }

    return array_values( $valid );
}

/**
 * Checks whether a URL is one of the exact editor-approved source URLs.
 */
function publion_is_configured_external_reference_url( $url, $reference_urls = array() ) {
    $candidate = untrailingslashit( strtolower( esc_url_raw( (string) $url, array( 'https' ) ) ) );
    if ( '' === $candidate ) {
        return false;
    }

    foreach ( $reference_urls as $reference_url ) {
        if ( $candidate === untrailingslashit( strtolower( (string) $reference_url ) ) ) {
            return true;
        }
    }

    return false;
}

function publion_normalize_domain( $domain ) {
    $domain = trim( (string) $domain );
    if ( '' === $domain ) {
        return '';
    }
    if ( ! preg_match( '/^https?:\\/\\//i', $domain ) ) {
        $domain = 'https://' . $domain;
    }
    $host = wp_parse_url( $domain, PHP_URL_HOST );
    return $host ? strtolower( $host ) : '';
}

/**
 * Return a human-readable output language from the WordPress site locale.
 *
 * Content deliberately follows the site language, not an individual editor's
 * profile language: an English-speaking administrator should not accidentally
 * publish English content on a Dutch public website.
 */
function publion_get_site_content_language() {
	$locale   = (string) get_locale();
	$language = strtolower( strtok( $locale, '_' ) );
	$languages = array(
		'nl' => 'Nederlands',
		'en' => 'English',
		'de' => 'Deutsch',
		'fr' => 'Français',
		'es' => 'Español',
		'it' => 'Italiano',
		'pt' => 'Português',
		'pl' => 'Polski',
		'da' => 'Dansk',
		'sv' => 'Svenska',
		'no' => 'Norsk',
		'fi' => 'Suomi',
	);

	$output_language = $languages[ $language ] ?? $locale;
	return (string) apply_filters( 'publion_content_language', $output_language, $locale );
}

function publion_generate_chatgpt_html( $topic, $category_name, $seo_brief = array() ) {
    $topic_validation = publion_validate_topic_originality( $topic );
    if ( is_wp_error( $topic_validation ) ) {
        update_option( 'publion_last_openai_error', $topic_validation->get_error_message() );
        return $topic_validation;
    }

    $api_key = get_option('publion_api_key', false);
    if (!$api_key) {
        $api_key = maybe_unserialize(get_option('publion_api_key'));
    }

    $model = publion_get_openai_model();
	$content_language = publion_get_site_content_language();
    // A complete response is more reliable than joining continuations: the latter can
    // leave lists and headings open and produces repeated phrases in published HTML.
	$article_settings   = get_option( 'publion_post_settings', array() );
	$rank_math_settings = publion_get_rank_math_settings( $article_settings );
	$rank_math_enabled  = $rank_math_settings['enabled'];
	// Rank Math awards the full content-length score from 2,500 words. Keep
	// this target limited to the explicit Rank Math workflow because it has a
	// material impact on API cost and generation time.
	$target_word_count = $rank_math_enabled ? $rank_math_settings['target_word_count'] : 1200;
	$max_output_tokens = $rank_math_enabled ? 7000 : 4096;
    $max_iterations = 1;

    $html_output = '';
    $word_count = 0;
    $iteration = 0;

    $configured_reference_urls = publion_get_configured_external_reference_urls();
    $web_research              = publion_research_web_sources( $topic, $category_name, $seo_brief );
    if ( is_wp_error( $web_research ) ) {
        update_option( 'publion_last_openai_error', $web_research->get_error_message() );
        return $web_research;
    }
    $research_source_urls = array();
    foreach ( (array) ( $web_research['sources'] ?? array() ) as $source ) {
        if ( ! empty( $source['url'] ) ) {
            $research_source_urls[] = $source['url'];
        }
    }
    $reference_urls = array_values( array_unique( array_merge( $configured_reference_urls, $research_source_urls ) ) );
    $external_link_instruction = "\n\nGebruik externe links alleen als ze inhoudelijk echt iets toevoegen. Verzin, gok of reconstrueer nooit een URL. Gebruik voor externe links target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\".";
    if ( ! empty( $configured_reference_urls ) ) {
        $external_link_instruction .= " Voeg precies één relevante externe bronlink toe uit deze door de redacteur gecontroleerde URL's. Gebruik alleen een URL uit deze lijst, met duidelijke ankertekst, bij voorkeur in een korte slotparagraaf met de kop <h2>Bronnen en verdieping</h2>:\n- " . implode( "\n- ", $configured_reference_urls );
    } else {
        $external_link_instruction .= " Voeg alleen een andere bron toe als je de exacte, relevante HTTPS-URL zeker weet. Als je die zekerheid niet hebt, laat de link weg; een redacteur kan in de instellingen geverifieerde bron-URL's toevoegen om voor elk artikel een externe link te waarborgen.";
    }

    $focus_keyword  = sanitize_text_field( $seo_brief['focus_keyword'] ?? $topic );
    $search_intent  = sanitize_text_field( $seo_brief['search_intent'] ?? 'informatief' );
    $angle          = sanitize_text_field( $seo_brief['angle'] ?? '' );
	$rank_math_generation_instruction = publion_get_rank_math_generation_instruction( $focus_keyword, $rank_math_enabled );
    $faq_questions  = ! empty( $seo_brief['faq_questions'] ) && is_array( $seo_brief['faq_questions'] ) ? $seo_brief['faq_questions'] : array();
    $faq_instruction = '';
    if ( ! empty( $faq_questions ) ) {
        $faq_instruction = "\nGebruik aan het eind een <h2>Veelgestelde vragen</h2> met deze vragen als <h3>-koppen en een direct, feitelijk antwoord per vraag:\n- " . implode( "\n- ", array_map( 'sanitize_text_field', $faq_questions ) );
    }

    $content_map = publion_get_existing_content_map();
    $originality_instruction = "\n\nORIGINALITEITSCONTROLE: Lees eerst de volledige onderstaande contentkaart van " . (int) $content_map['count'] . " bestaande WordPress-berichten. Dit artikel moet een aantoonbaar nieuwe zoekvraag, invalshoek en koppenstructuur toevoegen. Kopieer, parafraseer of herstructureer geen bestaand bericht. Vermijd een titel die sterk lijkt op een bestaande titel en herhaal geen lange zinnen, FAQ's of stappenplannen uit de kaart.\n\n=== ACTUELE CONTENTKAART ===\n" . $content_map['context'] . "\n=== EINDE CONTENTKAART ===";

	$base_prompt = "Schrijf een origineel, behulpzaam en inhoudelijk sterk artikel in HTML over \"$topic\" binnen de categorie \"$category_name\". De primaire zoekterm is \"$focus_keyword\" en de zoekintentie is \"$search_intent\". Schrijf de volledige zichtbare artikelinhoud, inclusief titelkoppen, FAQ en alt-teksten, uitsluitend in $content_language.";
    if ( $angle ) {
        $base_prompt .= " De gekozen invalshoek is: \"$angle\".";
    }
    $base_prompt .= "

Schrijf voor mensen eerst en maak het antwoord ook goed citeerbaar door AI-zoekmachines: begin met een helder, direct antwoord, werk met beschrijvende <h2> en <h3>-koppen, korte alinea's, concrete voorbeelden en waar passend een lijst of stappenplan. Beantwoord de volledige zoekvraag en benoem beperkingen of context wanneer nodig. Verzin nooit feiten, cijfers, ervaringen, citaten of bronnen.

Maak de inhoud bruikbaar voor klassieke zoekmachines, antwoordmachines en generatieve zoekinterfaces: definieer belangrijke begrippen direct, houd feitelijke beweringen specifiek en controleerbaar, gebruik relevante entiteiten bij naam en plaats antwoorden vlak bij de vraag waarop ze reageren. Voeg geen tekst toe die alleen voor een algoritme is geschreven en doe geen ongefundeerde claims over resultaten, prijzen, kortingen of prestaties.

Wanneer de zoekintentie commercieel of transactioneel is, help de lezer eerlijk vergelijken met duidelijke selectiecriteria, beperkingen en een rustige volgende stap. Schrijf geen advertentietekst, verzin geen aanbiedingen en gebruik geen druk- of clickbaittaal.

Schrijf " . ( $rank_math_enabled ? sprintf( 'minimaal %d woorden', $target_word_count ) : 'circa 1.200 tot 1.600 woorden' ) . ", maar vermijd opvultekst en herhaling. Voeg geen paginamarkup toe zoals <!DOCTYPE html>, <head>, <body>, <header>, <footer>, <script> of <meta>. Maak de eerste kop een <h2>, geen <h1>. Gebruik uitsluitend semantische content-HTML: <p>, <h2>, <h3>, <ul>, <ol>, <strong>, <table> waar dat inhoudelijk helpt. Sluit elke HTML-tag. Plaats een kop, alinea, tabel of nieuw onderwerp nooit binnen een <ul> of <ol>; daarin staan uitsluitend <li>-elementen. Herhaal een kop, openingszin, woordgroep of FAQ-vraag niet.

Neem alleen links op naar relevante, betrouwbare en verifieerbare bronnen.$external_link_instruction" . publion_format_web_research_context( $web_research ) . "$rank_math_generation_instruction$faq_instruction$originality_instruction

Geef uitsluitend valide HTML-content terug, zonder uitleg, notities of Markdown.";

    $messages = [
        ['role' => 'system', 'content' => 'Je bent een deskundige contentschrijver. Je bent strikt feitelijk, vermijdt SEO-spam en geeft uitsluitend valide HTML terug. De taal van de zichtbare inhoud volgt altijd de WordPress-sitetaal: ' . $content_language . '.'],
        ['role' => 'user', 'content' => $base_prompt]
    ];

    while ($word_count < $target_word_count && $iteration < $max_iterations) {
        $response = publion_openai_post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body' => wp_json_encode( publion_build_openai_chat_body( $model, $messages, $max_output_tokens ) ),
            'timeout' => $rank_math_enabled ? 210 : 135
        ], 'article');

        if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
            $error = publion_get_openai_request_error( $response, $model );
            update_option( 'publion_last_openai_error', $error );
            return new WP_Error( 'publion_openai_request_failed', $error );
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $new_html = $body['choices'][0]['message']['content'] ?? '';

        if (!$new_html) {
            $error = __( 'OpenAI gaf geen bruikbare artikeltekst terug. Probeer een ander model of verkort de Publion-prompt.', 'publion' );
            update_option( 'publion_last_openai_error', $error );
            return new WP_Error( 'publion_openai_empty_response', $error );
        }

        $html_output .= $new_html;
        $word_count = str_word_count(wp_strip_all_tags($html_output));
        $iteration++;

    }

    // Clean & validate
    $html_output = publion_clean_html_output($html_output);
    $html_output = publion_normalize_article_html( $html_output );
    $html_output = publion_ensure_rank_math_keyword_intro( $html_output, $focus_keyword, $rank_math_enabled );
	$html_output = publion_ensure_rank_math_keyword_heading( $html_output, $focus_keyword, $rank_math_enabled );
    $html_output = publion_validate_links_in_html( $html_output, $reference_urls );
    $html_output = publion_enhance_external_links($html_output);
    $html_output = publion_ensure_configured_external_reference( $html_output, $configured_reference_urls, $topic );
	$html_output = preg_replace('/<h1>(.*?)<\/h1>/i', '<h2>$1</h2>', $html_output, 1);
	$html_output = str_ireplace(['<header>', '</header>'], '', $html_output);
	$html_output = publion_add_rank_math_table_of_contents( $html_output, $rank_math_enabled );
	if ( $rank_math_enabled && $rank_math_settings['auto_repair'] ) {
		$rank_math_report = publion_get_rank_math_quality_report( $html_output, $focus_keyword, $topic );
		if ( ! empty( $rank_math_report['failed_required'] ) ) {
			$repaired_html = publion_repair_rank_math_content( $html_output, $focus_keyword, $rank_math_report, $api_key, $model, $content_language );
			if ( ! is_wp_error( $repaired_html ) ) {
				$html_output = publion_ensure_rank_math_keyword_intro( $repaired_html, $focus_keyword, true );
				$html_output = publion_ensure_rank_math_keyword_heading( $html_output, $focus_keyword, true );
				$html_output = publion_validate_links_in_html( $html_output, $reference_urls );
				$html_output = publion_enhance_external_links( $html_output );
				$html_output = publion_ensure_configured_external_reference( $html_output, $configured_reference_urls, $topic );
				$html_output = publion_add_rank_math_table_of_contents( $html_output, true );
			} else {
				// Do not discard a complete draft when the optional repair request is
				// temporarily unavailable. The final, stored report makes the review
				// requirement explicit before a human publishes it.
				update_option( 'publion_last_openai_error', $repaired_html->get_error_message() );
			}
		}
	}
	$keywords = publion_extract_noun_keywords($html_output, $api_key, $model);
	$html_output = publion_auto_internal_links($html_output, $keywords);

    $content_conflict = publion_find_existing_content_conflict( $topic, $html_output );
    if ( $content_conflict ) {
        $error = sprintf(
            /* translators: 1: duplicate type, 2: existing post title. */
            __( 'Concept overgeslagen: de nieuwe %1$s lijkt te veel op bestaand bericht “%2$s”. Kies een duidelijk andere zoekvraag of invalshoek.', 'publion' ),
            'titel' === $content_conflict['reason'] ? __( 'titel', 'publion' ) : __( 'inhoud', 'publion' ),
            $content_conflict['title']
        );
        update_option( 'publion_last_openai_error', $error );
        return new WP_Error( 'publion_duplicate_content', $error );
    }

    if ( ! empty( $web_research['sources'] ) && publion_get_web_research_settings()['display_sources'] ) {
        $html_output = publion_append_web_research_sources( $html_output, $web_research['sources'] );
    }

    // Append CTA
    $settings = get_option('publion_post_settings', []);
    if (($settings['cta_enabled'] ?? 'no') === 'yes' && !empty($settings['cta_text']) && !empty($settings['cta_link'])) {
        $html_output .= "<div style='clear:both; padding-top:20px; margin-top:30px; border-top:1px solid #ccc;'>
            <p>Hulp nodig bij <strong>{$topic}</strong>?<br><strong><em><a class=\"ai-blog-cta\" href='" . esc_url($settings['cta_link']) . "'>{$settings['cta_text']}</a></em></strong></p>
        </div>";
    }

    // Rename Conclusion heading
    $html_output = preg_replace_callback(
        '/<h([2-4])[^>]*>(\s*)(Conclusion|Conclusie)(\s*)<\/h\1>/i',
        function($matches) {
            return '<h' . $matches[1] . '>Belangrijkste punten</h' . $matches[1] . '>';
        },
        $html_output
    );
    
    $html_output = preg_replace('/<h([1-2])>(.*?)<\/h\1>/i', '<h$1 class="publion-title">$2</h$1>', $html_output, 1);

    delete_option( 'publion_last_openai_error' );
    return $html_output;
}

/**
 * Extracts FAQ pairs from a generated article for optional JSON-LD output.
 * The schema is kept outside post content so WordPress sanitizers cannot strip it.
 */
function publion_extract_faq_pairs( $html ) {
    $faqs = array();
    if ( ! preg_match( '/<h2[^>]*>\s*(Veelgestelde vragen|FAQ)\s*<\/h2>(.*)$/is', $html, $section ) ) {
        return $faqs;
    }

    if ( preg_match_all( '/<h3[^>]*>(.*?)<\/h3>\s*<p[^>]*>(.*?)<\/p>/is', $section[2], $pairs, PREG_SET_ORDER ) ) {
        foreach ( $pairs as $pair ) {
            $question = trim( wp_strip_all_tags( $pair[1] ) );
            $answer   = trim( wp_strip_all_tags( $pair[2] ) );
            if ( $question && $answer ) {
                $faqs[] = array( 'question' => $question, 'answer' => $answer );
            }
            if ( count( $faqs ) >= 5 ) {
                break;
            }
        }
    }
    return $faqs;
}

function publion_store_article_seo_data( $post_id, $post_html, $focus_keyword = '' ) {
    update_post_meta( $post_id, '_publion_focus_keyword', sanitize_text_field( $focus_keyword ) );
    update_post_meta( $post_id, '_publion_faq_pairs', publion_extract_faq_pairs( $post_html ) );
}

/**
 * Check the two focus-keyword stores used by Publion and Rank Math. This is a
 * focused cannibalisation guard; the full title/content duplicate check still
 * runs separately.
 */
function publion_rank_math_focus_keyword_in_use( $focus_keyword ) {
    $focus_keyword = sanitize_text_field( $focus_keyword );
    if ( '' === $focus_keyword ) {
        return false;
    }

    $posts = get_posts(
        array(
            'post_type'              => 'post',
            'post_status'            => array( 'publish', 'future', 'draft', 'pending', 'private' ),
            'posts_per_page'         => 1,
            'fields'                 => 'ids',
            'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
                'relation' => 'OR',
                array(
                    'key'     => '_publion_focus_keyword',
                    'value'   => $focus_keyword,
                    'compare' => '=',
                ),
                array(
                    'key'     => 'rank_math_focus_keyword',
                    'value'   => $focus_keyword,
                    'compare' => '=',
                ),
            ),
            'no_found_rows'          => true,
            'ignore_sticky_posts'    => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        )
    );

    return ! empty( $posts );
}

function publion_validate_rank_math_focus_keyword( $focus_keyword ) {
    if ( ! publion_rank_math_focus_keyword_in_use( $focus_keyword ) ) {
        return true;
    }

    return new WP_Error(
        'publion_duplicate_focus_keyword',
        __( 'Deze focus-keyword is al aan een bestaand bericht gekoppeld. Kies een specifiekere zoekterm om keywordcannibalisatie te voorkomen.', 'publion' )
    );
}

/**
 * Build a compact, keyword-led permalink for new posts. A short slug is more
 * useful than copying a long editorial title verbatim, while WordPress still
 * guarantees uniqueness when it saves the post.
 */
function publion_build_rank_math_slug( $focus_keyword, $topic = '' ) {
    $slug = sanitize_title( $focus_keyword ?: $topic );
    if ( '' === $slug ) {
        return '';
    }

	// Rank Math evaluates the whole URL, not only the permalink fragment. Keep
	// enough room for the site URL while retaining the keyword-led slug.
	$home_url_length = strlen( untrailingslashit( home_url( '/' ) ) );
	$slug_max_length = max( 20, min( 75, 75 - $home_url_length - 1 ) );
	$was_truncated   = strlen( $slug ) > $slug_max_length;
	$slug = substr( $slug, 0, $slug_max_length );
    // Only remove a possible partial word after an actual truncation. Removing
    // the final segment unconditionally would drop the last word of a short,
    // otherwise perfect focus-keyword slug.
    if ( $was_truncated ) {
        $slug = preg_replace( '/-[^-]*$/', '', $slug );
    }
    return trim( (string) $slug, '-' );
}

function publion_build_rank_math_seo_title( $topic, $focus_keyword ) {
    $topic         = sanitize_text_field( $topic );
    $focus_keyword = sanitize_text_field( $focus_keyword );
    if ( '' === $focus_keyword ) {
        return $topic;
    }

    $normalized_topic   = publion_normalize_content_for_comparison( $topic );
    $normalized_keyword = publion_normalize_content_for_comparison( $focus_keyword );
    if ( 0 === strpos( $normalized_topic, $normalized_keyword ) && preg_match( '/\b(?:praktische|complete|essentiële|essentiele|slimme|krachtige|eenvoudige|ultimate|best|complete|essential|practical|powerful|easy)\b/iu', $topic ) ) {
        return $topic;
    }

    // Start with the exact keyword and use one restrained power word. This is
    // helpful for Rank Math's title checks without inventing numbers or claims.
    $prefix    = $focus_keyword . ': ' . __( 'praktische gids', 'publion' );
    $remaining = max( 0, 60 - mb_strlen( $prefix ) - 3 );
    if ( $remaining < 12 || '' === $topic ) {
        return publion_trim_text_at_word_boundary( $prefix, 60 );
    }

    return $prefix . ' - ' . publion_trim_text_at_word_boundary( $topic, $remaining );
}

function publion_build_rank_math_meta_description( $html, $focus_keyword ) {
    $description   = publion_build_meta_description( $html, 155 );
    $focus_keyword = sanitize_text_field( $focus_keyword );
    if ( '' === $focus_keyword || publion_article_has_focus_keyword( $description, $focus_keyword ) ) {
        return $description;
    }

    return publion_trim_text_at_word_boundary( $focus_keyword . ': ' . $description, 155 );
}

/**
 * Store the exact metadata that Rank Math reads and mirror the description to
 * WordPress' excerpt. The excerpt is an intentional fallback in Rank Math when
 * a theme or a site template does not expose the custom snippet value.
 */
function publion_store_rank_math_post_data( $post_id, $html, $focus_keyword, $topic ) {
    $post_id       = (int) $post_id;
    $focus_keyword = sanitize_text_field( $focus_keyword );
    if ( $post_id <= 0 || '' === $focus_keyword ) {
        return;
    }

    $seo_title        = publion_build_rank_math_seo_title( $topic, $focus_keyword );
    $meta_description = publion_build_rank_math_meta_description( $html, $focus_keyword );
    update_post_meta( $post_id, 'rank_math_focus_keyword', $focus_keyword );
    update_post_meta( $post_id, 'rank_math_title', $seo_title );
    update_post_meta( $post_id, 'rank_math_description', $meta_description );

    // Rank Math falls back to the excerpt when a custom snippet is unavailable.
    // These posts are generated by Publion, so keeping the excerpt in sync is
    // preferable to leaving that fallback dependent on the first paragraph.
    wp_update_post(
        array(
            'ID'           => $post_id,
            'post_excerpt' => $meta_description,
        )
    );
}

/** Insert Rank Math's own TOC block only when its integration is enabled. */
function publion_add_rank_math_table_of_contents( $html, $enabled ) {
    $settings = publion_get_rank_math_settings();
    if ( ! $enabled || ! $settings['add_toc'] || ! defined( 'RANK_MATH_VERSION' ) || false !== strpos( $html, 'rank-math/toc-block' ) || ! function_exists( 'serialize_block' ) ) {
        return $html;
    }

    $toc_block = serialize_block(
        array(
            'blockName'    => 'rank-math/toc-block',
            'attrs'        => array( 'title' => __( 'Inhoudsopgave', 'publion' ) ),
            'innerBlocks'  => array(),
            'innerHTML'    => '',
            'innerContent' => array(),
        )
    );

    return preg_replace( '/(?=<h2\b)/i', $toc_block . "\n", $html, 1 );
}

function publion_article_has_focus_keyword( $html, $focus_keyword, $limit = 0 ) {
    $focus_keyword = trim( publion_normalize_content_for_comparison( $focus_keyword ) );
    if ( '' === $focus_keyword ) {
        return false;
    }
    $text = publion_normalize_content_for_comparison( wp_strip_all_tags( (string) $html ) );
    if ( $limit > 0 ) {
        $text = substr( $text, 0, $limit );
    }
    return false !== strpos( $text, $focus_keyword );
}

/**
 * Applies Rank Math's meaningful checks while protecting editorial quality.
 */
function publion_get_rank_math_generation_instruction( $focus_keyword, $enabled ) {
    if ( ! $enabled || '' === trim( (string) $focus_keyword ) ) {
        return '';
    }

    return "\n\nSEO/GEO-KWALITEITSCONTROLE: Gebruik de exacte focus-keyword \"" . sanitize_text_field( $focus_keyword ) . "\" natuurlijk in de eerste alinea, in ten minste één beschrijvende <h2> of <h3> en ongeveer 1 tot 1,5% van de zichtbare tekst. Vermijd keyword stuffing en ga nooit boven 2,5%. Houd alle alinea's korter dan 120 woorden. Gebruik minimaal vier inhoudelijk relevante afbeeldingen; de eerste afbeelding moet het hoofdonderwerp zichtbaar tonen, zodat de alt-tekst de focus-keyword natuurlijk kan bevatten. Een betrouwbare externe bronlink is verplicht zodra er een gecontroleerde bron of live onderzoeksbron beschikbaar is; gebruik nooit nofollow voor zo'n redactionele bron. Verwerk relevante interne links zodra er passende bestaande pagina's zijn. Voeg een getal, sentimentwoord of power word alleen toe wanneer het feitelijk is en de titel daardoor niet misleidend wordt.";
}

function publion_ensure_rank_math_keyword_intro( $html, $focus_keyword, $enabled ) {
    if ( ! $enabled || '' === trim( (string) $focus_keyword ) ) {
        return $html;
    }

    // Rank Math evaluates the opening content. A keyword in an early heading or
    // a table of contents is not a substitute for one in the first paragraph.
    if ( preg_match( '/<p\b[^>]*>(.*?)<\/p>/is', (string) $html, $first_paragraph ) && publion_article_has_focus_keyword( $first_paragraph[1], $focus_keyword ) ) {
        return $html;
    }

    $sentence = ' ' . sprintf(
        /* translators: %s: focus keyword. */
        esc_html__( 'In dit artikel lees je praktische aandachtspunten over %s.', 'publion' ),
        '<strong>' . esc_html( $focus_keyword ) . '</strong>'
    );
    // esc_html__ treats the markup as text; restore only our own safe emphasis.
    $sentence = str_replace( array( '&lt;strong&gt;', '&lt;/strong&gt;' ), array( '<strong>', '</strong>' ), $sentence );

    if ( preg_match( '/<p\b[^>]*>.*?<\/p>/is', $html, $match ) ) {
        $first_paragraph = preg_replace( '/<\/p>$/i', $sentence . '</p>', $match[0] );
        return preg_replace( '/<p\b[^>]*>.*?<\/p>/is', $first_paragraph, $html, 1 );
    }

    return '<p>' . ltrim( $sentence ) . '</p>' . $html;
}

function publion_ensure_rank_math_keyword_heading( $html, $focus_keyword, $enabled ) {
    if ( ! $enabled || '' === trim( (string) $focus_keyword ) ) {
        return $html;
    }

    if ( preg_match_all( '/<h[2-3][^>]*>(.*?)<\/h[2-3]>/is', $html, $headings ) ) {
        foreach ( $headings[1] as $heading ) {
            if ( publion_article_has_focus_keyword( $heading, $focus_keyword ) ) {
                return $html;
            }
        }
    }

    return preg_replace_callback(
        '/<h2([^>]*)>(.*?)<\/h2>/is',
        static function ( $match ) use ( $focus_keyword ) {
            return '<h2' . $match[1] . '>' . esc_html( $focus_keyword ) . ': ' . $match[2] . '</h2>';
        },
        $html,
        1
    );
}

/**
 * Count visible words in a way that also works for Dutch and other UTF-8 site
 * languages. str_word_count() is not reliable for accented characters.
 */
function publion_rank_math_visible_word_count( $html ) {
    $text = wp_strip_all_tags( (string) $html );
    return preg_match_all( '/[\p{L}\p{N}]+(?:[\'’\-][\p{L}\p{N}]+)*/u', $text, $matches );
}

function publion_rank_math_focus_keyword_occurrences( $html, $focus_keyword ) {
    $focus_keyword = trim( publion_normalize_content_for_comparison( $focus_keyword ) );
    if ( '' === $focus_keyword ) {
        return 0;
    }

    $text    = publion_normalize_content_for_comparison( wp_strip_all_tags( (string) $html ) );
    $pattern = '/(?<![\p{L}\p{N}])' . preg_quote( $focus_keyword, '/' ) . '(?![\p{L}\p{N}])/iu';
    return preg_match_all( $pattern, $text, $matches );
}

function publion_rank_math_link_quality( $html ) {
    $site_host = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
    $site_host = is_string( $site_host ) ? strtolower( preg_replace( '/^www\./', '', $site_host ) ) : '';
    $result    = array(
        'internal_links'         => 0,
        'external_links'         => 0,
        'followed_external_links' => 0,
    );

    if ( ! preg_match_all( '/<a\b[^>]*href\s*=\s*(["\'])(.*?)\1[^>]*>/is', (string) $html, $links ) ) {
        return $result;
    }

    foreach ( $links[0] as $index => $tag ) {
        $url  = html_entity_decode( $links[2][ $index ], ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' );
        $host = wp_parse_url( $url, PHP_URL_HOST );
        if ( ! is_string( $host ) || '' === $host ) {
            continue;
        }
        $host = strtolower( preg_replace( '/^www\./', '', $host ) );
        if ( '' !== $site_host && ( $host === $site_host || substr( $host, - strlen( '.' . $site_host ) ) === '.' . $site_host ) ) {
            $result['internal_links']++;
            continue;
        }

        $result['external_links']++;
        if ( ! preg_match( '/\brel\s*=\s*(["\'])[^"\']*\bnofollow\b[^"\']*\1/i', $tag ) ) {
            $result['followed_external_links']++;
        }
    }

    return $result;
}

/**
 * Creates an auditable Rank Math readiness report. It deliberately records
 * conditions that depend on the site (such as available internal links) rather
 * than fabricating links or clickbait just to chase a score.
 */
function publion_get_rank_math_quality_report( $html, $focus_keyword, $post_title = '' ) {
    $settings           = publion_get_rank_math_settings();
    $word_count         = publion_rank_math_visible_word_count( $html );
    $keyword_occurrences = publion_rank_math_focus_keyword_occurrences( $html, $focus_keyword );
    $density            = $word_count > 0 ? round( ( $keyword_occurrences / $word_count ) * 100, 2 ) : 0;
    $paragraphs         = array();
    $long_paragraphs    = 0;
    if ( preg_match_all( '/<p\b[^>]*>(.*?)<\/p>/is', (string) $html, $paragraphs ) ) {
        foreach ( $paragraphs[1] as $paragraph ) {
            if ( publion_rank_math_visible_word_count( $paragraph ) > $settings['max_paragraph_words'] ) {
                $long_paragraphs++;
            }
        }
    }

    $links      = publion_rank_math_link_quality( $html );
    $image_tags = array();
    preg_match_all( '/<img\b[^>]*>/is', (string) $html, $image_tags );
    $has_keyword_alt = false;
    foreach ( $image_tags[0] as $image_tag ) {
        if ( preg_match( '/\balt\s*=\s*(["\'])(.*?)\1/is', $image_tag, $alt_match ) && publion_article_has_focus_keyword( $alt_match[2], $focus_keyword ) ) {
            $has_keyword_alt = true;
            break;
        }
    }

    $seo_title       = publion_build_rank_math_seo_title( $post_title, $focus_keyword );
    $seo_description = publion_build_rank_math_meta_description( $html, $focus_keyword );
    $seo_slug        = publion_build_rank_math_slug( $focus_keyword, $post_title );
    $seo_url         = trailingslashit( home_url( '/' ) ) . ltrim( $seo_slug, '/' );
    $title_has_keyword_early = '' !== trim( (string) $focus_keyword ) && false !== strpos(
        mb_strtolower( mb_substr( $seo_title, 0, max( 1, (int) ceil( mb_strlen( $seo_title ) / 2 ) ) ) ),
        mb_strtolower( trim( (string) $focus_keyword ) )
    );
    $title_has_number = (bool) preg_match( '/\d/u', $seo_title );
    $title_has_power_word = (bool) preg_match( '/\b(?:beste|praktische|complete|essentiële|essentiele|slimme|krachtige|eenvoudige|ultimate|best|complete|essential|practical|powerful|easy)\b/iu', $seo_title );
    $title_has_sentiment = (bool) preg_match( '/\b(?:succesvol|veilig|sterk|effectief|onmisbaar|geweldig|betrouwbaar|successful|safe|strong|effective|essential|great|reliable)\b/iu', $seo_title );
    $has_keyword_heading = false;
    if ( preg_match_all( '/<h[2-3][^>]*>(.*?)<\/h[2-3]>/is', (string) $html, $headings ) ) {
        foreach ( $headings[1] as $heading ) {
            if ( publion_article_has_focus_keyword( $heading, $focus_keyword ) ) {
                $has_keyword_heading = true;
                break;
            }
        }
    }

    $checks = array(
        'focus_keyword_in_seo_title' => $title_has_keyword_early,
        'focus_keyword_in_meta_description' => publion_article_has_focus_keyword( $seo_description, $focus_keyword ),
        'focus_keyword_in_url'       => publion_article_has_focus_keyword( $seo_slug, $focus_keyword ),
        'focus_keyword_in_intro'     => (bool) ( preg_match( '/<p\b[^>]*>(.*?)<\/p>/is', (string) $html, $first_paragraph ) && publion_article_has_focus_keyword( $first_paragraph[1], $focus_keyword ) ),
        'focus_keyword_in_content'   => $keyword_occurrences > 0,
        'focus_keyword_in_heading'   => $has_keyword_heading,
        'focus_keyword_density'      => $density >= $settings['density_min'] && $density <= $settings['density_max'],
        'content_length'             => $word_count >= $settings['target_word_count'],
        'short_paragraphs'           => 0 === $long_paragraphs,
        'table_of_contents'          => ! $settings['add_toc'] || false !== strpos( (string) $html, 'rank-math/toc-block' ),
        'media_count'                => count( $image_tags[0] ) >= 4,
        'focus_keyword_in_image_alt' => ! $settings['check_image_alt'] || $has_keyword_alt,
        'external_link'              => ! $settings['check_external_link'] || $links['external_links'] > 0,
        'followed_external_link'     => ! $settings['check_external_link'] || $links['followed_external_links'] > 0,
        'internal_link'              => ! $settings['check_internal_link'] || $links['internal_links'] > 0,
        'short_url'                  => strlen( $seo_url ) <= 75,
        'number_in_seo_title'        => $title_has_number,
        'power_word_in_seo_title'    => $title_has_power_word,
        'sentiment_in_seo_title'     => $title_has_sentiment,
    );

    $required_checks = array( 'focus_keyword_in_seo_title', 'focus_keyword_in_meta_description', 'focus_keyword_in_url', 'focus_keyword_in_intro', 'focus_keyword_in_content', 'focus_keyword_in_heading', 'focus_keyword_density', 'content_length', 'short_paragraphs' );
    $failed_required = array();
    foreach ( $required_checks as $check ) {
        if ( empty( $checks[ $check ] ) ) {
            $failed_required[] = $check;
        }
    }

    // A number is intentionally not a requirement: adding one where no real
    // quantity exists would make a title less trustworthy, not more useful.
    $advisory_checks = array( 'table_of_contents', 'media_count', 'focus_keyword_in_image_alt', 'external_link', 'followed_external_link', 'internal_link', 'short_url', 'power_word_in_seo_title', 'sentiment_in_seo_title' );
    $needs_editor_review = array();
    foreach ( $advisory_checks as $check ) {
        if ( empty( $checks[ $check ] ) ) {
            $needs_editor_review[] = $check;
        }
    }

    return array(
        'version'             => 1,
        'focus_keyword'       => sanitize_text_field( $focus_keyword ),
        'word_count'          => $word_count,
        'keyword_occurrences' => $keyword_occurrences,
        'keyword_density'     => $density,
        'long_paragraphs'     => $long_paragraphs,
        'image_count'         => count( $image_tags[0] ),
        'seo_title'           => $seo_title,
        'meta_description'    => $seo_description,
        'seo_url_length'      => strlen( $seo_url ),
        'settings'            => $settings,
        'links'               => $links,
        'checks'              => $checks,
        'failed_required'     => $failed_required,
        'needs_editor_review' => $needs_editor_review,
        'status'              => empty( $failed_required ) ? 'ready' : 'review_required',
    );
}

/**
 * Requests one factual rewrite when the deterministic Rank Math content gate
 * finds a failure. It never asks the model to invent a numbered list, emotion
 * or a link merely to influence a superficial score.
 */
function publion_repair_rank_math_content( $html, $focus_keyword, $report, $api_key, $model, $content_language ) {
    $failed_checks = array_map( 'sanitize_key', (array) ( $report['failed_required'] ?? array() ) );
    if ( empty( $failed_checks ) ) {
        return $html;
    }
    if ( empty( $api_key ) ) {
        return new WP_Error( 'publion_rank_math_repair_key_missing', __( 'De SEO/GEO-kwaliteitscontrole kon niet worden hersteld omdat de OpenAI API-sleutel ontbreekt.', 'publion' ) );
    }

    $requirements = array();
    if ( in_array( 'content_length', $failed_checks, true ) ) {
        $requirements[] = 'maak de zichtbare tekst minimaal 2.500 woorden zonder opvultekst';
    }
    if ( in_array( 'focus_keyword_density', $failed_checks, true ) ) {
        $requirements[] = 'gebruik de exacte primaire zoekterm natuurlijk tussen 1,0% en 1,5% van de zichtbare tekst, nooit boven 2,5%';
    }
    if ( in_array( 'short_paragraphs', $failed_checks, true ) ) {
        $requirements[] = 'splits elke alinea die langer is dan 120 woorden op';
    }
    if ( in_array( 'focus_keyword_in_intro', $failed_checks, true ) ) {
        $requirements[] = 'verwerk de exacte primaire zoekterm in de eerste alinea';
    }
    if ( in_array( 'focus_keyword_in_heading', $failed_checks, true ) ) {
        $requirements[] = 'verwerk de exacte primaire zoekterm in minstens één beschrijvende h2 of h3';
    }

    $prompt = "Herschrijf uitsluitend de onderstaande HTML voor een bestaand artikel in $content_language. De primaire zoekterm is \"" . sanitize_text_field( $focus_keyword ) . "\". Behoud alle feitelijke claims, bronlinks, koppen, FAQ's en de betekenis; verzin geen cijfers, bronnen, ervaringen, lijstlengtes of clickbait. Voldoe aan deze concrete kwaliteitscorrecties:\n- " . implode( "\n- ", $requirements ) . "\n\nGeef uitsluitend complete, geldige semantische HTML terug, zonder Markdown of toelichting.\n\n=== HTML ===\n" . (string) $html . "\n=== EINDE HTML ===";
    $response = publion_openai_post(
        'https://api.openai.com/v1/chat/completions',
        array(
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ),
            'body'    => wp_json_encode( publion_build_openai_chat_body( $model, array(
                array( 'role' => 'system', 'content' => 'Je bent een nauwkeurige redacteur. Lever uitsluitend veilige, feitelijke HTML terug.' ),
                array( 'role' => 'user', 'content' => $prompt ),
            ), 7000 ) ),
            'timeout' => 210,
        ),
        'rank_math_repair'
    );
    if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
        return new WP_Error( 'publion_rank_math_repair_failed', __( 'De SEO/GEO-kwaliteitscontrole kon het concept niet veilig herstellen. Het oorspronkelijke concept blijft behouden voor redactionele review.', 'publion' ) );
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    $html = $body['choices'][0]['message']['content'] ?? '';
    if ( '' === trim( (string) $html ) ) {
        return new WP_Error( 'publion_rank_math_repair_empty', __( 'De SEO/GEO-kwaliteitscontrole kreeg geen bruikbare herstelde artikeltekst terug.', 'publion' ) );
    }

    return publion_normalize_article_html( publion_clean_html_output( $html ) );
}

function publion_auto_internal_links($html, $keywords) {
    if (empty($keywords)) return $html;

    // Extract existing <a> tags to prevent duplicate or nested links
    preg_match_all('/<a\b[^>]*>.*?<\/a>/is', $html, $a_matches);
    $placeholders = [];
    foreach ($a_matches[0] as $i => $a_tag) {
        $ph = "%%A_TAG_$i%%";
        $placeholders[$ph] = $a_tag;
        $html = str_replace($a_tag, $ph, $html);
    }

    // Split HTML into <p> blocks
    $paragraphs = preg_split('/(<\/p>)/i', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
    $combined = [];
    for ($i = 0; $i < count($paragraphs); $i += 2) {
        $combined[] = ($paragraphs[$i] ?? '') . ($paragraphs[$i + 1] ?? '');
    }

    $sections = array_chunk($combined, ceil(count($combined) / 4));
    $linked = 0;

    foreach ($keywords as $keyword) {
        if ($linked >= 4) break;

        $query = new WP_Query([
            's' => $keyword,
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'post_type' => ['post', 'page'],
            'orderby' => 'relevance',
        ]);

        if ($query->have_posts()) {
            $post = $query->posts[0];
            $url = get_permalink($post);
            $pattern = '/\b(' . preg_quote($keyword, '/') . ')\b/i';
            $replacement = '<a href="' . esc_url($url) . '" rel="internal" target="_blank">$1</a>';

            // Try placing it in a different quarter of the content each time
            for ($section_index = $linked; $section_index < count($sections); $section_index++) {
                for ($i = 0; $i < count($sections[$section_index]); $i++) {
                    $new_para = preg_replace($pattern, $replacement, $sections[$section_index][$i], 1);
                    if ($new_para !== $sections[$section_index][$i]) {
                        $sections[$section_index][$i] = $new_para;
                        $linked++;
                        break 2;
                    }
                }
            }
        }

        wp_reset_postdata();
    }

    // Reassemble content
    $final_html = '';
    foreach ($sections as $group) {
        foreach ($group as $block) {
            $final_html .= $block;
        }
    }

    // Restore saved <a> tags
    foreach ($placeholders as $ph => $tag) {
        $final_html = str_replace($ph, $tag, $final_html);
    }

    return $final_html;
}

function publion_extract_noun_keywords($text, $api_key, $model = '') {
    $prompt = "Extraheer 10 van de belangrijkste zelfstandige naamwoorden of zelfstandige naamwoordgroepen uit de volgende blogpostcontent. Geef ze terug als een platte JSON-array met strings. Gebruik geen werkwoorden of bijvoeglijke naamwoorden.

$text";

    $response = publion_openai_post('https://api.openai.com/v1/chat/completions', [
        'headers' => [
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
        ],
        'body' => wp_json_encode( publion_build_openai_chat_body(
            $model ?: publion_get_openai_model(),
            array(
                array( 'role' => 'system', 'content' => 'Je bent een assistent die nuttige keywords extraheert.' ),
                array( 'role' => 'user', 'content' => $prompt ),
            ),
            200,
            0.3
        ) ),
        'timeout' => 60
    ], 'keywords');

    $body = json_decode(wp_remote_retrieve_body($response), true);
	// Get raw response content
	$content = trim($body['choices'][0]['message']['content'] ?? '');

	// Manually strip ```json or ``` from start and end
	if (str_starts_with($content, '```json')) {
	    $content = substr($content, 7);
	} elseif (str_starts_with($content, '```')) {
	    $content = substr($content, 3);
	}

	$content = rtrim($content, " \n\r\t`");

	// Optional quote cleanup
	$content = str_replace(['“','”',"'"], '"', $content);
	$content = preg_replace('/,\s*]/', ']', $content);

	// Decode
	$keywords = json_decode($content, true);

    return is_array($keywords) ? $keywords : [];
}

function publion_validate_links_in_html( $html, $reference_urls = array() ) {
    if (empty($html)) return $html;

    // Match all <a href="...">...</a> links
    preg_match_all('/<a\b[^>]*href=["\'](.*?)["\'][^>]*>(.*?)<\/a>/is', $html, $matches, PREG_SET_ORDER);

    foreach ($matches as $match) {
        $url = $match[1];
        $anchor_text = $match[2];

        // Skip invalid or non-http(s) links
        if (!preg_match('/^https?:\/\//i', $url)) continue;

        // An editor-approved URL is intentionally retained even when its host
        // blocks automated probes. Many reputable services reject HEAD calls.
        if ( publion_is_configured_external_reference_url( $url, $reference_urls ) ) {
            continue;
        }

        $response = wp_remote_head( $url, array( 'timeout' => 5, 'redirection' => 3 ) );
        $code = wp_remote_retrieve_response_code($response);

        // A number of reliable sites return 403/405 for HEAD while serving a
        // normal page. Use a tiny ranged GET as a safe fallback before
        // deciding that a generated source is broken.
        if ( is_wp_error( $response ) || ! $code || $code >= 400 ) {
            $response = wp_remote_get(
                $url,
                array(
                    'timeout'             => 7,
                    'redirection'         => 3,
                    'limit_response_size' => 1024,
                    'headers'             => array( 'Range' => 'bytes=0-1023' ),
                )
            );
            $code = wp_remote_retrieve_response_code( $response );
        }

        // If broken, remove the full anchor tag and keep only the anchor text
        if (!$code || $code >= 400) {
            $html = str_replace($match[0], $anchor_text, $html);
        }
    }

    return $html;
}

function publion_clean_html_output($html) {
    // Step 1: Remove everything before <article>
    $html = preg_replace('/.*?<article>/is', '', $html);

    // Step 2: Remove </article> if it exists
    $html = str_replace('</article>', '', $html);
    $html = str_replace('<article>', '', $html);

    // Step 3: Trim after the LAST </section>
    $last_section_pos = strripos($html, '</section>');
    if ($last_section_pos !== false) {
        $html = substr($html, 0, $last_section_pos + 10); // 10 = length of </section>
    }

    // Step 4: Remove content BETWEEN adjacent </section><section> tags (usually noise)
    $html = preg_replace('/<\/section>\s*[^<]*?<section>/is', '</section><section>', $html);

    // Step 5: Strip all remaining <section> and </section> tags
    $html = str_replace(['<section>', '</section>'], '', $html);

    // Step 6: Remove triple backticks or similar junk
    $html = preg_replace('/[`]{3,}(html)?/i', '', $html);

    // Step 7: Remove all HTML entities like &lt;, &gt;, &nbsp;, etc.
    $html = preg_replace('/&[a-z0-9#]+;/i', '', $html);

    // Final trim
    return trim($html);
}

/**
 * Applies a final, conservative cleanup after generation. WordPress will still
 * sanitize on save, but balancing here keeps the editor and frontend markup
 * predictable before images and links are added.
 */
function publion_normalize_article_html( $html ) {
    $html = wp_kses_post( (string) $html );
    $html = force_balance_tags( $html );
    $html = preg_replace( '/<p>\s*(<(?:h[2-4]|ul|ol|table|figure)\b[^>]*>)/i', '$1', $html );
    $html = preg_replace( '/(<\/(?:h[2-4]|ul|ol|table|figure)>)\s*<\/p>/i', '$1', $html );
    $html = preg_replace( '/<p>\s*<\/p>/i', '', $html );

    return trim( $html );
}

/**
 * Shortens text on a word boundary, avoiding cut-off words in snippets and alt text.
 */
function publion_trim_text_at_word_boundary( $text, $max_length = 155 ) {
    $text       = preg_replace( '/\s+/', ' ', trim( wp_strip_all_tags( (string) $text ) ) );
    $max_length = max( 20, (int) $max_length );

    if ( mb_strlen( $text ) <= $max_length ) {
        return $text;
    }

    $trimmed = mb_substr( $text, 0, $max_length + 1 );
    $trimmed = preg_replace( '/\s+\S*$/u', '', $trimmed );
    return rtrim( $trimmed, " \t\n\r\0\x0B,;:-" );
}

/**
 * Produces a readable search snippet without truncating a word or sentence.
 */
function publion_build_meta_description( $html, $max_length = 155 ) {
    $text       = preg_replace( '/\s+/', ' ', trim( wp_strip_all_tags( (string) $html ) ) );
    $max_length = max( 120, min( 160, (int) $max_length ) );

    if ( mb_strlen( $text ) <= $max_length ) {
        return $text;
    }

    $sentences = preg_split( '/(?<=[.!?])\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
    $result    = '';
    foreach ( $sentences as $sentence ) {
        $candidate = trim( $result . ' ' . $sentence );
        if ( mb_strlen( $candidate ) > $max_length ) {
            break;
        }
        $result = $candidate;
        if ( mb_strlen( $result ) >= 110 ) {
            break;
        }
    }

    return mb_strlen( $result ) >= 90 ? $result : publion_trim_text_at_word_boundary( $text, $max_length );
}

function publion_upload_image($url, $context = '') {
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $tmp = download_url($url);

    // Create a slug-like filename from the context
    $slug = sanitize_title($context);
    if (empty($slug)) $slug = 'publion-image';

	$parsed_url = wp_parse_url($url);
	$ext = pathinfo($parsed_url['path'] ?? '', PATHINFO_EXTENSION);
    if (!$ext) $ext = 'jpg';
    $filename = $slug . '-' . wp_generate_password(6, false, false) . '.' . $ext;

    $file_array = [
        'name'     => $filename,
        'tmp_name' => $tmp
    ];

    // Upload
    $id = media_handle_sideload($file_array, 0);

    // Optionally update image title and alt text
    wp_update_post([
        'ID'         => $id,
        'post_title' => ucwords(str_replace('-', ' ', $slug)),
        'post_name'  => $slug,
    ]);

    update_post_meta($id, '_wp_attachment_image_alt', publion_build_descriptive_image_alt( $context ));

    return [
        'attachment_id' => $id,
        'url' => wp_get_attachment_url($id)
    ];
}

function publion_build_descriptive_image_alt( $context = '' ) {
    $context = html_entity_decode( wp_strip_all_tags( (string) $context ), ENT_QUOTES, 'UTF-8' );
    $context = preg_replace( '/\s+/', ' ', trim( $context ) );
    if ( '' === $context ) {
        return 'Illustratie bij het artikel';
    }
    $context = publion_trim_text_at_word_boundary( $context, 92 );
    return 'Illustratie bij: ' . $context;
}

function publion_ensure_preferred_domain_link( $html, $preferred_domain, $topic ) {
    $preferred_domain = trim( (string) $preferred_domain );
    if ( '' === $preferred_domain || empty( $html ) ) {
        return $html;
    }

    $host = publion_normalize_domain( $preferred_domain );
    if ( '' === $host ) {
        return $html;
    }

    if ( preg_match( '/https?:\\/\\/' . preg_quote( $host, '/' ) . '/i', $html ) ) {
        return $html;
    }

    $url = ( preg_match( '/^https?:\\/\\//i', $preferred_domain ) ) ? $preferred_domain : 'https://' . $preferred_domain;
    $anchor = esc_html( $topic ? $topic : $host );
    $link_html = '<a href="' . esc_url( $url ) . '" target="_blank" rel="dofollow noopener noreferrer">' . $anchor . '</a>';

    if ( preg_match( '/<p[^>]*>.*?<\\/p>/is', $html, $m ) ) {
        $new_p = preg_replace( '/<\\/p>$/', ' ' . $link_html . '</p>', $m[0] );
        return preg_replace( '/<p[^>]*>.*?<\\/p>/is', $new_p, $html, 1 );
    }

    return $html . '<p>' . $link_html . '</p>';
}

/**
 * Guarantees one safe external source when the editor has configured one.
 * The fallback never invents a source: it only uses an exact URL saved in the
 * settings screen. It is called after generated links have been checked.
 */
function publion_ensure_configured_external_reference( $html, $reference_urls, $topic ) {
    if ( empty( $html ) || empty( $reference_urls ) || ! is_array( $reference_urls ) ) {
        return $html;
    }

    if ( preg_match_all( '/<a\b[^>]*href=["\'](https?:\/\/[^"\']+)["\'][^>]*>/i', $html, $links ) ) {
        foreach ( $links[1] as $link ) {
            if ( publion_is_configured_external_reference_url( $link, $reference_urls ) ) {
                return $html;
            }
        }
    }

    $index = abs( (int) crc32( sanitize_title( (string) $topic ) ) ) % count( $reference_urls );
    $url   = $reference_urls[ $index ];
    $host  = (string) wp_parse_url( $url, PHP_URL_HOST );
    $label = sprintf(
        /* translators: %s: source website hostname. */
        __( 'Meer achtergrondinformatie van %s', 'publion' ),
        $host
    );
    $link_html = '<p class="publion-external-source"><strong>' . esc_html__( 'Bron en verdieping:', 'publion' ) . '</strong> <a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $label ) . '</a></p>';

    return $html . $link_html;
}

function publion_get_allowed_openai_image_models() {
    $models = array(
        'gpt-image-2.5-sunburst' => 'GPT Image 2.5 Sunburst',
        'gpt-image-2.5-flare'    => 'GPT Image 2.5 Flare',
        'gpt-image-2'   => 'GPT Image 2 — aanbevolen',
        'gpt-image-1.5' => 'GPT Image 1.5 — vorige generatie',
        'gpt-image-1'   => 'GPT Image 1 — eerdere generatie',
    );

    return apply_filters( 'publion/openai_image_models', $models );
}

function publion_get_openai_image_model() {
    $default  = 'gpt-image-2';
    $selected = publion_normalize_openai_model_id( get_option( 'publion_openai_image_model', $default ) );

    return apply_filters( 'publion/openai_image_model', $selected ? $selected : $default );
}

/**
 * GPT Image 2 accepts arbitrary divisible-by-16 sizes, so use a true 16:9
 * asset when it is selected. Earlier GPT Image models retain their documented
 * standard landscape size and are cropped by the presentation layer if needed.
 */
function publion_get_image_size_for_layout( $layout ) {
    if ( 'square' === $layout ) {
        return '1024x1024';
    }

    return 0 === strpos( publion_get_openai_image_model(), 'gpt-image-2' ) ? '1536x864' : '1536x1024';
}

function publion_build_image_prompt( $topic, $category_name = '' ) {
    $topic = trim( (string) $topic );
    $category_name = trim( (string) $category_name );

    if ( $category_name !== '' ) {
        return 'Maak een realistische, hoogwaardige foto-achtige afbeelding voor een blogpost over "' . $topic . '" in de categorie "' . $category_name . '". Contextueel en relevant, zonder tekst, watermerk of logo.';
    }

    return 'Maak een realistische, hoogwaardige foto-achtige afbeelding voor een blogpost over "' . $topic . '". Contextueel en relevant, zonder tekst, watermerk of logo.';
}

function publion_generate_contextual_image_prompts( $html, $topic, $category_name = '' ) {
    $blocks = [];
    preg_match_all( '/<h[2-4][^>]*>.*?<\\/h[2-4]>|<p[^>]*>.*?<\\/p>/is', $html, $matches, PREG_OFFSET_CAPTURE );
    $all_offsets = $matches[0] ?? [];

    $length = strlen( $html );
    $desired_positions = [
        floor( $length * 0.165 ),
        floor( $length * 0.33 ),
        floor( $length * 0.495 ),
        floor( $length * 0.66 ),
        floor( $length * 0.825 ),
    ];

    foreach ( $desired_positions as $target ) {
        $closest = null;
        $min_diff = PHP_INT_MAX;
        $text = '';
        foreach ( $all_offsets as $offset ) {
            $diff = abs( $offset[1] - $target );
            if ( $diff < $min_diff ) {
                $min_diff = $diff;
                $closest = $offset[1];
                $text = wp_strip_all_tags( $offset[0] );
            }
        }
        $text = trim( preg_replace( '/\s+/', ' ', $text ) );
        if ( $text !== '' ) {
            $blocks[] = $text;
        }
    }

    $topic = trim( (string) $topic );
    $category_name = trim( (string) $category_name );

    $items = [];
    foreach ( $blocks as $i => $block_text ) {
        $layout = ( 0 === $i % 2 ) ? 'landscape' : 'square';
        $size   = publion_get_image_size_for_layout( $layout );
        $context = mb_substr( $block_text, 0, 180 );
        $prompt = 'Maak een realistische, hoogwaardige foto-achtige afbeelding die past bij dit tekstfragment: "' . $context . '". ';
        $prompt .= 'Onderwerp: "' . $topic . '". ';
        if ( $category_name !== '' ) {
            $prompt .= 'Categorie: "' . $category_name . '". ';
        }
        $prompt .= 'Contextueel en relevant, geen tekst, watermerk of logo. Maak de compositie duidelijk anders dan andere afbeeldingen in dit artikel. ';
        $prompt .= ( 'landscape' === $layout )
            ? 'Gebruik een brede horizontale compositie met ruimte aan de zijkanten; het beeld wordt in een 16:9 artikelvlak getoond.'
            : 'Gebruik een sterke vierkante compositie met het hoofdonderwerp centraal; het beeld wordt in een 1:1 artikelvlak getoond.';
        $items[] = [
            'prompt'  => $prompt,
            'context' => $context,
            'layout'  => $layout,
            'size'    => $size,
        ];
    }

    // Featured image prompt (6e)
    $featured = publion_build_image_prompt( $topic, $category_name ) . ' Maak de compositie duidelijk anders dan de andere afbeeldingen. Gebruik een brede horizontale compositie die geschikt is als uitgelichte afbeelding.';
    $items[] = [
        'prompt'  => $featured,
        'context' => $topic,
        'layout'  => 'landscape',
        'size'    => publion_get_image_size_for_layout( 'landscape' ),
    ];

    return array_slice( $items, 0, 6 );
}

function publion_is_external_url( $url ) {
    $host = wp_parse_url( home_url(), PHP_URL_HOST );
    $link_host = wp_parse_url( $url, PHP_URL_HOST );
    return ! empty( $link_host ) && ! empty( $host ) && strcasecmp( $host, $link_host ) !== 0;
}

function publion_enhance_external_links( $html ) {
    if ( empty( $html ) ) {
        return $html;
    }

    return preg_replace_callback(
        '/<a\\s+[^>]*href=[\"\\\']([^\"\\\']+)[\"\\\'][^>]*>/i',
        function ( $matches ) {
            $tag = $matches[0];
            $url = $matches[1];

            if ( ! preg_match( '/^https?:\\/\\//i', $url ) ) {
                return $tag;
            }
            if ( ! publion_is_external_url( $url ) ) {
                return $tag;
            }

            if ( stripos( $tag, 'target=' ) === false ) {
                $tag = rtrim( $tag, '>' ) . ' target="_blank">';
            }

            if ( preg_match( '/\\srel=[\"\\\']([^\"\\\']*)[\"\\\']/i', $tag, $rel_match ) ) {
                $rels = preg_split( '/\\s+/', $rel_match[1] );
                $rels = array_filter( array_map( 'strtolower', $rels ) );
                foreach ( [ 'noopener', 'noreferrer' ] as $rel ) {
                    if ( ! in_array( $rel, $rels, true ) ) {
                        $rels[] = $rel;
                    }
                }
                $new_rel = implode( ' ', array_unique( $rels ) );
                $tag = preg_replace( '/\\srel=[\"\\\'][^\"\\\']*[\"\\\']/i', ' rel="' . esc_attr( $new_rel ) . '"', $tag );
            } else {
                $tag = rtrim( $tag, '>' ) . ' rel="noopener noreferrer">';
            }

            return $tag;
        },
        $html
    );
}

/** Extract stable, support-safe fields from an Image API error response. */
function publion_get_image_generation_error_data( $response ) {
    if ( is_wp_error( $response ) ) {
        return array();
    }

    $body    = json_decode( wp_remote_retrieve_body( $response ), true );
    $error   = is_array( $body ) && isset( $body['error'] ) && is_array( $body['error'] ) ? $body['error'] : array();
    $details = isset( $error['moderation_details'] ) && is_array( $error['moderation_details'] ) ? $error['moderation_details'] : array();
    $request_id = wp_remote_retrieve_header( $response, 'x-request-id' );
    if ( ! $request_id && ! empty( $body['request_id'] ) ) {
        $request_id = $body['request_id'];
    }

    return array(
        'code'       => sanitize_key( $error['code'] ?? '' ),
        'type'       => sanitize_key( $error['type'] ?? '' ),
        'request_id' => sanitize_text_field( (string) $request_id ),
        'stage'      => sanitize_key( $details['moderation_stage'] ?? 'unknown' ),
        'categories' => array_values( array_filter( array_map( 'sanitize_key', (array) ( $details['categories'] ?? array() ) ) ) ),
    );
}

function publion_is_image_moderation_blocked( $response ) {
    $error = publion_get_image_generation_error_data( $response );
    return ( $error['code'] ?? '' ) === 'moderation_blocked';
}

/**
 * Creates a genuinely different, neutral editorial brief after a moderation
 * block. It removes high-risk incident terms instead of retrying the same
 * request, while preserving only a broad practical subject.
 */
function publion_build_neutral_image_retry_prompt( $prompt ) {
    $context = html_entity_decode( wp_strip_all_tags( (string) $prompt ), ENT_QUOTES, 'UTF-8' );
    $context = preg_replace( '/\b(?:geweld|gewelddadig|wapen|wapens|bedreig\w*|inbraak\w*|inbreker\w*|aanval\w*|slachtoffer\w*|verwond\w*|bloed\w*|crime|weapon|violent|violence|threat\w*|injur\w*|blood\w*)\b/iu', 'praktische situatie', $context );
    $context = preg_replace( '/\s+/', ' ', trim( $context ) );
    $context = publion_trim_text_at_word_boundary( $context, 140 );

    return 'Maak een neutrale, niet-grafische redactionele foto-illustratie voor een praktisch blogartikel. Toon een rustige woon- of onderhoudssituatie zonder personen, wapens, verwondingen, dreiging, geweld, misdaad, tekst, logo\'s of merken. Houd de compositie algemeen en informatief. Brede onderwerpcontext: ' . $context;
}

function publion_store_image_generation_error( $response, $image_model, $neutral_retry_attempted = false ) {
    $error_data = publion_get_image_generation_error_data( $response );
    if ( ( $error_data['code'] ?? '' ) === 'moderation_blocked' ) {
        $message = $neutral_retry_attempted
            ? __( 'OpenAI kon deze afbeelding na een veilige, neutrale herformulering niet genereren. Publion gebruikt een placeholder; vervang die afbeelding vóór publicatie door een neutrale, relevante afbeelding.', 'publion' )
            : __( 'OpenAI kon deze afbeelding niet genereren vanwege veiligheidsregels. Publion gebruikt een placeholder; vervang die afbeelding vóór publicatie door een neutrale, relevante afbeelding.', 'publion' );
    } else {
        $message = publion_get_openai_request_error( $response, $image_model );
    }

    update_option( 'publion_last_image_error', $message );
    update_option( 'publion_last_image_error_details', wp_json_encode( $error_data ) );
    error_log( '[Publion][IMAGE] code=' . ( $error_data['code'] ?? 'unknown' ) . ' request_id=' . ( $error_data['request_id'] ?? 'unavailable' ) );
}

function publion_generate_image_base64s( $prompt, $api_key, $count = 1, $size = '1024x1024' ) {
    $prompt = trim( (string) $prompt );
    $api_key = trim( (string) $api_key );
    $count = max( 1, (int) $count );
    $allowed_sizes = array( '1024x1024', '1536x1024', '1024x1536' );
    if ( 0 === strpos( publion_get_openai_image_model(), 'gpt-image-2' ) ) {
        $allowed_sizes[] = '1536x864';
    }
    $size = in_array( $size, $allowed_sizes, true ) ? $size : '1024x1024';

    if ( '' === $prompt || '' === $api_key ) {
        return [];
    }

    $image_model = publion_get_openai_image_model();
    $request_image = static function ( $image_prompt ) use ( $api_key, $image_model, $count, $size ) {
        return publion_openai_post(
        'https://api.openai.com/v1/images/generations',
        [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ],
            'body'    => wp_json_encode(
                [
                    'model'         => $image_model,
                    'prompt'        => $image_prompt,
                    'n'             => $count,
                    'size'          => $size,
                    'quality'       => 'medium',
                    'output_format' => 'jpeg',
                ]
            ),
            'timeout' => 180,
        ],
        'image'
        );
    };

    $response                = $request_image( $prompt );
    $neutral_retry_attempted = false;
    if ( publion_is_image_moderation_blocked( $response ) ) {
        $neutral_retry_attempted = true;
        $response = $request_image( publion_build_neutral_image_retry_prompt( $prompt ) );
    }

    if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
        publion_store_image_generation_error( $response, $image_model, $neutral_retry_attempted );
        return [];
    }

    $code = wp_remote_retrieve_response_code( $response );
    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( empty( $body['data'] ) || ! is_array( $body['data'] ) ) {
        update_option( 'publion_last_image_error', 'Geen afbeeldingsdata ontvangen.' );
        return [];
    }

    $images = [];
    foreach ( $body['data'] as $item ) {
        $entry = [
            'b64_json' => $item['b64_json'] ?? '',
            'url'      => $item['url'] ?? '',
        ];
        if ( '' !== $entry['b64_json'] || '' !== $entry['url'] ) {
            $images[] = $entry;
        }
    }

    if ( empty( $images ) ) {
        update_option( 'publion_last_image_error', 'Lege afbeeldingsdata ontvangen.' );
        return [];
    }

    delete_option( 'publion_last_image_error' );
    delete_option( 'publion_last_image_error_details' );
    return $images;
}

function publion_upload_image_base64( $base64, $context = '', $format = 'jpeg' ) {
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $base64 = trim( (string) $base64 );
    if ( '' === $base64 ) {
        return false;
    }

    $binary = base64_decode( $base64 );
    if ( false === $binary ) {
        return false;
    }

    $tmp = wp_tempnam( 'publion-image' );
    if ( ! $tmp ) {
        return false;
    }

    file_put_contents( $tmp, $binary );

    $slug = sanitize_title( $context );
    if ( empty( $slug ) ) {
        $slug = 'publion-image';
    }

    $ext = 'jpg';
    if ( 'png' === $format ) {
        $ext = 'png';
    } elseif ( 'webp' === $format ) {
        $ext = 'webp';
    }

    $filename = $slug . '-' . wp_generate_password( 6, false, false ) . '.' . $ext;

    $file_array = [
        'name'     => $filename,
        'tmp_name' => $tmp,
    ];

    $id = media_handle_sideload( $file_array, 0 );
    if ( is_wp_error( $id ) ) {
        @unlink( $tmp );
        return false;
    }

    wp_update_post(
        [
            'ID'         => $id,
            'post_title' => ucwords( str_replace( '-', ' ', $slug ) ),
            'post_name'  => $slug,
        ]
    );

    update_post_meta( $id, '_wp_attachment_image_alt', publion_build_descriptive_image_alt( $context ) );

    return [
        'attachment_id' => $id,
        'url'           => wp_get_attachment_url( $id ),
    ];
}

function publion_generate_and_upload_images( $prompt, $count, $context, $api_key, $size = '1024x1024' ) {
    $images = publion_generate_image_base64s( $prompt, $api_key, $count, $size );
    if ( empty( $images ) ) {
        // Fallback: try single-image requests if bulk failed.
        $fallback = [];
        for ( $i = 0; $i < $count; $i++ ) {
            $single = publion_generate_image_base64s( $prompt, $api_key, 1, $size );
            if ( ! empty( $single ) ) {
                $fallback[] = $single[0];
            }
        }
        if ( empty( $fallback ) ) {
            return [ 'urls' => [], 'ids' => [] ];
        }
        $images = $fallback;
    }

    $uploaded_urls = [];
    $uploaded_ids  = [];

    foreach ( $images as $image ) {
        if ( ! empty( $image['b64_json'] ) ) {
            $upload = publion_upload_image_base64( $image['b64_json'], $context, 'jpeg' );
        } elseif ( ! empty( $image['url'] ) ) {
            $upload = publion_upload_image( $image['url'], $context );
        } else {
            $upload = false;
        }
        if ( is_array( $upload ) && ! empty( $upload['attachment_id'] ) && ! empty( $upload['url'] ) ) {
            $attachment_id = (int) $upload['attachment_id'];
            // Do not insert a media URL until WordPress identifies it as a
            // usable image attachment. This stays compatible with sites that
            // offload their media library to object storage.
            if ( ! wp_attachment_is_image( $attachment_id ) ) {
                continue;
            }
            $uploaded_ids[]  = $attachment_id;
            $uploaded_urls[] = esc_url_raw( $upload['url'] );
        }
    }

    return [
        'urls' => $uploaded_urls,
        'ids'  => $uploaded_ids,
    ];
}

function publion_process_and_upload_images($remote_image_urls) {
    $processed = [];

    foreach ($remote_image_urls as $url) {
        $upload = publion_upload_image($url);
        if ($upload && isset($upload['url'])) {
            $processed[] = $upload;
        }
    }

    return $processed;
}

function publion_insert_images_into_content($html, $image_urls, $layouts = array(), $focus_keyword = '') {
    if (!is_array($image_urls) || count($image_urls) < 5 || empty($html)) return $html;

    // Match to headings (h2–h4)
    preg_match_all('/<h[2-4][^>]*>.*?<\/h[2-4]>|<p[^>]*>.*?<\/p>/is', $html, $matches, PREG_OFFSET_CAPTURE);
    $all_offsets = $matches[0];

    $length = strlen($html);
    $desired_positions = [
        floor($length * 0.165),
        floor($length * 0.33),
        floor($length * 0.495),
        floor($length * 0.66),
        floor($length * 0.825)
    ];

    $inserts = [];
    foreach ($desired_positions as $i => $target) {
        $image_url = esc_url_raw( (string) ( $image_urls[ $i ] ?? '' ) );
        // A missing generation or the packaged fallback must not become a
        // broken image icon in the public article. It is better to omit that
        // slot and let the editor add a meaningful image later.
        if ( '' === $image_url || false !== strpos( $image_url, '/includes/images/image-placeholder.jpg' ) ) {
            continue;
        }
        $closest = null;
        $min_diff = PHP_INT_MAX;
        $alt_text = '';

        foreach ($all_offsets as $offset) {
            $diff = abs($offset[1] - $target);
            if ($diff < $min_diff) {
                $min_diff = $diff;
                $closest = $offset[1];
                // Keep the alt text concise, contextual and useful for screen readers.
                $alt_text = wp_strip_all_tags($offset[0]);
                $alt_text = preg_replace('/\s+/', ' ', trim($alt_text));
                $alt_text = implode(' ', array_slice(explode(' ', $alt_text), 0, 14));
            }
        }

        $layout = isset( $layouts[ $i ] ) && 'square' === $layouts[ $i ] ? 'square' : 'landscape';
        // Rank Math checks whether one relevant image describes the primary
        // subject. The first image is generated for the main article context.
        if ( 0 === $i && '' !== trim( (string) $focus_keyword ) && ! publion_article_has_focus_keyword( $alt_text, $focus_keyword ) ) {
            $alt_text = sanitize_text_field( $focus_keyword ) . ': ' . $alt_text;
        }
        $alt_text = publion_build_descriptive_image_alt( $alt_text );
        $inserts[] = array(
            'offset' => $closest ?? $target,
            'html'   => '<figure class="publion-article-media publion-article-media--' . $layout . '"><img class="publion-generated-image" src="' . esc_url( $image_url ) . '" alt="' . esc_attr($alt_text) . '" loading="lazy" decoding="async" /></figure>',
        );
    }

    // Sort descending so offsets don’t shift
    usort(
        $inserts,
        static function ( $a, $b ) {
            return $b['offset'] <=> $a['offset'];
        }
    );
    foreach ($inserts as $insert) {
        $html = substr_replace($html, $insert['html'], $insert['offset'], 0);
    }

    return $html;
}

function publion_get_pixabay_images($topic, $count) {
    $api_key = '43505663-0cdcc08fe88f23c843f4a27c3';
    $endpoint = 'https://pixabay.com/api/';

    // First attempt: same topic, random page
    $params = [
        'key'         => $api_key,
        'q'           => urlencode($topic),
        'image_type'  => 'all',
        'orientation' => 'horizontal',
        'safesearch'  => 'true',
        'per_page'    => 200,
        'page'        => wp_rand(1, 3),
        'order'       => 'latest'
    ];

    $url = $endpoint . '?' . http_build_query($params);
    $response = wp_remote_get($url);

    if (is_wp_error($response)) return [];

    $body = json_decode(wp_remote_retrieve_body($response), true);

    // If not enough images, try again using same topic but fixed to page 1
    if (empty($body['hits']) || count($body['hits']) < $count) {
	    $params = [
	        'key'         => $api_key,
	        'q'           => urlencode($topic),
	        'image_type'  => 'all',
	        'orientation' => 'horizontal',
	        'safesearch'  => 'true',
	        'per_page'    => 200,
	        'page'        => 1,
	        'order'       => 'popular'
	    ];
        $url = $endpoint . '?' . http_build_query($params);
        $response = wp_remote_get($url);
        $body = json_decode(wp_remote_retrieve_body($response), true);
    }

    if (empty($body['hits'])) return [];

    shuffle($body['hits']);
    $selected = array_slice($body['hits'], 0, $count);

    return array_column($selected, 'largeImageURL');
}

function publion_extract_keywords($topic, $max_words = 3) {
    // Lowercase and remove punctuation
    $clean = strtolower(preg_replace('/[^\w\s]/', '', $topic));

    // Stopwords to skip
    $stopwords = ['the', 'of', 'in', 'and', 'on', 'to', 'for', 'with', 'a', 'an', 'is', 'are', 'as', 'by', 'at', 'from'];

    // Explode into words and remove stopwords
    $words = array_filter(explode(' ', $clean), function($word) use ($stopwords) {
        return !in_array($word, $stopwords) && strlen($word) > 2;
    });

    // Limit to $max_words
    $keywords = array_slice($words, 0, $max_words);

    return implode(' ', $keywords);
}

