jQuery(document).ready(function ($) {
	const translations = (window.Publion && Publion.i18n) || {};
	function t(key, fallback) {
		return Object.prototype.hasOwnProperty.call(translations, key) ? translations[key] : fallback;
	}
	function format(message) {
		const values = Array.prototype.slice.call(arguments, 1);
		let index = 0;
		return String(message).replace(/%[ds]/g, function (token) {
			return index < values.length ? values[index++] : token;
		});
	}

	// Restore active tab from localStorage or from URL param
	const urlParams = new URLSearchParams(window.location.search);
	const urlTab = urlParams.get('publion_active_tab');

	const savedTab = localStorage.getItem('publion_active_tab') || urlTab;

	if (savedTab) {
	    $('.nav-tab').removeClass('nav-tab-active');
	    $(`.nav-tab[data-tab="${savedTab}"]`).addClass('nav-tab-active');

	    $('.publion-tab-content').hide();
	    $(`#${savedTab}`).show();

	    localStorage.removeItem('publion_active_tab');
	}

	function errorDetails(response, fallback) {
		const data = response && response.data;
		const details = (data && typeof data === 'object' && !Array.isArray(data)) ? data : {};
		const rawResponse = response && typeof response.responseText === 'string' ? response.responseText.trim() : '';
		const sessionExpired = rawResponse === '-1' || (response && (response.status === 401 || response.status === 403));
		return {
			code: details.code || (sessionExpired ? 'session_expired' : 'operation_failed'),
			title: details.title || (sessionExpired ? t('session_expired_title', 'Je WordPress-sessie is verlopen.') : t('action_required', 'Actie nodig')),
			message: details.message || (sessionExpired ? t('session_expired_message', 'De actie is niet uitgevoerd omdat de beveiligingssessie niet meer geldig is.') : (typeof data === 'string' ? data : fallback)),
			nextStep: details.next_step || (sessionExpired ? t('session_expired_next_step', 'Ververs de pagina, meld je zo nodig opnieuw aan en probeer daarna opnieuw.') : t('generic_next_step', 'Controleer de getoonde informatie en probeer daarna opnieuw.')),
			actionLabel: details.action_label || (sessionExpired ? t('refresh_queue', 'Ververs wachtrij') : ''),
			actionTab: details.action_tab || (sessionExpired ? 'publion-queue' : ''),
			reference: details.reference || '',
			invalidItems: Array.isArray(details.invalid_items) ? details.invalid_items : [],
			retryable: details.retryable !== false
		};
	}

	function appendErrorDetails($target, details, compact) {
		if (!$target || !$target.length) return;
		const $panel = $('<div>', { class: 'publion-operation-error', role: 'alert' });
		$panel.append($('<button>', {
			type: 'button',
			class: 'publion-dismiss-notice',
			'aria-label': t('dismiss_message', 'Melding sluiten'),
			title: t('dismiss_message', 'Melding sluiten'),
			text: '\u00d7'
		}));
		$panel.append($('<strong>', { text: details.title }));
		$panel.append($('<p>', { text: details.message }));
		if (!compact && details.nextStep) {
			$panel.append($('<p>', { class: 'publion-operation-error-next', text: details.nextStep }));
		}
		if (details.invalidItems && details.invalidItems.length) {
			const $list = $('<ul>', { class: 'publion-operation-error-list' });
			details.invalidItems.forEach(function (item) { $list.append($('<li>', { text: item })); });
			$panel.append($list);
		}
		if (details.reference) {
			$panel.append($('<small>', { text: t('reference', 'Referentie') + ': ' + details.reference }));
		}
		if (details.actionLabel && details.actionTab) {
			$panel.append($('<button>', {
				type: 'button',
				class: 'button button-secondary publion-error-action',
				text: details.actionLabel,
				'data-publion-error-tab': details.actionTab
			}));
		}
		$target.empty().append($panel);
	}

	function showNotice(type, message, details) {
		const $notice = $('#publion-global-notice');
		if (!$notice.length) return;
		$notice.removeClass('is-success is-warning is-error').addClass('is-' + type).empty();
		$notice.append($('<button>', {
			type: 'button',
			class: 'publion-dismiss-notice',
			'aria-label': t('dismiss_message', 'Melding sluiten'),
			title: t('dismiss_message', 'Melding sluiten'),
			text: '\u00d7'
		}));
		$notice.append($('<strong>', { text: type === 'error' ? t('action_required', 'Actie nodig') : type === 'warning' ? t('attention', 'Let op') : t('success', 'Gelukt') }));
		$notice.append($('<span>', { text: message }));
		if (details && details.actionLabel && details.actionTab) {
			$notice.append($('<button>', { type: 'button', class: 'button button-secondary publion-error-action', text: details.actionLabel, 'data-publion-error-tab': details.actionTab }));
		}
		if (details && details.reference) {
			$notice.append($('<small>', { text: t('reference', 'Referentie') + ': ' + details.reference }));
		}
		$notice.stop(true, true).slideDown(150);
		if (type === 'success') setTimeout(function () { $notice.fadeOut(250); }, 4500);
	}

	$(document).on('click', '.publion-dismiss-notice', function () {
		const $notice = $(this).closest('.publion-global-notice, .publion-operation-error');
		if ($notice.hasClass('publion-global-notice')) {
			$notice.stop(true, true).fadeOut(180, function () { $(this).empty(); });
		} else {
			$notice.stop(true, true).fadeOut(180, function () { $(this).remove(); });
		}
	});

	function responseMessage(response, fallback) {
		return errorDetails(response, fallback).message;
	}

	function showActionableError(response, fallback, $target) {
		const details = errorDetails(response, fallback);
		showNotice('error', details.title + ': ' + details.message + (details.nextStep ? ' ' + details.nextStep : ''), details);
		appendErrorDetails($target, details, false);
		return details;
	}

	function openPublionTab(target) {
		if (!target || !$('#' + target).length) return;
		if (target === 'publion-queue') {
			localStorage.setItem('publion_active_tab', target);
			location.reload();
			return;
		}
		localStorage.setItem('publion_active_tab', target);
		$('.nav-tab').removeClass('nav-tab-active');
		$('.nav-tab[data-tab="' + target + '"]').addClass('nav-tab-active');
		$('.publion-tab-content').hide();
		$('#' + target).fadeIn(150);
	}

	let qualityModalTrigger = null;
	function closeQualityModal() {
		const $modal = $('#publion-quality-modal');
		if (!$modal.length || $modal.prop('hidden')) return;
		$modal.prop('hidden', true);
		$('body').removeClass('publion-modal-open');
		if (qualityModalTrigger) qualityModalTrigger.focus();
	}

	function openQualityModal(trigger) {
		const $modal = $('#publion-quality-modal');
		if (!$modal.length) return;
		qualityModalTrigger = trigger || document.activeElement;
		$modal.prop('hidden', false);
		$('body').addClass('publion-modal-open');
		$modal.find('.publion-modal-dialog').trigger('focus');
	}
	
    // Toggle OpenAI Instructions accordion
    $('.publion-openai-instructions-header').on('click', function () {
        $(this).next('.publion-openai-instructions-body').slideToggle(200);
        $(this).find('.publion-accordion-arrow').toggleClass('rotated');
    });

	// Tab switch logic (with refresh for Post Creation Queue tab)
	$('.nav-tab').on('click', function (e) {
	    e.preventDefault();
	    openPublionTab($(this).data('tab'));
	});

	$(document).on('click', '[data-publion-tab]', function () {
		openPublionTab($(this).data('publion-tab'));
	});

	$(document).on('click', '[data-publion-error-tab]', function () {
		openPublionTab($(this).data('publion-error-tab'));
	});

	$('#publion-open-quality-modal').on('click', function () {
		openQualityModal(this);
	});

	$(document).on('click', '[data-publion-modal-close]', closeQualityModal);
	$(document).on('click', '#publion-quality-modal [data-publion-tab]', closeQualityModal);
	$(document).on('keydown', function (event) {
		const $modal = $('#publion-quality-modal');
		if (!$modal.length || $modal.prop('hidden')) return;
		if (event.key === 'Escape') {
			event.preventDefault();
			closeQualityModal();
			return;
		}
		if (event.key !== 'Tab') return;
		const $focusable = $modal.find('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])').filter(':visible');
		if (!$focusable.length) return;
		const first = $focusable.first()[0];
		const last = $focusable.last()[0];
		if (event.shiftKey && document.activeElement === first) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && document.activeElement === last) {
			event.preventDefault();
			first.focus();
		}
	});

    // Accordion toggles for Post Creation
    $(document).on('click', '.publion-accordion-header', function () {
        const $header = $(this);
        const $body = $header.next('.publion-accordion-body');
        $body.slideToggle(200);
        $header.find('.publion-accordion-arrow').toggleClass('rotated');
    });

	// Refresh Suggestions button
	function isSafeSuggestion(suggestion) {
		if (!suggestion || typeof suggestion !== 'object' || typeof suggestion.title !== 'string') return false;
		const title = suggestion.title.trim();
		const focus = typeof suggestion.focus_keyword === 'string' ? suggestion.focus_keyword.trim() : '';
		const allowedIntents = ['informatief', 'commercieel', 'transactioneel', 'navigerend'];
		if (title.length < 16 || title.length > 140 || focus.length < 2 || /[\[\]{}\r\n]/.test(title + focus)) return false;
		if (/(?:^|\s|["'])\b(?:title|focus_keyword|search_intent|angle|faq_questions)\b\s*:/i.test(title + ' ' + focus)) return false;
		if (!allowedIntents.includes(suggestion.search_intent)) return false;
		if (typeof suggestion.angle !== 'string' || suggestion.angle.trim().length < 20) return false;
		return Array.isArray(suggestion.faq_questions) && suggestion.faq_questions.filter(function (question) {
			return typeof question === 'string' && question.trim().length >= 12;
		}).length >= 3;
	}

	function renderSuggestions(suggestions) {
		const $list = $('#publion-suggestions').empty();
		const validSuggestions = Array.isArray(suggestions) ? suggestions.filter(function (suggestion) {
			return isSafeSuggestion(suggestion);
		}) : [];
		if (!validSuggestions.length) {
			$list.append($('<li>', {
				class: 'publion-suggestion publion-suggestion-empty',
			text: t('no_valid_suggestions', 'Geen volledig gevalideerde onderwerpvoorstellen ontvangen. Er is niets opgeslagen. Vernieuw de voorstellen; blijft dit gebeuren, kies een ondersteund model of controleer de Publion-prompt.')
			}));
			return;
		}
		validSuggestions.forEach(function (suggestion) {
			const title = suggestion.title.trim();
			const brief = {
				focus_keyword: suggestion.focus_keyword || title,
				search_intent: suggestion.search_intent || 'informatief',
				angle: suggestion.angle || '',
				faq_questions: Array.isArray(suggestion.faq_questions) ? suggestion.faq_questions : []
			};
			const $li = $('<li>', { class: 'publion-suggestion' }).data('topic', title).data('seo-brief', brief);
			const $button = $('<button>', { type: 'button', class: 'button button-primary add-topic', text: t('add', 'Toevoegen') });
			const $content = $('<div>', { class: 'publion-suggestion-content' });
			$content.append($('<strong>', { text: title }));
			const $meta = $('<div>', { class: 'publion-seo-meta' });
			$meta.append($('<span>', { class: 'publion-seo-tag', text: t('focus', 'Focus') + ': ' + brief.focus_keyword }));
			$meta.append($('<span>', { class: 'publion-seo-tag', text: t('intent', 'Intentie') + ': ' + brief.search_intent }));
			if (brief.angle) $content.append($('<p>', { class: 'publion-suggestion-angle', text: brief.angle }));
			$content.append($meta);
			if (brief.faq_questions.length) {
				$content.append($('<p>', { class: 'publion-faq-preview', text: t('faq', 'FAQ') + ': ' + brief.faq_questions.join(' · ') }));
			}
			$li.append($button, $content);
			$list.append($li);
		});
	}

	function isSafeCategorySuggestion(suggestion) {
		if (!suggestion || typeof suggestion !== 'object') return false;
		const name = typeof suggestion.name === 'string' ? suggestion.name.trim() : '';
		const slug = typeof suggestion.slug === 'string' ? suggestion.slug.trim() : '';
		const level = suggestion.category_level;
		const parentName = typeof suggestion.parent_name === 'string' ? suggestion.parent_name.trim() : '';
		const focusKeyword = typeof suggestion.focus_keyword === 'string' ? suggestion.focus_keyword.trim() : '';
		const intent = suggestion.search_intent;
		const description = typeof suggestion.description === 'string' ? suggestion.description.trim() : '';
		const seoTitle = typeof suggestion.seo_title === 'string' ? suggestion.seo_title.trim() : '';
		const metaDescription = typeof suggestion.meta_description === 'string' ? suggestion.meta_description.trim() : '';
		const geoSummary = typeof suggestion.geo_summary === 'string' ? suggestion.geo_summary.trim() : '';
		const rationale = typeof suggestion.rationale === 'string' ? suggestion.rationale.trim() : '';
		if (name.length < 3 || name.length > 70 || /[\[\]{}\r\n]/.test(name)) return false;
		if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) || slug.length > 80) return false;
		if (!['hoofd', 'subcategorie'].includes(level) || (level === 'hoofd' && parentName) || (level === 'subcategorie' && !parentName)) return false;
		if (focusKeyword.length < 2 || focusKeyword.length > 100) return false;
		if (!['informatief', 'commercieel', 'transactioneel'].includes(intent)) return false;
		if (description.length < 140 || description.length > 600 || seoTitle.length < 25 || seoTitle.length > 70 || metaDescription.length < 110 || metaDescription.length > 180 || geoSummary.length < 70 || geoSummary.length > 300 || rationale.length < 30) return false;
		const focus = focusKeyword.toLocaleLowerCase();
		if (!description.toLocaleLowerCase().includes(focus) || !seoTitle.toLocaleLowerCase().includes(focus) || !metaDescription.toLocaleLowerCase().includes(focus)) return false;
		return Array.isArray(suggestion.example_topics) && suggestion.example_topics.length === 3 && suggestion.example_topics.every(function (topic) {
			return typeof topic === 'string' && topic.trim().length >= 12 && topic.trim().length <= 140;
		});
	}

	function categoryNameKey(name) {
		return String(name || '').trim().toLocaleLowerCase();
	}

	function getKnownCategoryNames() {
		const names = {};
		$('#publion-category option[data-publion-category-name]').each(function () {
			const name = categoryNameKey($(this).attr('data-publion-category-name'));
			if (name) names[name] = true;
		});
		$('.publion-category-card[data-publion-term-id]').each(function () {
			const suggestion = $(this).data('category-suggestion') || {};
			const name = categoryNameKey(suggestion.name);
			if (name) names[name] = true;
		});
		return names;
	}

	function updateCategoryResultsStatus() {
		const $cards = $('.publion-category-card');
		const total = $cards.length;
		const created = $cards.filter('[data-publion-term-id]').length;
		$('#publion-category-results-status').text(total ? format(t('category_results_status', '%d van %d categorieën aangemaakt.'), created, total) : '');
		const $createAll = $('#publion-create-category-hierarchy');
		if ($createAll.hasClass('is-busy')) return;
		$createAll.prop('disabled', !total || created === total);
		if (created === total && total) $createAll.text(t('category_created_status', 'Aangemaakt'));
	}

	function refreshCategoryCardStates() {
		const knownNames = getKnownCategoryNames();
		$('.publion-category-card').each(function () {
			const $card = $(this);
			const suggestion = $card.data('category-suggestion') || {};
			const $button = $card.find('.publion-create-category');
			const $state = $card.find('.publion-category-card-state');
			if ($card.attr('data-publion-term-id')) {
				$card.removeClass('is-waiting is-ready').addClass('is-created');
				$state.text(t('category_created_status', 'Aangemaakt'));
				$button.prop('disabled', true).text(t('category_created', 'Categorie aangemaakt'));
				return;
			}

			const parentIsReady = suggestion.category_level !== 'subcategorie' || !!knownNames[categoryNameKey(suggestion.parent_name)];
			$card.toggleClass('is-waiting', !parentIsReady).toggleClass('is-ready', parentIsReady).removeClass('is-created');
			if (parentIsReady) {
				$button.prop('disabled', false).removeAttr('aria-disabled').text(t('create_category', 'Categorie aanmaken'));
				$state.text(t('category_ready', 'Klaar om aan te maken'));
			} else {
				$button.prop('disabled', true).attr('aria-disabled', 'true').text(t('create_category', 'Categorie aanmaken'));
				$state.text(format(t('category_waiting_for_parent', 'Wacht op hoofdcategorie: %s'), suggestion.parent_name));
			}
		});
		updateCategoryResultsStatus();
	}

	function addCreatedCategoryLinks($card, data) {
		const $links = $('<p>', { class: 'publion-category-card-links' });
		if (data.edit_url) {
			$links.append($('<a>', { class: 'button button-small', href: data.edit_url, text: t('edit_category', 'Bewerk in WordPress') }));
		}
		if (data.archive_url) {
			$links.append($('<a>', { class: 'button button-small', href: data.archive_url, target: '_blank', rel: 'noopener noreferrer', text: t('view_category', 'Bekijk categorie') }));
		}
		if ($links.children().length) $card.find('.publion-category-card-actions').prepend($links);
	}

	function renderCategorySuggestions(suggestions) {
		const $list = $('#publion-category-suggestions').empty();
		const validSuggestions = Array.isArray(suggestions) ? suggestions.filter(isSafeCategorySuggestion) : [];
		$('#publion-category-results-toolbar').prop('hidden', !validSuggestions.length);
		if (!validSuggestions.length) {
			$list.append($('<p>', { class: 'publion-suggestion-empty', text: t('no_valid_category_suggestions', 'Geen volledig gevalideerde categorievoorstellen ontvangen. Er is niets aangemaakt; probeer het opnieuw.') }));
			return;
		}
		validSuggestions.sort(function (a, b) { return (a.category_level === 'hoofd' ? 0 : 1) - (b.category_level === 'hoofd' ? 0 : 1); }).forEach(function (suggestion, index) {
			const $card = $('<article>', { class: 'publion-category-card' }).data('category-suggestion', suggestion);
			const cardId = 'publion-category-card-' + index;
			$card.attr('id', cardId);
			const $header = $('<div>', { class: 'publion-category-card-header' });
			$header.append($('<div>').append($('<h4>', { text: suggestion.name }), $('<span>', { class: 'publion-category-card-state', 'aria-live': 'polite' })));
			$header.append($('<span>', { class: 'publion-seo-tag', text: (suggestion.category_level === 'hoofd' ? t('main_category', 'Hoofdcategorie') : t('sub_category', 'Subcategorie')) + ' · ' + suggestion.search_intent }));
			$card.append($header);
			if (suggestion.parent_name) $card.append($('<p>', { class: 'publion-category-parent', text: t('parent_category', 'Hoofdcategorie') + ': ' + suggestion.parent_name }));
			$card.append($('<p>', { class: 'publion-category-slug', text: t('slug', 'Slug') + ': /' + suggestion.slug + '/' }));
			$card.append($('<p>', { class: 'publion-category-purpose', text: suggestion.description }));
			$card.append($('<p>', { class: 'publion-category-rationale' }).append($('<strong>', { text: t('strategy_reason', 'Waarom deze categorie') + ': ' }), document.createTextNode(suggestion.rationale)));
			const $seo = $('<dl>', { class: 'publion-category-seo-fields' });
			$seo.append($('<dt>', { text: t('focus', 'Focus') }), $('<dd>', { text: suggestion.focus_keyword }));
			$seo.append($('<dt>', { text: t('seo_title', 'SEO-titel') }), $('<dd>', { text: suggestion.seo_title }));
			$seo.append($('<dt>', { text: t('meta_description', 'Meta description') }), $('<dd>', { text: suggestion.meta_description }));
			$seo.append($('<dt>', { text: t('geo_summary', 'GEO-samenvatting') }), $('<dd>', { text: suggestion.geo_summary }));
			$card.append($seo);
			const $topics = $('<ul>', { class: 'publion-category-example-topics' });
			suggestion.example_topics.forEach(function (topic) { $topics.append($('<li>', { text: topic })); });
			$card.append($('<strong>', { text: t('example_articles', 'Mogelijke artikelen') }), $topics);
			const $actions = $('<div>', { class: 'publion-category-card-actions' });
			$actions.append($('<button>', { type: 'button', class: 'button button-primary publion-create-category', text: t('create_category', 'Categorie aanmaken') }));
			$card.append($actions);
			$list.append($card);
		});
		refreshCategoryCardStates();
		$list.trigger('focus');
	}

	function categoryRequestData(suggestion) {
		return {
			action: 'publion_create_category',
			nonce: Publion.nonce,
			name: suggestion.name,
			slug: suggestion.slug,
			category_level: suggestion.category_level,
			parent_name: suggestion.parent_name,
			focus_keyword: suggestion.focus_keyword,
			search_intent: suggestion.search_intent,
			description: suggestion.description,
			seo_title: suggestion.seo_title,
			meta_description: suggestion.meta_description,
			geo_summary: suggestion.geo_summary,
			rationale: suggestion.rationale,
			example_topics: suggestion.example_topics
		};
	}

	function createCategoryFromCard($card, options) {
		const $button = $card.find('.publion-create-category');
		const suggestion = $card.data('category-suggestion');
		const settings = options || {};
		if (!isSafeCategorySuggestion(suggestion) || $button.prop('disabled') || $card.attr('data-publion-term-id')) return $.Deferred().resolve(false).promise();
		$button.prop('disabled', true).text(t('creating_category', 'Categorie wordt aangemaakt…'));
		return $.post(Publion.ajax_url, categoryRequestData(suggestion)).then(function (response) {
			if (!response || !response.success || !response.data) {
				if (!settings.silent) showActionableError(response, t('create_category_failed', 'De categorie kon niet worden aangemaakt. Vernieuw de pagina en probeer opnieuw.'), $card.find('.publion-category-card-actions'));
				$button.prop('disabled', false).text(t('create_category', 'Categorie aanmaken'));
				return false;
			}
			const termId = parseInt(response.data.term_id, 10);
			const name = String(response.data.name || suggestion.name).trim();
			const parentName = String(response.data.parent_name || '').trim();
			const optionLabel = parentName ? parentName + ' → ' + name : name;
			if (termId && name) {
				const $categorySelect = $('#publion-category');
				if (!$categorySelect.find('option[value="' + termId + '"]').length) {
					$categorySelect.append($('<option>', { value: termId, text: optionLabel, 'data-publion-category-name': name }));
				}
				$categorySelect.val(String(termId)).trigger('change');
			}
			$card.attr('data-publion-term-id', String(termId || 'created'));
			addCreatedCategoryLinks($card, response.data);
			refreshCategoryCardStates();
			if (!settings.silent) showNotice('success', response.data.message || t('category_created_message', 'Categorie aangemaakt. Je kunt er nu onderwerpen voor plannen.'));
			return true;
		}, function (response) {
			if (!settings.silent) showActionableError(response, t('create_category_failed', 'De categorie kon niet worden aangemaakt. Vernieuw de pagina en probeer opnieuw.'), $card.find('.publion-category-card-actions'));
			$button.prop('disabled', false).text(t('create_category', 'Categorie aanmaken'));
			return false;
		});
	}

	$('#publion-suggest-categories').on('click', function () {
		const $button = $(this);
		$button.prop('disabled', true);
		$('#publion-category-strategy').attr('aria-busy', 'true');
		$('#publion-category-strategy-loading').css('display', 'flex');
		$('#publion-category-suggestions').attr('aria-busy', 'true').empty();
		$.post(Publion.ajax_url, {
			action: 'publion_get_category_suggestions',
			nonce: Publion.nonce,
			strategy_intent: $('#publion-category-intent').val(),
			additional_context: $('#publion-category-context').val()
		}, function (response) {
			if (response && response.success) {
				renderCategorySuggestions(response.data || []);
			} else {
				showActionableError(response, t('category_suggestions_failed', 'Categorievoorstellen konden niet worden gemaakt. Controleer je API-sleutel en probeer opnieuw.'));
			}
		}).fail(function () {
			showActionableError(null, t('connection_interrupted', 'De verbinding met WordPress of OpenAI is onderbroken. Controleer je internetverbinding en probeer opnieuw.'));
		}).always(function () {
			$('#publion-category-strategy-loading').hide();
			$('#publion-category-strategy').attr('aria-busy', 'false');
			$('#publion-category-suggestions').attr('aria-busy', 'false');
			$button.prop('disabled', false);
		});
	});

	$(document).on('click', '.publion-create-category', function () {
		if ($('#publion-create-category-hierarchy').hasClass('is-busy')) return;
		createCategoryFromCard($(this).closest('.publion-category-card'));
	});

	$('#publion-create-category-hierarchy').on('click', function () {
		const $button = $(this);
		if ($button.prop('disabled') || !window.confirm(t('create_hierarchy_confirm', 'Wil je alle getoonde categorieën aanmaken? Publion maakt eerst hoofdcategorieën en daarna subcategorieën. Bestaande categorieën worden niet gewijzigd.'))) return;
		const cards = $('#publion-category-suggestions .publion-category-card').toArray();
		let index = 0;
		let failed = false;
		$button.addClass('is-busy').prop('disabled', true).text(t('creating_hierarchy', 'Hiërarchie wordt aangemaakt…'));
		function next() {
			if (index >= cards.length) {
				refreshCategoryCardStates();
				if (failed) {
					showNotice('warning', t('hierarchy_stopped', 'De hiërarchie is gestopt bij een categorie die aandacht nodig heeft. Eerder aangemaakte categorieën blijven bestaan.'));
					$button.removeClass('is-busy').text(t('create_hierarchy', 'Volledige hiërarchie aanmaken')).prop('disabled', false);
				} else {
					showNotice('success', t('hierarchy_created', 'Categoriehiërarchie aangemaakt. Controleer daarna de categoriepagina’s en voeg interne links toe.'));
					$button.removeClass('is-busy');
					updateCategoryResultsStatus();
				}
				return;
			}
			const $card = $(cards[index++]);
			if ($card.attr('data-publion-term-id')) return next();
			refreshCategoryCardStates();
			createCategoryFromCard($card, { silent: true }).then(function (success) {
				if (!success) {
					failed = true;
					return next();
				}
				next();
			});
		}
		next();
	});

	$('#publion-clear-category-suggestions').on('click', function () {
		$('#publion-category-suggestions').empty();
		$('#publion-category-results-toolbar').prop('hidden', true);
	});

	$('#publion-refresh').on('click', function () {
	    const category = $('#publion-category').val();
	    if (!category) {
			showNotice('warning', t('select_category_first', 'Selecteer eerst een categorie om relevante onderwerpvoorstellen te maken.'));
	        return;
	    }

	    $('#publion-loading').css('display', 'flex');
	    $('#publion-suggestions').empty();

	    $.post(Publion.ajax_url, {
	        action: 'publion_get_topics',
	        nonce: Publion.nonce,
	        category: category
	    }, function (response) {
	        $('#publion-loading').hide();

	        if (response.success) {
	            $('#publion-suggestions-heading').show();
	            renderSuggestions(response.data || []);
	        } else {
				showActionableError(response, t('refresh_failed', 'Vernieuwen van voorstellen mislukt. Controleer je API-sleutel en probeer opnieuw.'));
	        }
	    }).fail(function () {
	        $('#publion-loading').hide();
		showActionableError(null, t('connection_interrupted', 'De verbinding met WordPress of OpenAI is onderbroken. Controleer je internetverbinding en probeer opnieuw.'));
	    });
	});

	// Suggest Topics button
	$('#publion-suggest').on('click', function () {
	    const category = $('#publion-category').val();
	    if (!category) {
	        showNotice('warning', t('select_category_first', 'Selecteer eerst een categorie om relevante onderwerpvoorstellen te maken.'));
	        return;
	    }

	    $('#publion-loading').css('display', 'flex');
	    $('#publion-suggestions').empty();

	    // Show heading and refresh button
	    $('#publion-suggestions-heading').show();
	    $('#publion-refresh').show();

	    // Disable the suggest button until new category selected
	    $(this).prop('disabled', true);

	    $.post(Publion.ajax_url, {
	        action: 'publion_get_topics',
	        nonce: Publion.nonce,
	        category: category
	    }, function (response) {
	        $('#publion-loading').hide();

	        if (response.success) {
	            renderSuggestions(response.data || []);
	        } else {
	            $('#publion-suggest').prop('disabled', false);
				showActionableError(response, t('suggestions_failed', 'Kon geen onderwerpvoorstellen ophalen. Controleer je API-sleutel en model in AI-instellingen.'));
	        }
	    }).fail(function () {
	        $('#publion-loading').hide();
	        $('#publion-suggest').prop('disabled', false);
		showActionableError(null, t('request_failed', 'De aanvraag kon niet worden verstuurd. Controleer de verbinding en probeer opnieuw.'));
	    });
	});

	// When category is changed, reset suggest button and hide suggestions
	$('#publion-category').on('change', function () {
	    $('#publion-suggest').prop('disabled', false);
	    $('#publion-refresh').hide();
	    $('#publion-suggestions-heading').hide();
	    $('#publion-suggestions').empty();
	});

	// Save queue for post creation
	$('#publion-save-queue').on('click', function () {
	    const postQueue = [];
	    const invalidRows = [];

	    $('#publion-ai-queue tbody tr').each(function () {
	        const $row = $(this);
	        // Values are stored with jQuery .data() on the row. Querying a
	        // [data-*] attribute loses them because .data() does not write it.
	        const category = $row.data('category');
	        const categoryLabel = $row.data('category-label') || $row.children('td').eq(1).text();
	        const topic = typeof $row.data('topic') === 'string' ? $row.data('topic').trim() : '';
	        const seoBrief = $row.data('seo-brief') || {};

	        if (!topic || !category) {
			invalidRows.push(topic || t('unknown_topic', 'Een geselecteerd onderwerp'));
			return;
	        }

	        postQueue.push({
	            category,
	            categoryLabel,
	            topic,
	            focusKeyword: seoBrief.focus_keyword || topic,
	            seoBrief: seoBrief
	        });
	    });

	    if (invalidRows.length) {
	        showNotice('warning', t('queue_item_incomplete', 'Een geselecteerd onderwerp mist verplichte gegevens. Verwijder het onderwerp en voeg de voorstelkaart opnieuw toe.'));
	        return;
	    }

	    if (postQueue.length === 0) {
	        showNotice('warning', t('select_topic_first', 'Kies eerst minstens één onderwerp voordat je de wachtrij opslaat.'));
	        return;
	    }

	    const $saveButton = $(this);
	    const $existingStatus = $('.publion-spinner-status');

	    if ($existingStatus.length) {
	        $existingStatus.remove();
	    }

	    const $status = $('<span class="publion-spinner-status" style="margin-left:10px;"></span>');
	    $saveButton.after($status);

	    $status.html('<span class="spinner is-active" style="float:none;display:inline-block;"></span>');

	    $.post(Publion.ajax_url, {
	        action: 'publion_save_queue',
	        nonce: Publion.nonce,
	        queue_json: JSON.stringify(postQueue)
	    }, function (response) {
	        if (response.success) {
	            $status.html('<span style="color:green;">✅ Toegevoegd aan de wachtrij voor postcreatie!</span>');
	            showNotice('success', t('selected_added_to_queue', 'De geselecteerde onderwerpen staan nu in de wachtrij.'));
	            $('#publion-ai-queue tbody').empty();

	            // Pause to show success message, then hide the section
	            setTimeout(function () {
	                const $wrapper = $('#publion-selected-topics');
	                if ($wrapper.is(':visible')) {
	                    $wrapper.stop(true, true).slideUp(200);
	                }
	            }, 1500);

            } else {
				showActionableError(response, t('save_failed', 'Opslaan mislukt.'), $status);
            }
        }).fail(function () {
			showActionableError(null, t('network_save_failed', 'Opslaan mislukt door een netwerkfout.'), $status);
	    });
	});

    // Default to Settings tab if API key is missing
    if (!Publion.has_api_key) {
        $('.nav-tab').removeClass('nav-tab-active');
        $('.publion-tab-content').hide();

        $('[data-tab="publion-settings"]').addClass('nav-tab-active');
        $('#publion-settings').show();
        showNotice('warning', t('api_key_needed', 'Voeg een OpenAI API-sleutel toe om met onderwerpen, artikelen en afbeeldingen te werken.'));
    }

    // Toggle CTA fields on dropdown change
    $('#publion_cta_enabled').on('change', function () {
        if ($(this).val() === 'yes') {
            $('#publion_cta_fields, .publion_cta_link_row').show();
        } else {
            $('#publion_cta_fields, .publion_cta_link_row').hide();
        }
    });

	function toggleRefinedStyleControls() {
		$('.publion-refined-style-control').toggle($('#publion_article_style_mode').val() === 'refined');
	}

	function toggleWebResearchControls() {
		$('.publion-web-research-options').toggle($('#publion_web_research_enabled').is(':checked'));
	}

	function updatePostScheduleControls() {
		const mode = $('#publion_post_schedule_mode').val();
		const isDaily = mode === 'daily';
		const postsPerDay = Math.max(1, parseInt($('#publion_posts_per_day').val(), 10) || 1);
		const windowHours = Math.max(1, parseInt($('#publion_post_creation_window_hours').val(), 10) || 1);
		const intervalDays = Math.max(1, parseInt($('#publion_time_frame_days').val(), 10) || 1);
		const firstTime = $('#publion_post_creation_time').val() || '00:00';

		$('.publion-post-schedule-daily').toggle(isDaily);
		$('.publion-post-schedule-every-days').toggle(!isDaily);

		const summary = isDaily
			? `Publion plant ${postsPerDay} ${postsPerDay === 1 ? 'post' : 'posts'} per dag vanaf ${firstTime}, gespreid over ${windowHours} ${windowHours === 1 ? 'uur' : 'uur'}.`
			: `Publion plant één post elke ${intervalDays} ${intervalDays === 1 ? 'dag' : 'dagen'} om ${firstTime}.`;
		$('#publion-post-schedule-summary').text(summary);

		const autoTopics = $('#publion_auto_daily_topic').is(':checked');
		const topicCount = isDaily ? postsPerDay : 1;
		const topicCadence = isDaily
			? `vóór elke dagelijkse postronde ${topicCount} ${topicCount === 1 ? 'nieuw onderwerp' : 'nieuwe onderwerpen'}`
			: `vóór elke postronde één nieuw onderwerp`;
		$('#publion-topic-schedule-summary').text(autoTopics
			? `Publion genereert ${topicCadence}, zodat de wachtrij automatisch gevuld blijft.`
			: 'Schakel dit in om de wachtrij automatisch met nieuwe, unieke onderwerpen aan te vullen.');
		$('.publion-next-topic-run').toggle(autoTopics);
	}

	$('#publion_article_style_mode').on('change', toggleRefinedStyleControls);
	$('#publion_web_research_enabled').on('change', toggleWebResearchControls);
	$('#publion_post_schedule_mode, #publion_posts_per_day, #publion_post_creation_window_hours, #publion_time_frame_days, #publion_post_creation_time, #publion_auto_daily_topic').on('change input', updatePostScheduleControls);
	toggleRefinedStyleControls();
	toggleWebResearchControls();
	updatePostScheduleControls();

    // Auto-save Rank Math toggle to prevent accidental loss on refresh.
    $('#publion_rank_math_integration').on('change', function () {
        $('#publion-post-settings-form').trigger('submit');
    });


    // AJAX save post settings
    $('#publion-post-settings-form').on('submit', function (e) {
        e.preventDefault();

        const $btn = $('#publion-save-button');
        const $status = $('#publion-save-status');

        $status.html('<span class="spinner is-active" style="float:none;display:inline-block;"></span>');

		const data = {
		    action: 'publion_save_post_settings',
		    nonce: Publion.nonce,
		    post_schedule_mode: $('#publion_post_schedule_mode').val(),
		    posts_per_day: $('#publion_posts_per_day').val(),
		    post_creation_window_hours: $('#publion_post_creation_window_hours').val(),
		    time_frame_days: $('#publion_time_frame_days').val(),
		    post_creation_time: $('#publion_post_creation_time').val(),
		    post_status: $('#publion_post_status').val(),
		    default_post_author: $('#publion_default_post_author').val(),
		    cta_enabled: $('#publion_cta_enabled').val(),
		    cta_text: $('#publion_cta_text').val(),
		    cta_link: $('#publion_cta_link').val(),
		    notification_email: $('#publion_notification_email').val(),
		    hide_title: $('#publion_hide_title').is(':checked') ? 'yes' : 'no',
		    auto_daily_topic: $('#publion_auto_daily_topic').is(':checked') ? 'yes' : 'no',
		    preferred_external_domain: $('#publion_preferred_external_domain').val(),
		    preferred_external_urls: $('#publion_preferred_external_urls').val(),
		    web_research_enabled: $('#publion_web_research_enabled').is(':checked') ? 'yes' : 'no',
		    web_research_model: $('#publion_web_research_model').val(),
		    web_research_source_count: $('#publion_web_research_source_count').val(),
		    web_research_context_size: $('#publion_web_research_context_size').val(),
		    web_research_live_access: $('#publion_web_research_live_access').is(':checked') ? 'yes' : 'no',
		    web_research_allowed_domains: $('#publion_web_research_allowed_domains').val(),
		    web_research_blocked_domains: $('#publion_web_research_blocked_domains').val(),
		    web_research_display_sources: $('#publion_web_research_display_sources').is(':checked') ? 'yes' : 'no',
		    web_research_failure_mode: $('#publion_web_research_failure_mode').val(),
		    rank_math_integration: $('#publion_rank_math_integration').is(':checked') ? 'yes' : 'no',
		    rank_math_target_word_count: $('#publion_rank_math_target_word_count').val(),
		    rank_math_density_min: $('#publion_rank_math_density_min').val(),
		    rank_math_density_max: $('#publion_rank_math_density_max').val(),
		    rank_math_max_paragraph_words: $('#publion_rank_math_max_paragraph_words').val(),
		    rank_math_auto_repair: $('#publion_rank_math_auto_repair').is(':checked') ? 'yes' : 'no',
		    rank_math_publish_gate: $('#publion_rank_math_publish_gate').is(':checked') ? 'yes' : 'no',
		    rank_math_add_toc: $('#publion_rank_math_add_toc').is(':checked') ? 'yes' : 'no',
		    rank_math_check_image_alt: $('#publion_rank_math_check_image_alt').is(':checked') ? 'yes' : 'no',
		    rank_math_check_external_link: $('#publion_rank_math_check_external_link').is(':checked') ? 'yes' : 'no',
		    rank_math_check_internal_link: $('#publion_rank_math_check_internal_link').is(':checked') ? 'yes' : 'no',
		    structured_data: $('#publion_structured_data').is(':checked') ? 'yes' : 'no',
		    image_border_radius: $('#publion_image_border_radius').val(),
		    article_style_mode: $('#publion_article_style_mode').val(),
		    content_accent_color: $('#publion_content_accent_color').val(),
		    content_max_width: $('#publion_content_max_width').val(),
		    custom_article_css: $('#publion_custom_article_css').val(),
		    search_console_url: $('#publion_search_console_url').val(),
		    ga4_url: $('#publion_ga4_url').val()
		};

        $.post(Publion.ajax_url, data, function (response) {
            if (response.success) {
                $status.html('<span style="color:green;">✅ Opgeslagen!</span>');
                if (response.data && response.data.next_daily_topic !== undefined) {
                    const nextLabel = response.data.next_daily_topic || 'Niet gepland';
                    $('#publion-next-daily-topic').text(nextLabel);
                }
            } else {
				showActionableError(response, t('save_failed', 'Opslaan mislukt.'), $status);
            }
        }).fail(function () {
			showActionableError(null, t('network_save_failed', 'Opslaan mislukt door een netwerkfout.'), $status);
        });
    });

	// Restore active tab after reload
	(function () {
	    const params = new URLSearchParams(window.location.search);
	    let savedTab = localStorage.getItem('publion_active_tab') || params.get('publion_active_tab');

	    if (savedTab) {
	        $('.nav-tab').removeClass('nav-tab-active');
	        $(`[data-tab="${savedTab}"]`).addClass('nav-tab-active');

	        $('.publion-tab-content').hide();
	        $('#' + savedTab).show();

	        localStorage.removeItem('publion_active_tab');
	    }
	})();

	// Save API Key via AJAX
	$('#publion-save-api-key').on('click', function (e) {
	    e.preventDefault();

	    const $status = $('#publion-api-key-status');
	    const apiKey = $('#publion_api_key').val().trim();
	    if (!apiKey) {
	        $status.html('<span style="color:#475569; margin-left:5px;">Laat dit veld leeg om de huidige sleutel te behouden.</span>');
	        return;
	    }
	    $status.html('<span class="spinner is-active" style="float:none;display:inline-block;"></span>');

	    $.post(Publion.ajax_url, {
	        action: 'publion_save_api_key',
	        nonce: Publion.nonce,
	        api_key: apiKey
	    }, function (response) {
	        if (response.success) {
	            $status.html('<span style="color:green; margin-left:5px;">✅ Opgeslagen!</span>');
	        } else {
	            showActionableError(response, t('save_failed', 'Opslaan mislukt.'), $status);
	        }
	    }).fail(function () {
	        showActionableError(null, t('network_save_failed', 'Opslaan mislukt door een netwerkfout.'), $status);
	    });
	});

	// Test the saved key (or a key currently entered above) server-side. The key
	// is never sent directly from the browser to OpenAI.
	$('#publion-test-openai-connection').on('click', function (e) {
	    e.preventDefault();

	    const $button = $(this);
	    const $status = $('#publion-connection-status');
	    $button.prop('disabled', true);
	    $status.html('<span class="spinner is-active" style="float:none;display:inline-block;"></span>');

	    $.post(Publion.ajax_url, {
	        action: 'publion_test_openai_connection',
	        nonce: Publion.nonce,
	        api_key: $('#publion_api_key').val().trim(),
	        text_model: $('#publion_custom_openai_model').val(),
	        image_model: $('#publion_custom_openai_image_model').val()
	    }, function (response) {
	        if (response.success) {
	            const data = response.data || {};
	            const checks = [];
	            if (data.text_model) {
	                checks.push((data.text_model_available ? '✓ ' : '⚠ ') + 'Tekstmodel ' + data.text_model + (data.text_model_available ? ': beschikbaar' : ': niet beschikbaar'));
	            }
	            if (data.image_model) {
	                checks.push((data.image_model_available ? '✓ ' : '⚠ ') + 'Afbeeldingsmodel ' + data.image_model + (data.image_model_available ? ': beschikbaar' : ': niet beschikbaar'));
	            }
	            $status.text((data.message || 'Verbinding met OpenAI geslaagd.') + (checks.length ? ' ' + checks.join('. ') + '.' : '')).css('color', data.text_model_available && data.image_model_available ? 'green' : '#a16207');
	        } else {
	            showActionableError(response, t('network_save_failed', 'Verbinding testen mislukt.'), $status);
	        }
	    }).fail(function () {
	        showActionableError(null, t('network_save_failed', 'Verbinding testen mislukt door een netwerkfout.'), $status);
	    }).always(function () {
	        $button.prop('disabled', false);
	    });
	});

	function syncCustomModelInput() {
	    const $select = $('#publion_openai_model');
	    const isCustom = $select.val() === '__custom__';
	    const $wrap = $('#publion-custom-model-wrap');
	    const $input = $('#publion_custom_openai_model');

        // The initial server-rendered value already matches the saved model.
        // On a selection change, reflect a curated model ID in the read-only
        // field without ever overwriting a custom model ID.
	    $wrap.prop('hidden', false).attr('aria-hidden', 'false');
	    if (!isCustom) {
	        $input.val($select.val());
	    } else {
	        $input.trigger('focus');
	    }
	    $input.prop('disabled', !isCustom);
	}

	$('#publion_openai_model').on('change', syncCustomModelInput);

	function syncCustomImageModelInput() {
	    const $select = $('#publion_openai_image_model');
	    const isCustom = $select.val() === '__custom__';
	    const $wrap = $('#publion-custom-image-model-wrap');
	    const $input = $('#publion_custom_openai_image_model');

	    $wrap.prop('hidden', false).attr('aria-hidden', 'false');
	    if (!isCustom) {
	        $input.val($select.val());
	    } else {
	        $input.trigger('focus');
	    }
	    $input.prop('disabled', !isCustom);
	}

	$('#publion_openai_image_model').on('change', syncCustomImageModelInput);


	// Save Model via AJAX
	$('#publion-save-model').on('click', function (e) {
	    e.preventDefault();

	    const $status = $('#publion-model-status');
	    $status.html('<span class="spinner is-active" style="float:none;display:inline-block;"></span>');

	    $.post(Publion.ajax_url, {
	        action: 'publion_save_model',
	        nonce: Publion.nonce,
	        model: $('#publion_openai_model').val(),
	        custom_model: $('#publion_custom_openai_model').val()
	    }, function (response) {
	        if (response.success) {
	            $status.text(response.data.message || 'Model opgeslagen.');
	        } else {
	            showActionableError(response, t('save_failed', 'Opslaan mislukt.'), $status);
	        }
	    }).fail(function () {
	        showActionableError(null, t('network_save_failed', 'Opslaan mislukt door een netwerkfout.'), $status);
	    });
	});

	$('#publion-save-image-model').on('click', function (e) {
	    e.preventDefault();

	    const $status = $('#publion-image-model-status');
	    $status.html('<span class="spinner is-active" style="float:none;display:inline-block;"></span>');

	    $.post(Publion.ajax_url, {
	        action: 'publion_save_image_model',
	        nonce: Publion.nonce,
	        model: $('#publion_openai_image_model').val(),
	        custom_model: $('#publion_custom_openai_image_model').val()
	    }, function (response) {
	        if (response.success) {
	            $status.text(response.data.message || 'Afbeeldingsmodel opgeslagen.');
	        } else {
	            showActionableError(response, t('save_failed', 'Opslaan mislukt.'), $status);
	        }
	    }).fail(function () {
	        showActionableError(null, t('network_save_failed', 'Opslaan mislukt door een netwerkfout.'), $status);
	    });
	});

	// Save Prompt via AJAX
	$('#publion-save-prompt').on('click', function (e) {
	    e.preventDefault();

	    const $status = $('#publion-prompt-status');
	    $status.html('<span class="spinner is-active" style="float:none;display:inline-block;"></span>');

	    $.post(Publion.ajax_url, {
	        action: 'publion_save_prompt',
	        nonce: Publion.nonce,
	        prompt: $('#publion_prompt').val()
	    }, function (response) {
	        if (response.success) {
	            $status.html('<span style="color:green; margin-left:9px">✅ Opgeslagen!</span>');
	        } else {
	            showActionableError(response, t('save_failed', 'Opslaan mislukt.'), $status);
	        }
	    }).fail(function () {
	        showActionableError(null, t('network_save_failed', 'Opslaan mislukt door een netwerkfout.'), $status);
	    });
	});

	// Load Post Creation Queue and Created Posts separately
	let publionQueueOffset = 0;
	let publionCreatedOffset = 0;
	const publionQueueLimit = 10;

	function loadQueueOrCreated(type) {
	    const action = type === 'created' ? 'publion_load_created_posts' : 'publion_load_queue_entries';

	    $.post(Publion.ajax_url, {
	        action: action,
	        nonce: Publion.nonce,
	        offset: type === 'created' ? publionCreatedOffset : publionQueueOffset,
	        limit: publionQueueLimit
	    }, function (response) {
	        if (response.success) {
	            const html = response.data.rows || '';
	            const rowCount = (html.match(/<tr/g) || []).length;

	            if (type === 'created') {
	                $('#publion-created-table tbody').append(html);
	                publionCreatedOffset += publionQueueLimit;

	                if (!response.data.has_more || rowCount < publionQueueLimit) {
	                    $('#publion-load-more-created').hide();
	                }
	            } else {
                $('#publion-queue-table tbody').append(html);
	                publionQueueOffset += publionQueueLimit;

	                if (!response.data.has_more || rowCount < publionQueueLimit) {
	                    $('#publion-load-more').hide();
	                }
	            }
	        } else {
	            showActionableError(response, t('items_load_failed', 'Items laden mislukt.'));
	        }
	    }).fail(function () {
	        showActionableError(null, t('connection_interrupted', 'De verbinding met WordPress of OpenAI is onderbroken. Controleer je internetverbinding en probeer opnieuw.'));
	    });
	}

	$('#publion-load-more').on('click', function () {
	    loadQueueOrCreated('pending');
	});

	$('#publion-load-more-created').on('click', function () {
	    loadQueueOrCreated('created');
	});

	$('#publion-clear-created-history').on('click', function () {
		const $button = $(this);
		if (!confirm(t('clear_history_confirm', 'Wil je de volledige Publion-geschiedenis van aangemaakte posts wissen? De originele WordPress-posts blijven behouden.'))) return;

		$button.prop('disabled', true).text(t('clearing_history', 'Geschiedenis wissen…'));
		$.post(Publion.ajax_url, {
			action: 'publion_clear_created_history',
			nonce: Publion.nonce
		}, function (response) {
			if (response && response.success) {
				publionCreatedOffset = 0;
				$('#publion-created-table tbody').empty();
				$('#publion-load-more-created').hide();
				showNotice('success', (response.data && response.data.message) || t('clear_history_success', 'De Publion-geschiedenis is gewist. Je WordPress-posts zijn niet verwijderd.'));
				$button.prop('disabled', false).text(t('history_cleared', 'Geschiedenis gewist'));
			} else {
				$button.prop('disabled', false).text(t('clear_history', 'Geschiedenis wissen'));
				showActionableError(response, t('clear_history_failed', 'De Publion-geschiedenis kon niet worden gewist. Er is niets verwijderd.'));
			}
		}).fail(function () {
			$button.prop('disabled', false).text(t('clear_history', 'Geschiedenis wissen'));
			showActionableError(null, t('clear_history_failed', 'De Publion-geschiedenis kon niet worden gewist. Er is niets verwijderd.'));
		});
	});

	setTimeout(function () {
    const $queueTab = $('#publion-queue');
	    if ($queueTab.is(':visible') && publionQueueOffset === 0) {
	        loadQueueOrCreated('pending');
	    }
	}, 100);
	
	setTimeout(function () {
    const $queueTab = $('#publion-queue');
	    if ($queueTab.is(':visible') && publionCreatedOffset === 0) {
	        loadQueueOrCreated('created');
	    }
	}, 150);

	function formatEstimateDuration(seconds) {
		const minutes = Math.max(1, Math.round((parseInt(seconds, 10) || 0) / 60));
		return minutes + ' ' + t('minutes_short', 'min.');
	}

	function renderCreationProgress($cell, progress) {
		if (!$cell.length || !progress) return;
		let percent = Math.max(0, Math.min(100, parseInt(progress.percent, 10) || 0));
		const state = progress.state || 'running';
		const stage = progress.stage || t('working', 'Bezig');
		const detail = progress.detail || t('server_processing', 'De server verwerkt deze stap.');
		const updatedAt = parseInt(progress.updated_at, 10) || 0;
		const previous = $cell.data('publion-creation-progress') || {};
		if (previous.serverUpdatedAt && updatedAt && (updatedAt < previous.serverUpdatedAt || (previous.state !== 'running' && state === 'running' && updatedAt <= previous.serverUpdatedAt))) {
			progress.state = previous.state;
			progress.percent = previous.percent;
			progress.stage = previous.stage;
			progress.detail = previous.detail;
			return previous;
		}
		if (state === 'running' && previous.state === 'running') percent = Math.max(percent, parseInt(previous.percent, 10) || 0);
		progress.percent = percent;
		const displayed = { state: state, percent: percent, stage: stage, detail: detail, serverUpdatedAt: updatedAt || previous.serverUpdatedAt || 0 };
		$cell.data('publion-creation-progress', displayed);
		const $button = $cell.find('.publion-create-now');
		const $cancel = $cell.find('.publion-cancel-creation');
		const $estimate = $cell.find('.publion-create-estimate');
		const buttonText = state === 'running' ? stage + ' - ' + percent + '%' : stage;
		$button.removeClass('publion-create-is-running publion-create-is-completed publion-create-is-failed publion-create-is-cancelled')
			.addClass('publion-create-is-' + state)
			.attr('title', detail)
			.attr('aria-label', stage + ': ' + percent + '% — ' + detail)
			.find('.button-text').text(buttonText);
		$cancel.prop('hidden', state !== 'running');
		const estimate = progress.estimate;
		if (state === 'running' && estimate && estimate.lower_seconds && estimate.upper_seconds) {
			let estimateText = t('estimated_generation_time', 'Verwachte generatietijd') + ': ' + formatEstimateDuration(estimate.lower_seconds) + '–' + formatEstimateDuration(estimate.upper_seconds);
			if (estimate.source === 'baseline') estimateText += ' · ' + t('estimate_learning', 'wordt nauwkeuriger na voltooide generaties');
			else if (estimate.sample_count) estimateText += ' · ' + t('estimate_based_on', 'op basis van eerdere generaties');
			$estimate.text(estimateText).prop('hidden', false);
		} else {
			$estimate.empty().prop('hidden', true);
		}
		return displayed;
	}

	function pollCreationProgress(id, $cell, $button) {
		const poll = function () {
			$.post(Publion.ajax_url, {
				action: 'publion_get_creation_progress',
				nonce: Publion.nonce,
				id: id
			}, function (response) {
				if (!response || !response.success || !response.data) return;
				renderCreationProgress($cell, response.data);
				if (response.data.state === 'running') {
					$button.find('.button-text').text((response.data.stage || t('working', 'Bezig')) + ' · ' + (response.data.percent || 0) + '%');
				}
			});
		};
		poll();
		return window.setInterval(poll, 1100);
	}

	$(document).on('click', '.publion-create-now', function () {
	    const $button = $(this);
	    const id = $button.data('id');
	    const $cell = $button.closest('.publion-queue-actions');
	    $cell.removeData('publion-creation-progress');

	    if (!confirm(t('create_now_confirm', 'Wil je nu een blogpost maken voor dit onderwerp? De status hieronder volgt de echte stappen op de server.'))) return;

	    $button.prop('disabled', true).find('.button-text').text(t('request_sent', 'Aanvraag verstuurd'));
	    renderCreationProgress($cell, {
			state: 'running',
			percent: 1,
			stage: t('request_started', 'Aanvraag gestart'),
			detail: t('waiting_server', 'Publion wacht op de eerste serverbevestiging.')
		});
	    $button.siblings('.publion-create-spinner').addClass('is-active').show();
	    $('.publion-delete[data-id="' + id + '"]').hide();
	    const progressTimer = pollCreationProgress(id, $cell, $button);

	    $.post(Publion.ajax_url, {
	        action: 'publion_create_post_now',
	        nonce: Publion.nonce,
	        id: id
	    }, function (res) {
	        window.clearInterval(progressTimer);
	        if (res && res.success) {
				renderCreationProgress($cell, {
					state: 'completed',
					percent: 100,
					stage: t('complete', 'Klaar'),
					detail: t('draft_ready', 'Het artikelconcept is aangemaakt en staat klaar voor controle.')
				});
				$button.find('.button-text').text(t('complete', 'Klaar') + ' · 100%');
				$button.siblings('.publion-create-spinner').removeClass('is-active').hide();
				showNotice('success', t('post_created', 'Post succesvol aangemaakt. De wachtrij wordt bijgewerkt.'));
				localStorage.setItem('publion_active_tab', 'publion-queue');
				window.setTimeout(function () { location.reload(); }, 1100);
			} else {
				const error = showActionableError(res, t('create_failed', 'Post aanmaken mislukt. Controleer de getoonde voortgang en probeer opnieuw.'));
				renderCreationProgress($cell, { state: 'failed', percent: 0, stage: error.title, detail: error.message, error: error });
	            $button.prop('disabled', false).find('.button-text').text(t('create_now', 'Nu maken'));
	            $button.siblings('.publion-create-spinner').removeClass('is-active').hide();
	            $('.publion-delete[data-id="' + id + '"]').show();
	        }
	    }).fail(function (jqXHR, textStatus, errorThrown) {
			window.clearInterval(progressTimer);
			try { console.error('Nu maken AJAX mislukt:', textStatus, errorThrown, jqXHR && jqXHR.responseText); } catch (e) {}
			const error = errorDetails(null, t('connection_lost', 'De verbinding met WordPress viel weg. Controleer de actuele status na het verversen voordat je opnieuw start.'));
			error.title = t('connection_lost_stage', 'Verbinding onderbroken');
			error.nextStep = t('connection_lost_next_step', 'Ververs eerst de wachtrij. Start alleen opnieuw als er nog geen concept is aangemaakt.');
			error.actionLabel = t('open_queue', 'Open wachtrij');
			error.actionTab = 'publion-queue';
			renderCreationProgress($cell, { state: 'failed', percent: 0, stage: error.title, detail: error.message, error: error });
			showNotice('error', error.title + ': ' + error.message + ' ' + error.nextStep, error);
			$button.prop('disabled', false).find('.button-text').text(t('create_now', 'Nu maken'));
			$button.siblings('.publion-create-spinner').removeClass('is-active').hide();
			$('.publion-delete[data-id="' + id + '"]').show();
	    });
	});

	$(document).on('click', '.publion-cancel-creation', function () {
		const $cancel = $(this);
		const id = $cancel.data('id');
		const $cell = $cancel.closest('.publion-queue-actions');
		if (!confirm(t('cancel_creation_confirm', 'Wil je de artikelgeneratie annuleren? Publion stopt bij het eerstvolgende veilige servermoment.'))) return;

		$cancel.prop('disabled', true);
		$cell.data('publion-cancelled', true);
		$.post(Publion.ajax_url, {
			action: 'publion_cancel_post_creation',
			nonce: Publion.nonce,
			id: id
		}, function (res) {
			if (res && res.success) {
				renderCreationProgress($cell, { state: 'cancelled', percent: 0, stage: t('cancel_requested', 'Annulering aangevraagd'), detail: res.data.message || t('cancel_pending', 'De server stopt bij het eerstvolgende veilige moment.') });
				showNotice('success', res.data.message || t('cancel_pending', 'De server stopt bij het eerstvolgende veilige moment.'));
				window.setTimeout(function () { location.reload(); }, 1300);
			} else {
				$cell.data('publion-cancelled', false);
				$cancel.prop('disabled', false);
				showActionableError(res, t('cancel_failed', 'Annuleren is niet gelukt. De artikelgeneratie kan nog actief zijn.'));
			}
		}).fail(function () {
			$cell.data('publion-cancelled', false);
			$cancel.prop('disabled', false);
			showNotice('error', t('cancel_connection_lost', 'Annuleren kon niet worden bevestigd. Ververs de wachtrij om de actuele status te controleren.'));
		});
	});

	$(document).on('click', '.publion-accordion-heading', function () {
	    const $header = $(this);
	    const $arrow = $header.find('.publion-accordion-arrow');
	    $header.toggleClass('active');
	    $header.next('.publion-accordion-body').slideToggle(200);

	    // Toggle arrow direction
	    if ($header.hasClass('active')) {
	        $arrow.text('▲');
	    } else {
	        $arrow.text('▼');
	    }
	});
	
	$(document).on('click', '.publion-delete', function () {
	    const $button = $(this);
	    const id = $button.data('id');

	    if (!confirm(t('delete_topic_confirm', 'Weet je zeker dat je dit onderwerp uit de wachtrij wilt verwijderen?'))) return;

	    $button.prop('disabled', true).text(t('removing', 'Verwijderen…'));

	    $.post(Publion.ajax_url, {
	        action: 'publion_delete_topic',
	        nonce: Publion.nonce,
	        id: id
	    }, function (res) {
	        if (res.success) {
	            $button.closest('tr').fadeOut(300, function () {
	                $(this).remove();
	            });
	        } else {
	            showActionableError(res, t('remove_topic_failed', 'Onderwerp verwijderen mislukt.'));
	            $button.prop('disabled', false).text(t('remove', 'Verwijderen'));
	        }
	    }).fail(function () {
	        showActionableError(null, t('delete_ajax_error', 'AJAX-fout bij verwijderen van onderwerp.'));
	        $button.prop('disabled', false).text(t('remove', 'Verwijderen'));
	    });
	});

    function getSelectedQueueIds() {
        const ids = [];
        $('#publion-queue-table tbody .publion-row-select:checked').each(function () {
            const id = parseInt($(this).data('id'), 10);
            if (id) ids.push(id);
        });
        return ids;
    }

    function setBulkStatus(html) {
        $('#publion-bulk-status').html(html);
    }

    function processBulkGenerate(ids, index) {
        if (!ids.length) {
            setBulkStatus('<span style="color:red;">&#10060; ' + t('no_items_selected', 'Geen items geselecteerd.') + '</span>');
            return;
        }

        if (index >= ids.length) {
            setBulkStatus('<span style="color:green;">&#9989; ' + t('reloading', 'Klaar! Herladen…') + '</span>');
            localStorage.setItem('publion_active_tab', 'publion-queue');
            location.reload();
            return;
        }

        const id = ids[index];
        setBulkStatus('<span class="spinner is-active" style="float:none;display:inline-block;"></span> ' + (index + 1) + '/' + ids.length);

        $.post(Publion.ajax_url, {
            action: 'publion_create_post_now',
            nonce: Publion.nonce,
            id: id
        }, function (res) {
            if (res && res.success) {
                processBulkGenerate(ids, index + 1);
            } else {
                setBulkStatus('<span style="color:red;">&#10060; ' + format(t('failed_at_item', 'Mislukt bij item %d.'), index + 1) + '</span>');
            }
        }).fail(function () {
            setBulkStatus('<span style="color:red;">&#10060; ' + format(t('ajax_error_at_item', 'AJAX-fout bij item %d.'), index + 1) + '</span>');
        });
    }

    function processBulkDelete(ids) {
        if (!ids.length) {
            setBulkStatus('<span style="color:red;">&#10060; ' + t('no_items_selected', 'Geen items geselecteerd.') + '</span>');
            return;
        }

        setBulkStatus('<span class="spinner is-active" style="float:none;display:inline-block;"></span>');
        let completed = 0;
        let failed = 0;

        ids.forEach(function (id) {
            $.post(Publion.ajax_url, {
                action: 'publion_delete_topic',
                nonce: Publion.nonce,
                id: id
            }, function (res) {
                if (res && res.success) {
                    $('#publion-queue-table tbody .publion-row-select[data-id="' + id + '"]').closest('tr').fadeOut(200, function () {
                        $(this).remove();
                    });
                } else {
                    failed++;
                }
            }).fail(function () {
                failed++;
            }).always(function () {
                completed++;
                if (completed >= ids.length) {
                    if (failed) {
                        setBulkStatus('<span style="color:red;">&#10060; ' + format(t('failed_count', '%d mislukt.'), failed) + '</span>');
                    } else {
                        setBulkStatus('<span style="color:green;">&#9989; ' + t('deleted', 'Verwijderd.') + '</span>');
                    }
                }
            });
        });
    }

    function queueTopicLabel(id) {
        const $row = $('#publion-queue-table tbody .publion-row-select[data-id="' + id + '"]').closest('tr');
        return $row.find('td').eq(2).text().trim() || t('queue_item', 'Wachtrij-item') + ' #' + id;
    }

    function renderBulkSummary(total, succeeded, failures) {
        const $status = $('#publion-bulk-status').empty();
        const $summary = $('<div>', { class: 'publion-bulk-summary' + (failures.length ? ' is-error' : '') });
        const heading = failures.length
            ? format(t('bulk_completed_with_errors', 'Bulkactie afgerond: %d item(s) hebben aandacht nodig.'), failures.length)
            : t('bulk_completed', 'Bulkactie succesvol afgerond.');
        $summary.append($('<strong>', { text: heading }));
		$summary.append($('<span>', { text: format(t('bulk_progress_summary', '%d van %d verwerkt.'), succeeded + failures.length, total) + ' ' + format(t('bulk_success_summary', '%d geslaagd.'), succeeded) }));
        if (failures.length) {
            const $list = $('<ul>');
            failures.slice(0, 5).forEach(function (failure) {
                $list.append($('<li>', { text: failure.topic + ' — ' + failure.error.title + ': ' + failure.error.message + ' ' + failure.error.nextStep }));
            });
            $summary.append($list);
            const first = failures[0].error;
            if (first.actionLabel && first.actionTab) {
                $summary.append($('<button>', { type: 'button', class: 'button button-secondary publion-error-action', text: first.actionLabel, 'data-publion-error-tab': first.actionTab }));
            }
        }
        $summary.append($('<button>', { type: 'button', class: 'button publion-error-action', text: t('refresh_queue', 'Ververs wachtrij'), 'data-publion-error-tab': 'publion-queue' }));
        $status.append($summary);
    }

    function processBulkGenerateDetailed(ids, index, results) {
        results = results || { succeeded: 0, failures: [] };
        if (index >= ids.length) {
            renderBulkSummary(ids.length, results.succeeded, results.failures);
            if (results.failures.length) showActionableError({ data: results.failures[0].error }, t('bulk_failed', 'Een of meer items konden niet worden verwerkt.'));
            return;
        }
        const id = ids[index];
        setBulkStatus('<span class="spinner is-active" style="float:none;display:inline-block;"></span> ' + format(t('bulk_processing', 'Item %d van %d wordt verwerkt.'), index + 1, ids.length));
        $.post(Publion.ajax_url, { action: 'publion_create_post_now', nonce: Publion.nonce, id: id }, function (res) {
            if (res && res.success) {
                results.succeeded++;
                $('#publion-queue-table tbody .publion-row-select[data-id="' + id + '"]').closest('tr').fadeOut(180, function () { $(this).remove(); });
            } else {
                results.failures.push({ topic: queueTopicLabel(id), error: errorDetails(res, t('bulk_failed', 'Dit item kon niet worden verwerkt.')) });
            }
            processBulkGenerateDetailed(ids, index + 1, results);
        }).fail(function () {
            results.failures.push({ topic: queueTopicLabel(id), error: errorDetails(null, t('connection_lost', 'De verbinding met WordPress viel weg.')) });
            processBulkGenerateDetailed(ids, index + 1, results);
        });
    }

    function processBulkDeleteDetailed(ids) {
        const results = { succeeded: 0, failures: [] };
        let completed = 0;
        setBulkStatus('<span class="spinner is-active" style="float:none;display:inline-block;"></span> ' + t('bulk_delete_processing', 'Geselecteerde items worden verwijderd.'));
        ids.forEach(function (id) {
            const topic = queueTopicLabel(id);
            $.post(Publion.ajax_url, { action: 'publion_delete_topic', nonce: Publion.nonce, id: id }, function (res) {
                if (res && res.success) {
                    results.succeeded++;
                    $('#publion-queue-table tbody .publion-row-select[data-id="' + id + '"]').closest('tr').fadeOut(180, function () { $(this).remove(); });
                } else {
                    results.failures.push({ topic: topic, error: errorDetails(res, t('remove_topic_failed', 'Onderwerp verwijderen mislukt.')) });
                }
            }).fail(function () {
                results.failures.push({ topic: topic, error: errorDetails(null, t('delete_ajax_error', 'AJAX-fout bij verwijderen van onderwerp.')) });
            }).always(function () {
                completed++;
                if (completed === ids.length) {
                    renderBulkSummary(ids.length, results.succeeded, results.failures);
                    if (results.failures.length) showActionableError({ data: results.failures[0].error }, t('bulk_failed', 'Een of meer items konden niet worden verwijderd.'));
                }
            });
        });
    }

    $(document).on('change', '#publion-select-all', function () {
        const checked = $(this).is(':checked');
        $('#publion-queue-table tbody .publion-row-select').prop('checked', checked);
    });

    $(document).on('change', '#publion-queue-table tbody .publion-row-select', function () {
        const total = $('#publion-queue-table tbody .publion-row-select').length;
        const checked = $('#publion-queue-table tbody .publion-row-select:checked').length;
        $('#publion-select-all').prop('checked', total && total === checked);
    });

    $(document).on('click', '#publion-bulk-apply', function () {
        const action = $('#publion-bulk-action').val();
        const ids = getSelectedQueueIds();

        if (!action) {
            setBulkStatus('<span style="color:red;">&#10060; ' + t('choose_bulk_action', 'Kies een bulkactie.') + '</span>');
            return;
        }

        if (!ids.length) {
            setBulkStatus('<span style="color:red;">&#10060; ' + t('no_items_selected', 'Geen items geselecteerd.') + '</span>');
            return;
        }

        if (action === 'generate') {
	            if (!confirm(t('bulk_generate_confirm', 'Weet je zeker dat je alle geselecteerde posts wilt genereren?'))) return;
            processBulkGenerateDetailed(ids, 0);
        } else if (action === 'delete') {
	            if (!confirm(t('bulk_delete_confirm', 'Weet je zeker dat je alle geselecteerde items wilt verwijderen?'))) return;
            processBulkDeleteDetailed(ids);
        }
    });

    // Update schedule for a queued post
    $(document).on('click', '.publion-schedule-save', function () {
        const $button = $(this);
        const $cell = $button.closest('td');
        const $row = $button.closest('tr');
        const id = $button.data('id');
        const $input = $cell.find('.publion-schedule-input');
        const value = $input.val();
        const $status = $cell.find('.publion-schedule-status');

        if (!id || !value) {
            $status.html('<span style="color:red;">&#10060; ' + t('invalid_date_time', 'Ongeldige datum/tijd.') + '</span>');
            return;
        }

        $button.prop('disabled', true);
        $status.html('<span class="spinner is-active" style="float:none;display:inline-block;"></span>');

        $.post(Publion.ajax_url, {
            action: 'publion_update_schedule',
            nonce: Publion.nonce,
            id: id,
            scheduled_at: value
        }, function (response) {
            if (response.success) {
                $status.html('<span style="color:green;">&#9989; ' + t('saved_short', 'Opgeslagen') + '</span>');
                if (response.data && response.data.scheduled_input) {
                    $input.val(response.data.scheduled_input);
                }
                if (response.data && response.data.days_until !== undefined) {
                    $row.find('.publion-days-until').text(response.data.days_until);
                }
            } else {
                showActionableError(response, t('save_failed', 'Opslaan mislukt.'), $status);
            }
        }).fail(function () {
            showActionableError(null, t('network_save_failed', 'Opslaan mislukt door een netwerkfout.'), $status);
        }).always(function () {
            $button.prop('disabled', false);
        });
    });
	
	// Remove orphaned topic from "Created Posts" when post is not found, then reload into Post Creation tab
	$(document).on('click', '.publion-remove-notfound', function () {
	    const $btn = $(this);
	    const id = $btn.data('id');
	    if (!id) return;

	    if (!confirm(t('remove_from_publion_confirm', 'Onderwerp verwijderen uit Publion?'))) return;

	    $btn.prop('disabled', true).text(t('removing', 'Verwijderen…'));

	    $.post(Publion.ajax_url, {
	        action: 'publion_delete_topic',
	        nonce: Publion.nonce,
	        id: id
	    }, function (res) {
	        if (res.success) {
	            // Ensure we return to the Post Creation tab on reload
	            localStorage.setItem('publion_active_tab', 'publion-queue');
	            location.reload();
	        } else {
	            showActionableError(res, t('remove_topic_failed', 'Onderwerp verwijderen mislukt.'));
	            $btn.prop('disabled', false).text(t('remove', 'Verwijderen'));
	        }
	    }).fail(function () {
	        showActionableError(null, t('delete_ajax_error', 'AJAX-fout bij verwijderen van onderwerp.'));
	        $btn.prop('disabled', false).text(t('remove', 'Verwijderen'));
	    });
	});
	
// 👇 Show/hide "Selected Topics" section based on row count, with slide animation
function updateQueueVisibility() {
    const $wrapper = $('#publion-selected-topics');
    const hasRows = $('#publion-ai-queue tbody tr').length > 0;

    if (hasRows) {
        if (!$wrapper.is(':visible')) $wrapper.stop(true, true).slideDown(200);
    } else {
        if ($wrapper.is(':visible')) $wrapper.stop(true, true).slideUp(200);
    }
}

	// Call once on DOM ready (in case of leftover rows from old session)
	updateQueueVisibility();

	// Add topic to the selected queue and update visibility
	$(document).on('click', '.add-topic', function () {
	    const $button = $(this);
	    const $li = $button.closest('li');
	    const rawTopic = $li.data('topic') || $button.data('topic');
	    const seoBrief = $li.data('seo-brief') || {};
	    const category = $('#publion-category').val();
	    const categoryLabel = $('#publion-category option:selected').text();

	    // Guard against double-clicks or duplicate rows.
	    if ($button.prop('disabled')) return;
	    if ($('#publion-ai-queue tbody tr').filter(function () { return $(this).data('topic') === rawTopic && String($(this).data('category')) === String(category); }).length) {
	        $li.hide();
	        return;
	    }

	    $button.prop('disabled', true);

	    const $row = $('<tr>').data('topic', rawTopic).data('category', category).data('category-label', categoryLabel).data('seo-brief', seoBrief);
	    $row.append($('<td>').append($('<button>', { type: 'button', class: 'button remove-topic', text: t('remove', 'Verwijderen') }).data('restore-topic', rawTopic)));
	    $row.append($('<td>').data('category', category).data('category-label', categoryLabel).text(categoryLabel));
	    $row.append($('<td>').data('topic', rawTopic).text(rawTopic));
	    const briefText = t('focus', 'Focus') + ': ' + (seoBrief.focus_keyword || rawTopic) + ' · ' + (seoBrief.search_intent || t('informational', 'informatief'));
	    $row.append($('<td>', { class: 'publion-queue-brief', text: briefText }));
	    $('#publion-ai-queue tbody').append($row);

	    // Hide the original suggestion
	    $li.hide();

	    setTimeout(() => {
	        updateQueueVisibility();
	    }, 10);
	});

	// Trigger after removing a topic
	$(document).on('click', '.remove-topic', function () {
	    const $button = $(this);
	    const rawTopic = $button.data('restore-topic') || '';
	    
	    // Unhide matching suggestion
	    if (rawTopic) {
	        $('#publion-suggestions li').each(function () {
	            const $li = $(this);
	            const $addBtn = $li.find('.add-topic');
	            if ($li.data('topic') === rawTopic) {
	                $addBtn.prop('disabled', false);
	                $li.show();
	            }
	        });
	    }

	    $button.closest('tr').fadeOut(150, function () {
	        $(this).remove();
	        updateQueueVisibility();
	    });
	});

	function checkLoadMoreVisibility() {
    if ($('#publion-queue-table tbody tr').length < publionQueueLimit) {
	        $('#publion-load-more').hide();
	    }
	    if ($('#publion-created-table tbody tr').length < publionQueueLimit) {
	        $('#publion-load-more-created').hide();
	    }
	}
	
	document.addEventListener('DOMContentLoaded', function () {
	    const manualForm = document.getElementById('publion-manual-form');
	    if (manualForm) {
	        manualForm.addEventListener('submit', function () {
	            const activeTab = localStorage.getItem('publion_active_tab') || 'publion-queue';
	            const url = new URL(manualForm.action);
	            url.searchParams.set('publion_active_tab', activeTab);
	            manualForm.action = url.toString();
	        });
	    }
	});
	
	$(document).ajaxError(function (event, jqXHR, settings, thrownError) {
	    try {
	        if (settings && typeof settings.data === 'string' && settings.data.indexOf('action=publion_') !== -1 && jqXHR && String(jqXHR.responseText || '').trim() === '-1') {
	            showActionableError(jqXHR, t('session_expired_message', 'De actie is niet uitgevoerd omdat de beveiligingssessie niet meer geldig is.'));
	            return;
	        }
	        // settings.data is a URL-encoded string for $.post
        if (settings && typeof settings.data === 'string' && settings.data.indexOf('action=publion_create_post_now') !== -1) {
	            const error = errorDetails(null, t('post_status_uncertain', 'Er ging iets mis. De post is mogelijk toch aangemaakt. Vernieuw de pagina om de actuele status te controleren.'));
	            error.title = t('connection_lost_stage', 'Verbinding onderbroken');
	            error.nextStep = t('connection_lost_next_step', 'Ververs eerst de wachtrij. Start alleen opnieuw als er nog geen concept is aangemaakt.');
	            error.actionLabel = t('refresh_queue', 'Ververs wachtrij');
	            error.actionTab = 'publion-queue';
	            showNotice('error', error.title + ': ' + error.message + ' ' + error.nextStep, error);
        }
	    } catch (e) {
	        // If anything goes wrong parsing, fail quietly—this is just a fallback.
	    }
	});
});

