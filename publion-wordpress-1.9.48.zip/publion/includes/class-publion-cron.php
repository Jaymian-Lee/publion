<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Register a 15-minute cron schedule (so "every_15_minutes" exists).
 */
add_filter( 'cron_schedules', function ( $schedules ) {
	if ( empty( $schedules['every_15_minutes'] ) ) {
		$schedules['every_15_minutes'] = array(
			'interval' => 15 * MINUTE_IN_SECONDS,
			'display'  => __( 'Elke 15 minuten', 'publion' ),
		);
	}
	return $schedules;
} );

/**
 * Cached DB row reader for cron. Centralizes PHPCS ignores so call sites stay clean.
 *
 * @param string $sql   SQL with placeholders.
 * @param array  $args  Placeholder args (array supported by $wpdb->prepare()).
 * @param string $key   Cache key.
 * @param string $group Cache group.
 * @param int    $ttl   Cache seconds.
 * @return object|null  Row object or null.
 */
if ( ! function_exists( 'publion_db_get_row_cached_cron' ) ) {
	function publion_db_get_row_cached_cron( $query_template, array $args, $key, $group, $ttl = 60 ) {
		global $wpdb;

		$cached = wp_cache_get( $key, $group );
		if ( false !== $cached ) {
			return $cached; // may be null
		}

		// The template + args are prepared here.
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$prepared = $wpdb->prepare( $query_template, $args );

		$result = $wpdb->get_row( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$prepared, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			OBJECT
		);

		wp_cache_set( $key, $result, $group, $ttl );
		return $result;
	}
}

class Publion_Cron {

	/** @var string */
	protected $cache_group = 'publion';

	/** @var string */
	protected $cache_key_next_topic = 'next_pending_topic_v1';

	public function __construct() {
		add_action( 'init', array( $this, 'schedule_cron' ) );
		add_action( 'publion_cron_hook', array( $this, 'maybe_create_queued_post' ) );
		add_action( 'publion_daily_topic_hook', array( $this, 'maybe_create_daily_topic' ) );
	}

	public function schedule_cron() {
		if ( ! wp_next_scheduled( 'publion_cron_hook' ) ) {
			// Keep original behavior that used time().
			wp_schedule_event( time(), 'every_15_minutes', 'publion_cron_hook' );
		}

		$settings = get_option( 'publion_post_settings', array() );
		if ( ( $settings['auto_daily_topic'] ?? 'no' ) !== 'yes' ) {
			wp_clear_scheduled_hook( 'publion_daily_topic_hook' );
			return;
		}

		if ( ! wp_next_scheduled( 'publion_daily_topic_hook' ) ) {
			publion_reschedule_daily_topic_event( $settings );
		}
	}

	protected function schedule_next_daily_topic( $settings ) {
		$tz      = wp_timezone();
		$now     = new DateTimeImmutable( 'now', $tz );
		$next_ts = publion_calculate_next_daily_topic_timestamp( $now, $settings );
		wp_clear_scheduled_hook( 'publion_daily_topic_hook' );
		wp_schedule_single_event( $next_ts, 'publion_daily_topic_hook' );
	}

	public function maybe_create_daily_topic() {
		$settings = get_option( 'publion_post_settings', array() );
		if ( ( $settings['auto_daily_topic'] ?? 'no' ) !== 'yes' ) {
			return;
		}

		$api_key = get_option( 'publion_api_key', '' );
		if ( empty( $api_key ) ) {
			$this->schedule_next_daily_topic( $settings );
			return;
		}

		$categories = get_categories(
			array(
				'hide_empty' => false,
				'exclude'    => array( (int) get_option( 'default_category' ) ),
			)
		);
		if ( empty( $categories ) ) {
			$this->schedule_next_daily_topic( $settings );
			return;
		}

		shuffle( $categories );

		$default_prompt = "Je bent een expert in het schrijven van blogs en maakt hoogwaardige, SEO-geoptimaliseerde content voor [JOUW BEDRIJFSNAAM (INDIEN VAN TOEPASSING) EN WEBSITE-URL], [WAT JOUW BEDRIJF/WEBSITE BIEDT]. Het doel is [JOUW BEDRIJFS/WEBSITE-DOELEN]. Stem de toon af op het merk: [DE TOON DIE JE WILT UITSTRALEN - voorbeeld: professioneel maar benaderbaar, deskundig maar eenvoudig uit te leggen]. Elk onderwerp moet de missie van [JOUW BEDRIJFS/WEBSITE-NAAM] weerspiegelen om [BEDRIJVEN of MENSEN] te helpen met [HOE JE BEDRIJVEN of MENSEN HELPT]. (Vervang deze prompt door je eigen tekst om je doelen beter te weerspiegelen.)";
		$pre_prompt     = get_option( 'publion_prompt', $default_prompt );

		global $wpdb;
		if ( empty( $wpdb->publion_queue ) ) {
			$wpdb->publion_queue = $wpdb->prefix . 'publion_queue';
		}
		$content_map = publion_get_existing_content_map();
		$topics_to_add    = publion_get_automatic_topic_batch_size( $settings );
		$topics_added     = 0;
		$suggestion_count = max( 5, min( 12, $topics_to_add ) );

		foreach ( $categories as $category ) {
			$category_name = $category->name;

			$prompt  = $pre_prompt . "\n\nOp basis van de categorie \"" . $category_name . "\", stel " . $suggestion_count . " unieke blogonderwerpen voor.";
			$prompt .= "\n\nLees eerst de onderstaande actuele contentkaart van alle " . (int) $content_map['count'] . " bestaande WordPress-berichten. Geef alleen een onderwerp met een nieuwe zoekvraag en een duidelijk andere invalshoek; hergebruik geen bestaande titel, koppenstructuur of centrale uitleg.\n\n=== ACTUELE CONTENTKAART ===\n" . $content_map['context'] . "\n=== EINDE CONTENTKAART ===";
			$prompt .= "\n\nFormaat: geef exact " . $suggestion_count . " onderwerpen, elk op een eigen regel. Geen inleiding, geen bullets, geen nummers, geen Markdown, geen extra uitleg.";

			$response = wp_remote_post(
				'https://api.openai.com/v1/chat/completions',
				array(
					'headers' => array(
						'Authorization' => 'Bearer ' . $api_key,
						'Content-Type'  => 'application/json',
					),
					'body'    => wp_json_encode(
						publion_build_openai_chat_body(
							publion_get_openai_model(),
							array(
								array( 'role' => 'system', 'content' => 'Je bent een behulpzame assistent.' ),
								array( 'role' => 'user', 'content' => $prompt ),
							),
							360
						)
					),
					'timeout' => 60,
				)
			);

			if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
				update_option( 'publion_last_openai_error', publion_get_openai_request_error( $response, publion_get_openai_model() ) );
				continue;
			}

            $text = publion_parse_article_response( $response );
            if ( is_wp_error( $text ) ) { update_option( 'publion_last_openai_error', $text->get_error_message() ); continue; }
			if ( empty( $text ) ) {
				update_option( 'publion_last_openai_error', 'OpenAI gaf geen onderwerpvoorstellen terug tijdens de geplande taak.' );
				continue;
			}

			delete_option( 'publion_last_openai_error' );

			$lines = preg_split( '/\r\n|\n|\r/', trim( $text ) );
			foreach ( $lines as $line ) {
				$line = trim( $line );
				if ( '' === $line ) {
					continue;
				}

				$line = preg_replace( '/^\s*[-*•]+\s*/', '', $line );
				$line = preg_replace( '/^\s*\d+[\.\)]\s*/', '', $line );
				$line = str_replace( '**', '', $line );
				$line = trim( $line );
				if ( '' === $line ) {
					continue;
				}

                if ( ! publion_is_safe_suggestion_title( $line ) || preg_match( '/[<>]/', $line ) || publion_content_has_instruction_leak( $line ) ) { continue; }
				// Check uniqueness against posts and queue.
				if ( function_exists( 'publion_get_post_id_by_exact_title' ) ) {
					if ( publion_get_post_id_by_exact_title( $line ) ) {
						continue;
					}
				}
				if ( publion_find_existing_content_conflict( $line ) ) {
					continue;
				}

				$exists_in_queue = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$wpdb->prepare(
						"SELECT COUNT(1) FROM {$wpdb->publion_queue} WHERE LOWER(topic) = LOWER(%s)",
						$line
					)
				);
				if ( $exists_in_queue ) {
					continue;
				}

				$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$wpdb->publion_queue,
					array(
						'topic'          => $line,
                        'focus_keyword' => publion_effective_focus_keyword( '', $line ),
						'category_id'    => (int) $category->term_id,
						'category_label' => $category_name,
						'status'         => 'pending',
						'created_at'     => current_time( 'mysql' ),
					)
				);
				$topics_added++;

				// Invalidate caches affected by this write.
				wp_cache_delete( 'pending_ids', $this->cache_group );
				wp_cache_delete( 'pending_total', $this->cache_group );
				publion_schedule_pending_entries( false );

				if ( $topics_added >= $topics_to_add ) {
					$this->schedule_next_daily_topic( $settings );
					return;
				}
			}
		}

		$this->schedule_next_daily_topic( $settings );
	}

	public function maybe_create_queued_post() {
		global $wpdb;

		// Register custom table on $wpdb so PHPCS allows it in prepared SQL.
		if ( empty( $wpdb->publion_queue ) ) {
			$wpdb->publion_queue = $wpdb->prefix . 'publion_queue';
		}

		// Read settings.
		$settings           = get_option( 'publion_post_settings', array() );
		$post_status        = publion_get_requested_post_status( $settings );
		$add_cta            = ( ( $settings['cta_enabled'] ?? 'no' ) === 'yes' );
		$cta_text           = $settings['cta_text'] ?? '';
		$cta_link           = $settings['cta_link'] ?? '';
		$notification_email = $settings['notification_email'] ?? '';
		$rank_math_enabled  = ( ( $settings['rank_math_integration'] ?? 'no' ) === 'yes' );
		$author_id          = publion_get_post_author_id( $settings, 'first' );

		// Ensure schedule exists for pending entries.
		publion_schedule_pending_entries( false );

		// Normalize stragglers: pending + has post_created_at -> created.
		// Writes are not cacheable. We invalidate the read cache below.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->publion_queue} SET status = %s WHERE status = %s AND post_created_at IS NOT NULL",
				'created',
				'pending'
			)
		);

		// Invalidate cached "next topic" after write that may affect result set.
		wp_cache_delete( $this->cache_key_next_topic, $this->cache_group );
		publion_release_stale_processing_entries();

		// Select next pending by lowest ID via cached helper (keeps call site WPCS-clean).
		$topic = publion_db_get_row_cached_cron(
			"SELECT * FROM {$wpdb->publion_queue} WHERE status = %s AND post_created_at IS NULL AND (retry_after IS NULL OR retry_after <= %s) ORDER BY (scheduled_at IS NULL) ASC, scheduled_at ASC, id ASC LIMIT 1",
			array( 'pending', current_time( 'mysql' ) ),
			$this->cache_key_next_topic,
			$this->cache_group,
			60
		);

		if ( ! $topic ) {
			return;
		}

		$scheduled_ts = $topic->scheduled_at ? publion_mysql_to_timestamp( $topic->scheduled_at ) : 0;
		$now_ts       = current_time( 'timestamp' );
		if ( $scheduled_ts && $now_ts < $scheduled_ts ) {
			return;
		}

		$existing_post_id = publion_get_post_id_for_queue_entry( $topic );
		if ( $existing_post_id ) {
			$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->publion_queue,
				array( 'status' => ( 'publish' === get_post_status( $existing_post_id ) ? 'published' : 'created' ), 'processing_started_at' => null ),
				array( 'id' => (int) $topic->id )
			);
			wp_cache_delete( $this->cache_key_next_topic, $this->cache_group );
			return;
		}
		if ( ! publion_claim_queue_entry( (int) $topic->id, $topic->topic ) ) {
			return;
		}

		// A duplicate title is a terminal outcome for this queue row, not a reason
		// to keep it pending and block every later scheduled article.
		$topic_validation = publion_validate_topic_originality( $topic->topic );
		if ( is_wp_error( $topic_validation ) ) {
            publion_record_queue_failure( (int) $topic->id, $topic->topic, $topic_validation );
            return;
        }

		// Generate HTML content.
		$seo_brief = ! empty( $topic->seo_brief ) ? json_decode( $topic->seo_brief, true ) : array();
        if ( ! is_array( $seo_brief ) ) { publion_record_queue_failure( (int) $topic->id, $topic->topic, new WP_Error( 'publion_invalid_input', 'De opgeslagen SEO-brief is ongeldige JSON.' ) ); return; }
		$seo_brief['focus_keyword'] = publion_effective_focus_keyword( $topic->focus_keyword ?? '', $topic->topic );
		if ( $rank_math_enabled && is_wp_error( publion_validate_rank_math_focus_keyword( $seo_brief['focus_keyword'] ) ) ) {
			publion_release_queue_claim( (int) $topic->id, $topic->topic, 'blocked' );
			return;
		}
		$post_html = publion_generate_queue_article( $topic, $seo_brief );
		if ( is_wp_error( $post_html ) && 'publion_duplicate_content' === $post_html->get_error_code() ) {
            publion_record_queue_failure( (int) $topic->id, $topic->topic, $post_html );
            return;
        }

		if ( is_wp_error( $post_html ) || ! $post_html ) {
			publion_record_queue_failure( (int) $topic->id, $topic->topic, $post_html );
			return;
		}

		$category = get_term( (int) $topic->category_id, 'category' );
		$category_name = ( $category && ! is_wp_error( $category ) ) ? $category->name : '';
		$media = publion_generate_queue_media( $topic, $post_html, $category_name, get_option( 'publion_api_key', '' ) );
		if ( is_wp_error( $media ) ) { publion_record_queue_failure( (int) $topic->id, $topic->topic, $media ); return; }
		$post_html = $media['html'];
		if ( $media['requires_review'] ) { $post_status = 'draft'; }
		$rank_math_quality_report = array();
		if ( $rank_math_enabled ) {
			$rank_math_quality_report = publion_get_rank_math_quality_report( $post_html, $seo_brief['focus_keyword'], $topic->topic );
			// A manually selected Publish status must not bypass a failed hard
			// content check. Keep the result as a draft until it is repaired.
			if ( publion_get_rank_math_settings( $settings )['publish_gate'] && ! empty( $rank_math_quality_report['failed_required'] ) ) {
				$post_status = 'draft';
			}
		}


		// Check once more immediately before writing: another source may have
		// created an equivalent article while this cron job generated images.
		$final_conflict = publion_find_existing_content_conflict( $topic->topic, $post_html );
		if ( $final_conflict ) {
			publion_record_queue_failure( (int) $topic->id, $topic->topic, new WP_Error( 'publion_duplicate_content', 'Tijdens de generatie is een vergelijkbaar artikel aangemaakt.' ) );
			return;
		}

        $valid = publion_validate_article_content( $post_html, $topic->topic, $seo_brief['focus_keyword'] );
        if ( is_wp_error( $valid ) ) { publion_record_queue_failure( (int) $topic->id, $topic->topic, $valid ); return; }
        if ( ! publion_renew_queue_claim( (int) $topic->id, $topic->topic ) ) { return; }
		// Create post.
		$post_id = wp_insert_post( array(
			'post_title'    => $topic->topic,
			'post_name'     => publion_build_rank_math_slug( $seo_brief['focus_keyword'], $topic->topic ),
			'post_content'  => wp_slash( $post_html ),
			'post_status'   => 'draft',
            'meta_input' => array( '_publion_queue_id' => (int) $topic->id ),
			'comment_status'=> 'closed',
			'ping_status'   => 'closed',
			'post_category' => array( $topic->category_id ),
			'post_type'     => 'post',
			'post_author'   => $author_id,
		), true );
		
		if ( ! is_wp_error( $post_id ) && $post_id ) {
			// Link post -> queue row for reliable lookups later.
			// Using update_post_meta makes this safe to run more than once.
			update_post_meta( (int) $post_id, '_publion_queue_id', (int) $topic->id );
			publion_store_article_seo_data( $post_id, $post_html, $seo_brief['focus_keyword'] );

			if ( $rank_math_enabled ) {
				publion_store_rank_math_post_data( $post_id, $post_html, $seo_brief['focus_keyword'], $topic->topic );
				update_post_meta( (int) $post_id, '_publion_rank_math_quality_report', wp_json_encode( $rank_math_quality_report ) );
				update_post_meta( (int) $post_id, '_publion_rank_math_quality_status', sanitize_key( $rank_math_quality_report['status'] ?? 'review_required' ) );
			}
		}
		
		if ( is_wp_error( $post_id ) || ! $post_id ) {
			publion_record_queue_failure( (int) $topic->id, $topic->topic, new WP_Error( 'publion_post_write_failed', 'WordPress kon het gevalideerde concept niet opslaan.' ) );
			return;
		}

		if ( $media['hero_id'] ) { set_post_thumbnail( $post_id, $media['hero_id'] ); }
		update_post_meta( $post_id, '_publion_hero_display', publion_get_pipeline_limits()['hero_display'] );
		update_post_meta( $post_id, '_publion_image_slots', $media['images'] );
		publion_store_safety_report( $post_id, $post_html );
        if ( ! publion_renew_queue_claim( (int) $topic->id, $topic->topic ) ) { return; }
        if ( publion_source_review_required( $post_id ) ) { $post_status = 'draft'; update_post_meta( $post_id, '_publion_publication_error', 'Bronreview nodig. Open Publion Diagnose.' ); }
		$status_result = publion_ensure_requested_post_status( $post_id, $post_status );
		if ( is_wp_error( $status_result ) ) {
			$now = current_time( 'mysql' );
			$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->publion_queue,
				array(
					'status'                => 'created',
					'processing_started_at' => null,
					'post_created_at'       => $now,
				),
				array( 'id' => (int) $topic->id, 'claim_token' => $GLOBALS['publion_claim_tokens'][(int) $topic->id] ?? '' ),
                null,
                array( '%d', '%s' )
			);
			wp_cache_delete( $this->cache_key_next_topic, $this->cache_group );
			publion_release_generation_lock( (int) $topic->id, $topic->topic );
			error_log( '[Publion][PUBLION-POST-STATUS] Queue item #' . (int) $topic->id . ': ' . publion_redact_error( $status_result->get_error_message() ) );
			return;
		}
		$actual_post_status = get_post_status( $post_id );

		// Update queue row. Writes are not cacheable; also invalidate the next-topic cache.
		$now = current_time( 'mysql' );
		$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->publion_queue,
			array(
				'status'          => ( 'publish' === $actual_post_status ? 'published' : 'created' ),
				'processing_started_at' => null,
				'post_created_at' => $now,
				'published_at'    => ( 'publish' === $actual_post_status ? $now : null ),
			),
			array( 'id' => (int) $topic->id, 'claim_token' => $GLOBALS['publion_claim_tokens'][(int) $topic->id] ?? '' ),
			null,
			array( '%d', '%s' )
		);
		wp_cache_delete( $this->cache_key_next_topic, $this->cache_group );
		publion_release_generation_lock( (int) $topic->id, $topic->topic );

		update_option( 'publion_last_post_created_at', $now );

		// Email Notification.
		if ( ! empty( $notification_email ) && is_email( $notification_email ) && get_permalink( $post_id ) ) {
			wp_mail(
				$notification_email,
				'Nieuwe post aangemaakt door Publion',
				"Er is zojuist een nieuwe post aangemaakt met de titel \"{$topic->topic}\".\n\nBekijk hem hier:\n" . get_permalink( $post_id ),
				array( 'Content-Type: text/plain; charset=UTF-8' )
			);
		}
	}
}
